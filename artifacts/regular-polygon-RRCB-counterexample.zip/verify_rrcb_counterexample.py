#!/usr/bin/env python3
"""Exact small verifier of the arithmetic, with no huge-matrix construction."""
from math import comb, isqrt
from itertools import product

def prime(p):
    return p >= 2 and all(p % i for i in range(2,isqrt(p)+1))

PASCAL=[[1]]
for r in range(1,369):
    old=PASCAL[-1]
    PASCAL.append([1]+[old[k-1]+old[k] for k in range(1,r)]+[1])

def max_ub(r,choose):
    assert r>=3
    Q=[]
    for d in range(2,r):
        j=d//2
        a=2*choose(r-j-1,j) if d%2 else choose(r-j,j)+choose(r-j-1,j-1)
        Q.append((a,d))
    return max(Q)

def small_gray(m,w):
    if w==0: return [0]
    if w==m: return [(1<<m)-1]
    return small_gray(m-1,w)+[x|(1<<(m-1)) for x in reversed(small_gray(m-1,w-1))]

for m in range(2,13):
    for w in range(1,m):
        L=small_gray(m,w)
        assert len(L)==len(set(L))==comb(m,w)
        assert all(x.bit_count()==w for x in L)
        assert all((a^b).bit_count()==2 for a,b in zip(L,L[1:]+L[:1]))

def add9(a,b):
    return (a+b)%3+3*((a//3+b//3)%3)
def mul9(a,b):
    x,y=a%3,a//3
    z,w=b%3,b//3
    return (x*z-y*w)%3+3*((x*w+y*z)%3)
def check9():
    A=[[add9(x,y) for y in range(9)]for x in range(9)]
    M=[[mul9(x,y) for y in range(9)]for x in range(9)]
    assert all(1 in M[x] for x in range(1,9))
    for x,y,z in product(range(9),repeat=3):
        assert M[M[x][y]][z]==M[x][M[y][z]]
        assert M[x][A[y][z]]==A[M[x][y]][M[x][z]]
    hist=[0]*11
    for a in product(range(9),repeat=5):
        if not any(a): continue
        ct=(a[4]==0)
        for t in range(9):
            z=0
            for c in reversed(a): z=A[M[t][z]][c]
            ct+=z==0
        assert ct<=4
        hist[ct]+=1
    assert sum(hist)==9**5-1
    return hist

def case(m,p,q,t,last):
    assert prime(p) and m<p and p*p<=q**5
    assert t>=2*4+2
    assert t<=q+1
    n=comb(m,m//2)
    assert n==PASCAL[m][m//2]
    a=max_ub(last,comb)
    b=max_ub(last,lambda u,v:PASCAL[u][v])
    assert a==b and a[0]<n and m+q*t<last+1
    print('n =',n)
    print('RRCB <=',m+q*t,'< rank_+ lower bound',last+1)
    print('max vertices with',last,'facets =',a[0],'; dimension =',a[1])

if __name__=='__main__':
    case(206,211,9,10,296)
    hist=check9();print('GF(9) projective roots of 59,048 nonzero polynomials:',hist[:5])
    case(256,257,11,10,368)
