// Pair of 34/31 anchors, two specified degree-three residues, plus seven
// degree-one vertices. Exact colored-hypergraph canonicalization (all equal
// signature permutations) while fixing the four distinguished roles.
#include <bits/stdc++.h>
using namespace std;using V=vector<int>;int bit(int i){return 1<<i;}
int main(int ac,char**av){ifstream in(av[1]);string s;set<V>S;long long ct=0,p=0;while(getline(in,s)){stringstream ss(s);int a,c,d,h,n;ss>>a>>c>>d>>h;d=0;while(d==a||d==c||d==10)d++;assert(h==6);V T;while(h--){int x;ss>>x;T.push_back(4096|x);}ss>>n;while(n--){int x;ss>>x;T.push_back(x);}int old[]={10,a,c,d};map<V,V>G;array<int,11>m;for(int j=0;j<4;j++)m[old[j]]=10-j;for(int i=0;i<11;i++)if(find(old,old+4,i)==old+4){V v(64);for(int x:T)if(x&bit(i)){int code=(x/2048)*16;for(int k=0;k<4;k++)if(x&bit(old[k]))code+=bit(k);v[code]++;}G[v].push_back(i);}
 V best;vector<V> g;for(auto&kv:G)g.push_back(kv.second);auto go=[&](auto&&f,int k,int num)->void{if(k==g.size()){V x;for(int a:T){int v=a&~2047;for(int j=a&2047;j;j&=j-1)v|=bit(m[__builtin_ctz(j)]);x.push_back(v);}sort(x.begin(),x.end());if(best.empty()||x<best)best=x;p++;return;}
 auto&u=g[k];do{for(int j=0;j<u.size();j++)m[u[j]]=num+j;f(f,k+1,num+u.size());}while(next_permutation(u.begin(),u.end()));};go(go,0,0);S.insert(best);ct++;}
 int id=0;for(auto&u:S){cout<<++id<<' '<<u.size();for(int x:u)cout<<' '<<x;cout<<'\n';}cerr<<ct<<" labeled, "<<p<<" permutations, "<<S.size()<<" full shell classes"<<endl;}
