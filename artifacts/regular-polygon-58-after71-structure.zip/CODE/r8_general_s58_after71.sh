#!/bin/sh
# Ancillary structural results beyond f>=71. Requires common input VF catalogue.
set -eu
cd "$(dirname "$0")/..";w=${WORK:-$(mktemp -d)};mkdir -p "$w";if [ -z "${WORK:-}" ];then trap 'rm -rf "$w"' EXIT;fi
C=${CXX:-c++};for s in r8_general_s58_f71pair r8_general_s58_f71shellcanon r8_general_s58_f71third r3_geom_quickp r3_geom_stream r3_geom_export r4_chord_concurrency;do "$C" -O3 -w -std=c++17 "CODE/$s.cpp" -o "$w/$s";done
if [ "${1:-}" = --source ];then src=$2;else
 sed 's/if(nf>=33)/if(nf==36||nf==38)/' CODE/r3_geom_fill.cpp >"$w/fill.cpp";"$C" -O3 "$w/fill.cpp" -o "$w/fill";for s in canon links;do "$C" -O3 -std=c++17 "CODE/r3_geom_$s.cpp" -o "$w/$s";done
 "$w/fill" CERTIFICATES/r3_geom_vertexfigures.txt 0 1142 "$w/pt" >"$w/f.log";"$w/canon" CERTIFICATES/r3_geom_vertexfigures.txt "$w/pt" "$w/can" >"$w/c.log";"$w/links" CERTIFICATES/r3_geom_smalllinks.txt "$w/can" "$w/all" >"$w/l.log";src="$w/all"
fi
python3 - "$src" "$w" <<'PY'
from pathlib import Path
from itertools import combinations
import hashlib,sys
p=Path(sys.argv[2]);v=Path(sys.argv[1]).read_bytes()
for n,sha in [(36,'a9d1b5a7ab5c2b1ca35966d6610402322bc519c7861507481af199c172e1c1c3'),(38,'a00cc53ab256d5f7404519d6f48fae896b3945d0c4df03f00e93b29e0cf94035')]:
 a=b''.join(v[i:i+32]for i in range(0,len(v),32)if int.from_bytes(v[i:i+32],'little').bit_count()==n)
 assert hashlib.sha256(a).hexdigest()==sha;(p/str(n)).write_bytes(a)
F=[i for i in range(1024)if i.bit_count()==5];P=[(i,j,sum(1<<n for n,x in enumerate(F)if x>>i&x>>j&1))for i,j in combinations(range(10),2)];z=(p/'36').read_bytes();T=[]
for i in range(0,len(z),32):
 u=int.from_bytes(z[i:i+32],'little');M=[(i,j)for i,j,m in P if not u&m]
 if len(set(a for e in M for a in e))==3:T.append(z[i:i+32])
assert len(T)==77;(p/'tri').write_bytes(b''.join(T))
PY
a=CERTIFICATES/r8_s58_f67_six.bin;b=CERTIFICATES/r8_s58_f67_stars.txt
"$w/r8_general_s58_f71pair" "$a" "$b" >"$w/query" 2>"$w/A";tail -1 "$w/A";grep -q '^result pairs 509436 shells 1619 pointed 1619$' "$w/A"
python3 - "$w" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);G={36:[],38:[]}
for line in(p/'query').open():
 a,c,d,n,*H=map(int,line.split());G[42-2*sum(x>>c&1 for x in H[:n])].append(line)
assert [len(G[36]),len(G[38])]==[972,647]
for k,l in G.items():(p/('q'+str(k))).write_text(''.join(l))
PY
for k in 36 38;do "$w/r8_general_s58_f71shellcanon" "$w/q$k" >"$w/s$k";"$w/r8_general_s58_f71third" "$w/s$k" "$w/$k" "$k" >"$w/out$k" 2>"$w/rep$k";tail -1 "$w/rep$k";test ! -s "$w/out$k";done
grep -q '7517 distinct placements; stages 2018 2018 104 0 0 0 0' "$w/rep36";grep -q '0 exact partner comparisons 0 distinct placements' "$w/rep38"
"$w/r4_chord_concurrency" 58 1000037 668900 "$w/b" >"$w/ct";python3 CODE/r4_chord_triples_exact.py 58 "$w/b" "$w/exact";python3 CODE/r5_general_patterns35.py 58 "$w/exact" >"$w/p"
sed 's/const int K=32,N=58/const int K=31,N=58/' CODE/r8_general_s58_intrinsic.cpp >"$w/s31.cpp";"$C" -O3 -std=c++17 "$w/s31.cpp" -o "$w/s31"
"$w/r3_geom_quickp" "$w/tri" 36 1000000 0 "$w/q" 31 >"$w/front";cmp "$w/q" "$w/tri";"$w/r3_geom_stream" "$w/q" 1000000 "$w/chi" 0 31 > "$w/g";"$w/r3_geom_export" "$w/q" "$w/chi" >"$w/raw";"$w/s31" "$w/p" "$w/raw" "$w/left" 3 >"$w/terminal";cat "$w/terminal";test ! -s "$w/left";grep -q 'traces 337 layouts 678 .* 0 652 26 0 0 memo' "$w/terminal"
python3 CODE/r8_general_s58_hollowprofiles.py
