// Match complete 36-facet geometry catalogue to the two anchored face-stars
// inside a candidate third low (C=8). A=10,B=9,D=7; all high labels 0..6.
#include <bits/stdc++.h>
using namespace std;int NF=0;using U=uint64_t;using V=vector<int>;int bit(int i){return 1<<i;}int pc(int x){return __builtin_popcount(x);}int wt(U x){return __builtin_popcountll(x);}
int dropC(int v){return(v&255)|((v>>9)<<8);}int insertC(int v){return(v&255)|((v>>8)<<9)|256;}
struct Ga{V F,H;array<U,10>I{};array<int,10>D{};};
Ga geo(V f,V h){Ga g;g.F=f;g.H=h;for(int i=0;i<f.size();i++)for(int j=0;j<10;j++)if(f[i]&bit(j))g.I[j]|=U(1)<<i;for(int e:h)for(int j=0;j<10;j++)if(e&bit(j))g.D[j]|=e^bit(j);return g;}
struct Ank{int a,b;U x,y,z;array<int,10>d;array<int,9>sig;};
Ank anchor(const Ga&g,int a,int b){
 Ank o{a,b};o.x=g.I[a]&~g.I[b];o.y=g.I[b]&~g.I[a];o.z=g.I[a]&g.I[b];int j=1;
 o.sig[0]=wt(o.x)|(wt(o.y)<<5)|(wt(o.z)<<10)|(pc(g.D[a])<<15)|(pc(g.D[b])<<18)|(((g.D[a]>>b)&1)<<21);
 for(int i=0;i<10;i++)if(i!=a&&i!=b){int v=wt(g.I[i]&o.x)|(wt(g.I[i]&o.y)<<5)|(wt(g.I[i]&o.z)<<10)|(pc(g.D[i])<<15)|(((g.D[i]>>a)&1)<<18)|(((g.D[i]>>b)&1)<<19);o.sig[j++]=o.d[i]=v;}
 sort(o.sig.begin()+1,o.sig.end());return o;}
struct Hsh{size_t operator()(const array<int,9>&s)const{U h=0xf67323c2003ULL;for(int i:s)h=(h^i)*1099511628211ULL;return h;}};
struct Case{V F,H,T;Ga g;Ank k;set<V>live;};vector<Case>C;long long s0,s1,s2,s3,s4,s5,s6,pre,iso,src;
bool sub(int a,int b){return (a&b)==a;}
void fill(int id,Case&q,const V&CF){
 // C facets are actual full 6-facets. Every previously determined hollow is
 // absent from both these and the remaining pure-anchor complement.
 for(int f:CF)for(int h:q.H)if(sub(h,f))return;
 set<int>S(CF.begin(),CF.end());for(int v:q.F)S.insert(v&2047);int ng=S.size();if(ng>71||ng+28<71)return;
 int Fd[11],dg[11]={},rid[2048]={};for(int i=0;i<11;i++){Fd[i]=42;for(int x:q.H)if(x&bit(i))Fd[i]-=2;}
 for(int f:S)for(int v=f;v;v&=v-1){int i=__builtin_ctz(v);dg[i]++;rid[f^bit(i)]++;}
 for(int i=0;i<11;i++)if(dg[i]>Fd[i])return;
 for(int i=0;i<2048;i++)if(rid[i]>2||((i&1792)&&rid[i]==1))return;
 s0++;int E[8][8]={},k=0;V mask;for(int a=0;a<8;a++)for(int b=0;b<a;b++){E[a][b]=E[b][a]=k++;mask.push_back(255^bit(a)^bit(b));}
 auto tri=[&](int a,int b,int c){return (U(1)<<E[a][b])|(U(1)<<E[b][c])|(U(1)<<E[c][a]);};
 auto inc=[&](int a,int b,int c){return rid[255^bit(a)^bit(b)^bit(c)];};
 U base=0,forbid=0;for(int a=1;a<8;a++)for(int b=1;b<a;b++)if(inc(a,b,0)&1)base|=U(1)<<E[a][b];for(int i=0;i<28;i++)for(int h:q.H)if(sub(h,mask[i]))forbid|=U(1)<<i;
 for(int a=1;a<8;a++)for(int b=1;b<a;b++)for(int c=1;c<b;c++)if(__builtin_parityll(base&tri(a,b,c))!=(inc(a,b,c)&1))return;
 s1++;int n=71-ng;for(int j=0;j<8;j++){int d=dg[j]+n-Fd[j];if(d<0||d>7)return;}
 s2++;for(int t=0;t<128;t++){int m=t<<1;U v=base;for(int a=0;a<8;a++)for(int b=0;b<a;b++)if(((m>>a)^(m>>b))&1)v^=U(1)<<E[a][b];if((v&forbid)||wt(v)!=n)continue;s3++;
 bool ok=true;for(int a=0;a<8;a++){int miss=0;for(int j=0;j<8;j++)if(a!=j)miss+=int(v>>E[a][j]&1);if(dg[a]+n-miss!=Fd[a])ok=false;}if(!ok)continue;s4++;
 for(int a=0;a<8&&ok;a++)for(int b=0;b<a&&ok;b++)for(int c=0;c<b&&ok;c++){int r=inc(a,b,c)+wt(v&tri(a,b,c));if(r!=0&&r!=2)ok=false;}if(!ok)continue;s5++;
 V full(S.begin(),S.end());for(int j=0;j<28;j++)if(v>>j&1)full.push_back(mask[j]);sort(full.begin(),full.end());assert(full.size()==71);
 bool faces[2048]={};for(int f:full)for(int s=f;s;s=(s-1)&f)faces[s]=true;
 for(int i=0;i<2048;i++)if((pc(i)==2&&!faces[i])||(pc(i)==3&&(faces[i]==(find(q.H.begin(),q.H.end(),i)!=q.H.end()))))ok=false;if(!ok)continue;
 s6++;cout<<"candidate "<<id;for(int f:full)cout<<' '<<f;cout<<'\n';}
}
V image(const V&f,const array<int,10>&m){V p;for(int v:f){int w=0;for(int j=v&1023;j;j&=j-1)w|=bit(m[__builtin_ctz(j)]);p.push_back(w|(v&1024));}sort(p.begin(),p.end());return p;}
uint32_t pairkey(const Ga&g,const Ank&o,int i,int j){U u=g.I[i]&g.I[j];return wt(u&o.x)|(wt(u&o.y)<<5)|(wt(u&o.z)<<10)|(((g.D[i]>>j)&1)<<15);}
void place(int id,const Ga&g,const Ank&o,const V&F0){auto&q=C[id];auto&t=q.k;auto&h=q.g;
 array<int,10>m; m[o.a]=9;m[o.b]=8;V rest;std::array<V,10>poss;for(int i=0;i<10;i++)if(i!=o.a&&i!=o.b){for(int j=0;j<8;j++)if(o.d[i]==t.d[j])poss[i].push_back(j);rest.push_back(i);}sort(rest.begin(),rest.end(),[&](int a,int b){return poss[a].size()<poss[b].size();});
 auto go=[&](auto&&f,int at,int used)->void{if(at<8){int i=rest[at];for(int y:poss[i])if(!(used&bit(y))){bool ok=true;for(int k=0;k<at;k++){int j=rest[k];if(pairkey(g,o,i,j)!=pairkey(h,t,y,m[j]))ok=false;}if(ok){m[i]=y;f(f,at+1,used|bit(y));}}return;}
 if(image(F0,m)!=q.T)return;iso++;auto z=image(g.F,m);for(int&v:z)v=insertC(v);if(q.live.insert(z).second)fill(id,q,z);};
 go(go,0,0);
}
int main(int ac,char**av){NF=stoi(av[3]);ifstream c(av[1]),q(av[2],ios::binary);int id,n;unordered_map<array<int,9>,V,Hsh> idx;
 while(c>>id>>n){Case z;V t,h;for(int i=0;i<n;i++){int u;c>>u;int f=u&2047;if(u>=4096){z.H.push_back(f);if(f&256)h.push_back(dropC(f));}else{z.F.push_back(u);if(f&256)t.push_back(dropC(f));}}assert(h.size()==(42-NF)/2);z.g=geo(t,h);z.k=anchor(z.g,9,8);z.T=t;for(int y:h)z.T.push_back(y|1024);sort(z.T.begin(),z.T.end());idx[z.k.sig].push_back(C.size());C.push_back(move(z));}
 V words;for(int x=0;x<1024;x++)if(pc(x)==5)words.push_back(x);array<U,4>book;while(q.read((char*)book.data(),32)){V f,h;for(int j=0;j<252;j++)if(book[j/64]>>(j%64)&1)f.push_back(words[j]);if(f.size()!=NF)continue;auto g=geo(f,{});for(int a=0;a<10;a++)for(int b=0;b<a;b++)if(!(g.I[a]&g.I[b]))h.push_back(bit(a)|bit(b));assert(h.size()==(42-NF)/2);g=geo(f,h);src++;
 for(int a=0;a<10;a++)for(int b=0;b<10;b++)if(a!=b){auto o=anchor(g,a,b);auto it=idx.find(o.sig);if(it==idx.end())continue;V F;for(int y:f)if(y&(bit(a)|bit(b)))F.push_back(y);for(int x:h)F.push_back(x|1024);for(int id:it->second){pre++;place(id,g,o,F);}}
 if(src%5000==0)cerr<<src<<" source pre "<<pre<<" exact "<<iso<<" shell cut "<<s6<<endl;}
 int placements=0;for(auto&q:C)placements+=q.live.size();cerr<<"complete "<<src<<" source "<<idx.size()<<" signatures "<<C.size()<<" shells "<<pre<<" pre "<<iso<<" exact partner comparisons "<<placements<<" distinct placements; stages "<<s0<<' '<<s1<<' '<<s2<<' '<<s3<<' '<<s4<<' '<<s5<<' '<<s6<<endl;}
