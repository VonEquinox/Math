"""Exact hollow hypergraphs up to high-label and deficit-preserving low-label
permutations, after the proper f38 and (34,31) pair packing exclusions.
A high (32-mark) vertex is in 0 or 1 hollow, so distinct holes always have
disjoint high parts. A hole records just its subset of the <=4 non-high labels.
"""
from itertools import permutations,combinations_with_replacement
from collections import Counter
from pathlib import Path
import math,sys
def reps(E):
 for d in ((1,1,1,1),(1,1,2),(1,3),(2,2),(4,)):
  n=len(d);U=range(n);S=[x for x in range(1<<n)if x.bit_count()<=3];G=[]
  for p in permutations(U):
   if tuple(d[i]for i in p)==d:
    G.append([sum(1<<p[i]for i in U if x>>i&1)for x in range(1<<n)])
  for T in combinations_with_replacement(S,E):
   if any(x==y and x.bit_count()==3 for x,y in zip(T,T[1:])):continue
   H=sum(3-x.bit_count()for x in T)
   if H>11-n:continue
   deg=[sum(x>>i&1 for x in T)for i in U]
   if any(h>{1:4,2:5,3:6,4:7}[j]for h,j in zip(deg,d)):continue
   L=[i for i in U if d[i]==1 and deg[i]==4]
   if len(L)>1:continue
   if any(tuple(sorted(g[x]for x in T))<T for g in G):continue
   holes=[];h=n
   for x in T:
    m=3-x.bit_count();holes.append(x+sum(1<<j for j in range(h,h+m)));h+=m
   if L:
    i=L[0];ee=[v^(1<<i)for v in holes if v>>i&1];D=[sum(x>>j&1 for x in ee)for j in range(11)];b=sorted(v for v in D if v);W=sum(1<<j for j in range(11) if D[j]==2)
    if b!=[1]*8 and not(b==[1,1,1,1,2,2]and W in ee):continue
   yield d,T,H,holes
if __name__=='__main__':
 for E in range(6,-1,-1):
  A=list(reps(E));C=Counter(z[2]for z in A)
  print('f',77-E,'types',len(A),'h1-high',sorted(C.items()),flush=True)
if __name__=='__main__':
 for E in range(6,-1,-1):
  L=[]
  for d,T,h,H in reps(E):
   bad=False
   for i,a in enumerate(d):
    if a!=1:continue
    K=[e^(1<<i) for e in H if e>>i&1]
    if len(K)==3 and (K[0]|K[1]|K[2]).bit_count()==3:bad=True
   if not bad:L.append(h)
  print('f',77-E,'after K3 exclusion',len(L),'minimum high f40',min(L))
