#!/bin/sh
# Terminal f70 incompatibility: 3-low parity fill, then two-low incidence signatures.
set -eu
cd "$(dirname "$0")/..";w=${WORK:-$(mktemp -d)};mkdir -p "$w";if [ -z "${WORK:-}" ];then trap 'rm -rf "$w"' EXIT;fi
C=${CXX:-c++};for s in r8_general_s58_triplefill r8_general_s58_pairanchors r8_general_s58_h70sig;do "$C" -O3 -std=c++17 -w "CODE/$s.cpp" -o "$w/$s";done
a=CERTIFICATES/r8_s58_f67_six.bin;b=CERTIFICATES/r8_s58_f67_stars.txt
python3 - "$a" <<'PY'
from pathlib import Path
from itertools import combinations
import sys
v=Path(sys.argv[1]).read_bytes();assert len(v)==6*32;fs=[x for x in range(1024)if x.bit_count()==5]
for m in range(0,len(v),32):
 z=int.from_bytes(v[m:m+32],'little');F=[f for j,f in enumerate(fs)if z>>j&1];assert len(F)==34
 E=[(a,b)for a,b in combinations(range(10),2)if not any(f>>a&f>>b&1 for f in F)];assert len(E)==4
 deg=[sum(i in e for e in E)for i in range(10)];d=sorted(x for x in deg if x);T=tuple(i for i in range(10)if deg[i]==2)
 assert d==[1]*8 or (d==[1,1,1,1,2,2] and T in E)
PY
"$w/r8_general_s58_triplefill" "$a" "$b" 70 >"$w/list" 2>"$w/T";tail -1 "$w/T";test ! -s "$w/list";grep -q '^result 310024 triples; 28560 affine consistent; 5374 degree-two-ridge fills; 0 allowed facet degrees; 0 selected-degree feasible$' "$w/T"
"$w/r8_general_s58_pairanchors" "$a" "$b" >"$w/query" 2>"$w/A";tail -1 "$w/A";grep -q '^result pairs 509436 shells 972 pointed 1944$' "$w/A";test "$(wc -l <"$w/query")" -eq 1944
if [ "${1:-}" = --source ];then src=$2;else
 sed 's/if(nf>=33)/if(nf==36)/' CODE/r3_geom_fill.cpp >"$w/fill.cpp";"$C" -O3 -std=c++17 "$w/fill.cpp" -o "$w/fill";for s in canon links;do "$C" -O3 -std=c++17 "CODE/r3_geom_$s.cpp" -o "$w/$s";done
 "$w/fill" CERTIFICATES/r3_geom_vertexfigures.txt 0 1142 "$w/pt" >"$w/f.log";"$w/canon" CERTIFICATES/r3_geom_vertexfigures.txt "$w/pt" "$w/can" >"$w/c.log";"$w/links" CERTIFICATES/r3_geom_smalllinks.txt "$w/can" "$w/all" >"$w/l.log";src="$w/all"
fi
python3 - "$src" "$w/36" <<'PY'
from pathlib import Path
import hashlib,sys
v=Path(sys.argv[1]).read_bytes();a=b''.join(v[i:i+32]for i in range(0,len(v),32)if int.from_bytes(v[i:i+32],'little').bit_count()==36)
assert(len(a),hashlib.sha256(a).hexdigest())==(26548*32,'a9d1b5a7ab5c2b1ca35966d6610402322bc519c7861507481af199c172e1c1c3')
Path(sys.argv[2]).write_bytes(a)
PY
"$w/r8_general_s58_h70sig" "$w/query" "$w/36" >"$w/res";cat "$w/res";grep -q '^catalog 26548; target signatures 16 source matches 38842; target signatures 19 source matches 120; target signatures 23 source matches 0$' "$w/res"
echo 'Every f70 case is excluded. Balanced regular58 ambient f>=71.'
