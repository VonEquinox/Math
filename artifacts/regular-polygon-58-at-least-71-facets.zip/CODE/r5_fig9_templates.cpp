// From all joined rank-three quotient signs, recover exact labelled shadow
// support cycles; deduplicate via whole serialized key, never a hash alone.
#include <bits/stdc++.h>
using namespace std;using U=unsigned;using V=uint64_t;using AR=array<unsigned char,53>;
struct H{size_t operator()(const AR&a) const{size_t h=0xcbf29ce484222325ULL;for(unsigned x:a)h=(h^x)*0x100000001b3ULL;return h;}};
struct Tet{array<int,4> t;int a,b,m;};
struct T{vector<int> Fs;vector<Tet> ts;};
int main(int ac,char**av){
 if(ac<3)return 2;map<int,T>D;ifstream c(av[1]);string s;int n,ids[512],ix=0;
 for(int a=0;a<9;a++)for(int b=a+1;b<9;b++)for(int e=b+1;e<9;e++)ids[(1<<a)|(1<<b)|(1<<e)]=ix++;
 while(c>>s>>n){auto&t=D[stoi(s.substr(1))];t.Fs.resize(n);for(int&f:t.Fs)c>>f;for(int m=0;m<512;m++)if(__builtin_popcount(m)==4){
   vector<int>L;for(int j=0;j<n;j++)if((t.Fs[j]&m)==m)L.push_back(j);if(L.empty())continue;assert(L.size()==2);
   Tet te{};te.a=L[0];te.b=L[1];te.m=m;int k=0;for(int b=0;b<9;b++)if(m>>b&1)te.t[k++]=ids[m^(1<<b)];t.ts.push_back(te);
 }}
 int id; V lo,hi;U active;int min_n=(ac>3?atoi(av[3]):0);
 // 9-bit masks require a 16-bit entry.
 using KEY=array<unsigned short,54>;
 struct HK{size_t operator()(const KEY&a) const{size_t h=0xcbf29ce484222325ULL;for(unsigned x:a)h=(h^x)*0x100000001b3ULL;return h;}};
 unordered_set<KEY,HK>seen;ifstream f(av[2]);unsigned long long hist[37]={};
 while(f>>id>>n>>lo>>hi>>active){if(n<min_n)continue;const auto &t=D.at(id);auto bit=[&](int b){return int(((b<64?lo:hi)>>(b%64))&1);};
   int ct[32]={},N[32][2]{},E[32][2]{},start=999,facet=-1;
   for(auto &te:t.ts){auto a=te.t;int j=bit(a[0]);if(j==bit(a[2])&&j!=bit(a[1])&&j!=bit(a[3])){
       assert(ct[te.a]<2&&ct[te.b]<2);N[te.a][ct[te.a]]=te.b;E[te.a][ct[te.a]++]=te.m;N[te.b][ct[te.b]]=te.a;E[te.b][ct[te.b]++]=te.m;
       if(te.m<start){start=te.m;facet=(t.Fs[te.a]<t.Fs[te.b]?te.a:te.b);}
   }}
   KEY k{};k[0]=n;assert(facet>=0);int ff=facet,prev=start;
   for(int j=0;j<n;j++){assert(ct[ff]==2&&(E[ff][0]==prev||E[ff][1]==prev));const int p=(E[ff][0]==prev?1:0);
       k[1+j]=511^t.Fs[ff];k[1+n+j]=prev;prev=E[ff][p];ff=N[ff][p];
   }assert(ff==facet&&prev==start);
   if(ac>4)k[53]=id; // preserve ambient type for omitted-facet backlinks
   if(seen.insert(k).second){hist[n]++;cout<<id;for(int j=0;j<=2*n;j++)cout<<' '<<k[j];cout<<'\n';}
 }
 for(int i=18;i<=30;i++)if(hist[i])cerr<<i<<' '<<hist[i]<<'\n';
}
