// Independent third-low tester. Use only specified vertex degrees in its two
// marked sub-stars and their common facets. No isomorphism or GF2 code.
#include <bits/stdc++.h>
using namespace std;using V=vector<int>;using U=uint64_t;
int b(int i){return 1<<i;}int pc(int i){return __builtin_popcount(i);}int wt(U i){return __builtin_popcountll(i);}
struct Tbl{array<V,11>v;};
V key(int n,int a,int b0,int c,const V&F,const V&H,int detail){V A(3),w;for(int x:F){if(c>=0&&!(x&b(c)))continue;int k=!!(x&b(a))+2*!!(x&b(b0));if(k)A[k-1]++;}if(detail>=2){int u=0,v=0,t=0;for(int x:H){if(c>=0&&!(x&b(c)))continue;u+=!!(x&b(a));v+=!!(x&b(b0));t+= ((x&b(a))&&(x&b(b0)));}A.push_back(u+8*v+64*t);}
 for(int i=0;i<n;i++)if(i!=a&&i!=b0&&i!=c){int h[3]={},dd=0;for(int x:F){if(c>=0&&!(x&b(c)))continue;if(!(x&b(i)))continue;int k=!!(x&b(a))+2*!!(x&b(b0));if(k)h[k-1]++;}if(detail>=2)for(int x:H){if(c>=0&&!(x&b(c)))continue;if(x&b(i))dd+=1+8*!!(x&b(a))+16*!!(x&b(b0));}
  w.push_back(h[0]+32*h[1]+1024*h[2]+32768*dd);}
 if(detail)sort(w.begin(),w.end()),A.insert(A.end(),w.begin(),w.end());return A;}
int main(int ac,char**av){ifstream in(av[1]),ge(av[2],ios::binary);set<V>Q[3];string l;while(getline(in,l)){stringstream s(l);int a,c,d,n,k;s>>a>>c>>d>>n;V H(n);for(int&u:H)s>>u;s>>k;V F(k);for(int&u:F){s>>u;u&=2047;}for(int t=0;t<3;t++)Q[t].insert(key(11,10,a,c,F,H,t));}
 array<U,4>M;V word;for(int i=0;i<1024;i++)if(pc(i)==5)word.push_back(i);long long totals[3]={};int ns=0;
 while(ge.read((char*)M.data(),32)){V F,H;U inc[10]={};for(int j=0;j<252;j++)if(M[j/64]>>(j%64)&1){int f=word[j];for(int i=0;i<10;i++)if(f&b(i))inc[i]|=U(1)<<F.size();F.push_back(f);}if(F.size()!=36)continue;ns++;for(int i=0;i<10;i++)for(int j=0;j<i;j++)if(!(inc[i]&inc[j]))H.push_back(b(i)|b(j));assert(H.size()==3);
 for(int a=0;a<10;a++)for(int b0=0;b0<10;b0++)if(a!=b0){U x=inc[a]&~inc[b0],y=inc[b0]&~inc[a],z=inc[a]&inc[b0];V k{wt(x),wt(y),wt(z)};if(!Q[0].count(k))continue;totals[0]++;V w;for(int i=0;i<10;i++)if(i!=a&&i!=b0)w.push_back(wt(x&inc[i])+32*wt(y&inc[i])+1024*wt(z&inc[i]));sort(w.begin(),w.end());k.insert(k.end(),w.begin(),w.end());if(!Q[1].count(k))continue;totals[1]++;if(Q[2].count(key(10,a,b0,-1,F,H,2)))totals[2]++;}}
 cout<<"catalog "<<ns;for(int i=0;i<3;i++)cout<<"; target signatures "<<Q[i].size()<<" source matches "<<totals[i];cout<<'\n';}
