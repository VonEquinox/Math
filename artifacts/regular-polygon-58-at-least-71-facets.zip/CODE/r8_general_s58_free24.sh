#!/bin/sh
# Arbitrary nine-width polygons: at most 24 regular58 grid marks, both polarities.
set -eu
cd "$(dirname "$0")/..";w=${WORK:-$(mktemp -d)};mkdir -p "$w";if [ -z "${WORK:-}" ];then trap 'rm -rf "$w"' EXIT;fi
C=${CXX:-c++};for s in r2_geom_pivot5 r2_geom_glue5 r5_fig9_templates r4_chord_concurrency r5_general_fasttree r7_general_mass_exactrect;do "$C" -O3 -std=c++17 "CODE/$s.cpp" -o "$w/$s";done
"$C" -O3 -std=c++17 -DMARKED_K=25 CODE/r5_general_marked34.cpp -o "$w/mk";sed 's/n>=30/n>=25/g' CODE/r5_general_markedjoin.cpp >"$w/j.cpp";"$C" -O3 -std=c++17 "$w/j.cpp" -o "$w/join"
g=CERTIFICATES/r2_simplicial5_large.txt;sha=$(sha256sum "$g"|cut -d" " -f1);test "$sha" = c8d1ee7da0753cda298a8a33be163a613bbc1a8242ac1f428725180c990bfd59
"$w/r2_geom_pivot5" "$g" "$w/pi" 25 >"$w/p.log";"$w/r2_geom_glue5" "$g" "$w/pi" 25 "$w/G" >"$w/g.log";"$w/r5_fig9_templates" "$g" "$w/G" 25 >"$w/raw";test "$(wc -l <"$w/raw")" -eq 298
"$w/r4_chord_concurrency" 58 1000037 668900 "$w/b" >"$w/c.log";python3 CODE/r4_chord_triples_exact.py 58 "$w/b" "$w/e";python3 CODE/r5_general_patterns35.py 58 "$w/e" >"$w/p";test "$(wc -l <"$w/p")" -eq 26040
"$w/mk" "$w/raw" "$w/back" 58 "$w/dat" "$w/p" >"$w/head";test "$(wc -l <"$w/back")" -eq 796;cat "$w/head" "$w/dat" >"$w/sys";"$w/join" "$w/p" "$w/sys" 50000 58 >"$w/j";tail -1 "$w/j";grep -q '^total=202 unsat=201 budget=0 candidates=1$' "$w/j"
: >"$w/none";python3 CODE/r5_general_massstream.py "$w/raw" "$w/back" "$w/j" "$w/m" 58 25 0 "$w/none";python3 CODE/r5_general_metalines.py "$w/m.meta" 58 >"$w/ms";cmp "$w/ms" CERTIFICATES/r8_s58_w9K25_mask.txt
"$w/r5_general_fasttree" "$w/ms" "$w/eq" 9;echo 0 >"$w/one";"$w/r7_general_mass_exactrect" "$w/eq" "$w/one" 8 - "$w/p" >"$w/term";cat "$w/term";grep -q '^total 1 empty / 1$' "$w/term"
