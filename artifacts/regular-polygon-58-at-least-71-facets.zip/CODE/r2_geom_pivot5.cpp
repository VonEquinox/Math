// Five-dimensional necessary screen. For each selected pivot y_i in R^3/Y, contract
// to eight rank-two rays modulo span(y_i). Sweeping a line in the transverse quotient
// leaves label i on the boundary; assigning that label either sign must pass both cap
// Euler tests. A candidate full-dimensional section facet must have a strictly
// positive circuit among the non-i vertices in this rank-two view.
// Usage: pivot INPUT [records.bin|-] [threshold=25]; outputs per-type/pivot counts.
#include <cstdio>
#include <iostream>
#include <fstream>
#include <cstring>
#include <string>
#include <vector>
#include <array>
#include <algorithm>
#include <cstdlib>
#include <cassert>
#include <iomanip>
using namespace std;using U=unsigned;
static_assert(sizeof(U)==4);
const int ALL=511;
int thr=25,pi,anchor,fN,nei,iter,typ;long long nodes;U mix[512];bool admiss[512];
int order[9],pos[9];U seenpat[1<<8];ofstream records;
struct Rec{U id,i,sign,facets;};
int pc(U m){return __builtin_popcount(m);} int bt(int i){return 1<<i;}
int gcode(int S){
 int z=0,ix=0;
 for(int j=0;j<9;j++)if(j!=pi)for(int k=j+1;k<9;k++)if(k!=pi){
    bool neg=(pos[j]>pos[k])^bool(S&bt(j))^bool(S&bt(k))^bool((pi>j)^(pi>k));
    if(neg)z|=1<<ix;
    ++ix;
 }
 assert(ix==28);return z&1?(z^((1<<28)-1)):z;
}
void walk(int S0,int S,int left,U F,int level){
 ++nodes;if(!admiss[S] || pc(F&=mix[S])<thr)return;
 if(!left){
  if(order[1]>order[7])return; // choose either orientation of the sweep
  ++iter;if(records.is_open()){unsigned pat=gcode(S0);Rec r{(U)typ,(U)pi,pat,F};records.write((char*)&r,sizeof(r));}
  return;
 }
 for(int j=0;j<9;j++)if(left&bt(j)){order[level]=j;pos[j]=level;walk(S0,S^bt(j),left^bt(j),F,level+1);}
}
int main(int argc,char**argv){if(argc<2)return 1;ifstream file(argv[1]);if(argc>2&&string(argv[2])!="-")records.open(argv[2],ios::binary);if(argc>3)thr=atoi(argv[3]);string id;int nf;long long tot=0;
 while(file>>id>>nf){typ=stoi(id.substr(1));vector<int>F(nf);bool face[512]={};int chi[512]={};
 for(auto&f:F){file>>f;for(int s=f;s;s=(s-1)&f)face[s]=true;}
 for(int s=0;s<512;s++){for(int t=s;t;t=(t-1)&s)if(face[t])chi[s]+=(pc(t)%2?1:-1);}
 cout<<id<<' '<<nf;
 for(pi=0;pi<9;pi++){nei=ALL^bt(pi);anchor=pi==0?1:0;
 for(int S=0;S<512;S++)if(!(S&bt(pi))){auto T=nei^S;
 admiss[S]=(chi[S]==1&&chi[S|bt(pi)]==1&&chi[T]==1&&chi[T|bt(pi)]==1);
 mix[S]=0;for(int k=0;k<nf;k++)if((F[k]&S)&&(F[k]&T))mix[S]|=1u<<k;}
 iter=0;nodes=0;order[0]=anchor;pos[anchor]=0;
 for(int S=0;S<512;S++){if((S&(bt(pi)|bt(anchor)))||!admiss[S])continue;walk(S,S^bt(anchor),nei^bt(anchor),mix[S],1);}
 tot+=iter;cout<<' '<<iter;
 }
 cout<<'\n';}
 cerr<<"surviving pivot views: "<<tot<<'\n';
}
