// Three six-dimensional vertex stars leave eight labels outside. Their wholly
// outside facets complement graph edges; closed ridge parity on every outside
// 5-ridge fixes its triangle edge XOR. Only seven edge choices remain.
#define main oldmain
#include "r8_general_s58_fourlow_check.cpp"
#undef main
using U=uint32_t;
struct Tot{long long triples=0,parity=0,sphere=0,degree=0,bm=0;};Tot totals;int targetF=70;
bool bmatch(array<int,8>d,U avail,const int E[8][8]){
 for(int i=0;i<8;i++)if(d[i]<0)return false;
 auto dfs=[&](auto&&f,int i)->bool{
  while(i<8&&!d[i])i++;if(i==8)return true;
  vector<int>L;for(int j=i+1;j<8;j++)if((avail>>E[i][j]&1)&&d[j])L.push_back(j);
  if(L.size()<d[i])return false;
  auto pick=[&](auto&&g,int at,int rem)->bool{if(!rem)return f(f,i+1);
  for(int k=at;k+rem<=L.size();k++){d[L[k]]--;if(g(g,k+1,rem-1))return true;d[L[k]]++;}return false;};
  return pick(pick,0,d[i]);};return dfs(dfs,0);
}
void test(const H&st,const H&A,const H&B,int L){
 totals.triples++;U F0[64]{};set<int>I(st.begin(),st.end());I.insert(A.begin(),A.end());I.insert(B.begin(),B.end());
 int outside[8],r=0,ng=I.size(),ngs=0,deg[11]{},sel[11]{},inc[2048]{};
 if(ng>targetF||ng+28<targetF)return;
 for(int i=0;i<11;i++)if(!(L&bit(i)))outside[r++]=i;assert(r==8);
 for(int u:I){int v=u&2047;ngs+=u<2048;for(int x=v;x;x&=x-1){int i=__builtin_ctz(x);deg[i]++;sel[i]+=u<2048;inc[v^bit(i)]++;}}
 if(ngs>58)return;for(int t=0;t<2048;t++)if(inc[t]>2||((t&L)&&(inc[t]==1)))return;
 int E[8][8]={},k=0,pfx=0;array<int,28> mask{};for(int i=0;i<8;i++)for(int j=0;j<i;j++){E[i][j]=E[j][i]=k;mask[k++]=2047^L^bit(outside[i])^bit(outside[j]);}
 int z[8][8][8]={};for(int a=0;a<8;a++)for(int b=0;b<a;b++)for(int c=0;c<b;c++)z[a][b][c]=inc[2047^L^bit(outside[a])^bit(outside[b])^bit(outside[c])];
 U ref=0;for(int a=1;a<8;a++)for(int b=1;b<a;b++)if(z[a][b][0]&1)ref|=U(1)<<E[a][b];
 for(int a=1;a<8;a++)for(int b=1;b<a;b++)for(int c=1;c<b;c++)if((__builtin_parity(ref&((U(1)<<E[a][b])|(U(1)<<E[b][c])|(U(1)<<E[c][a]))))!=(z[a][b][c]&1))return;
 totals.parity++;
 for(int t=0;t<128;t++){int m=t<<1;U u=ref;for(int a=0;a<8;a++)for(int b=0;b<a;b++)if(((m>>a)^(m>>b))&1)u^=U(1)<<E[a][b];int c=__builtin_popcount(u);if(ng+c!=targetF)continue;
 bool ok=true;for(int a=0;a<8&&ok;a++)for(int b=0;b<a&&ok;b++)for(int h=0;h<b&&ok;h++){int l=z[a][b][h]+((u>>E[a][b])&1)+((u>>E[b][h])&1)+((u>>E[h][a])&1);if(l&&l!=2)ok=false;}if(!ok)continue;totals.sphere++;
 // All 3 anchors have 31 selected facets, so exactly one remaining low (31);
 // all other vertices need 32, hence (conditional on f38 exclusion) f>=40.
 int f[8];for(int a=0;a<8;a++){int n=0;for(int j=0;j<8;j++)if(a!=j)n+=(u>>E[a][j])&1;f[a]=deg[outside[a]]+c-n;}
 for(int low=0;low<8;low++){bool ok=true;for(int a=0;a<8;a++)if(f[a]<(a==low?34:40)||f[a]>42||(f[a]&1))ok=false;if(!ok)continue;
 totals.degree++;array<int,8>w;for(int a=0;a<8;a++)w[a]=sel[outside[a]]+58-ngs-(a==low?31:32);
 if(!bmatch(w,u,E))continue;totals.bm++;cout<<"AMBIENT "<<targetF<<" full "<<ng+c<<" low "<<outside[low]<<" anchors "<<L<<" facets";for(auto v:I)cout<<' '<<(v&2047);for(int j=0;j<28;j++)if((u>>j)&1)cout<<' '<<mask[j];cout<<'\n';
 }}
}
int main(int ac,char**av){ifstream q(av[1],ios::binary),t(av[2]);if(ac>3)targetF=stoi(av[3]);map<H,State>Q;string l;while(getline(t,l)){stringstream ss(l);int id,o;ss>>id;set<int>O;while(ss>>o)O.insert(o);q.seekg(32*(id-1));array<uint64_t,4>a;q.read((char*)a.data(),32);assert(q);H f;int j=0;for(int v=0;v<1024;v++)if(pc(v)==5){if(a[j/64]>>(j%64)&1)f.push_back(v|(O.count(v)?1024:0));++j;}assert(f.size()==34&&O.size()==3);auto K=canon(10,f,false).key;if(Q.count(K))continue;State P;P.facets=K;for(int v=0;v<10;v++){H F;for(int e:K)if(e&bit(v))F.push_back((e&(bit(v)-1))|((e>>(v+1))<<v));P.link[v]=canon(9,F,true);}Q[K]=P;}
 int at=0;for(auto&[key,P]:Q){vector<vector<H>>op(10);for(int j=0;j<10;j++){set<H>S;auto&T=P.link[j];
 for(auto&[k,R]:Q)for(int b=0;b<10;b++){auto&s=R.link[b];if(s.key!=T.key)continue;
 for(auto&t:T.maps){A I{},map{};for(int k=0;k<9;k++)I[t[k]]=k;
 for(int k=0;k<10;k++)if(k==b)map[k]=10;else{int v=s.maps[0][k-(k>b)],w=I[v];map[k]=w+(w>=j);}
 H a;for(int e:R.facets)a.push_back(permute(e&1023,map)|bit(j)|((e&1024)<<1));sort(a.begin(),a.end());S.insert(a);}}
 op[j].assign(S.begin(),S.end());}
 H star;for(int e:P.facets)star.push_back((e&1023)|1024|((e&1024)<<1));sort(star.begin(),star.end());
 auto edge=[](const H&v,int j){H x;for(int t:v)if(t&bit(j))x.push_back(t);return x;};
 for(int a=0;a<9;a++)for(int b=a+1;b<10;b++){map<H,vector<int>>ab;for(int j=0;j<op[b].size();j++)ab[edge(op[b][j],a)].push_back(j);for(auto&x:op[a]){auto h=ab.find(edge(x,b));if(h!=ab.end())for(int j:h->second)test(star,x,op[b][j],1024|bit(a)|bit(b));}}
 cerr<<"anchor "<<++at<<" "<<totals.triples<<" "<<totals.parity<<" "<<totals.sphere<<" "<<totals.degree<<" "<<totals.bm<<endl;}
 cerr<<"result "<<totals.triples<<" triples; "<<totals.parity<<" affine consistent; "<<totals.sphere<<" degree-two-ridge fills; "<<totals.degree<<" allowed facet degrees; "<<totals.bm<<" selected-degree feasible"<<endl;}
