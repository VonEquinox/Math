// Glue rank-two chirotopes of nine contractions to one rank-three signed table.
// Counts complete signed tables (global sign quotient) having at least 25 true
// tetrahedral ridge hits. Each accepted chirotope is only necessary: no metric,
// convex extension realization, or regularity is assumed.
// Usage: glue facemasks.txt pivot-records.bin [threshold=25] [candidate-output]
#include <array>
#include <vector>
#include <string>
#include <set>
#include <map>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <unordered_map>
#include <cstdint>
#include <cassert>
using namespace std;using U=unsigned;using V=uint64_t;
int pc(U m){return __builtin_popcount(m);} int bit(int x){return 1<<x;}
struct T{V lo=0,hi=0;bool get(int i)const{return ((i<64?lo:hi)>>(i%64))&1;} void set(int i){(i<64?lo:hi)|=1ull<<(i%64);}friend T operator|(T a,T b){return {a.lo|b.lo,a.hi|b.hi};}};
struct Rec {U id,i,sign,facets;};struct Entry{T set;U f;};
int trid[512],local[9][28],threshold=25,typ,nf;
vector<Rec> v[9];array<int,9> seq;vector<int> Fs;
unordered_map<U,vector<Entry>> lookup[9];vector<pair<int,int>> keybits[9];
struct Tet{array<int,4> t;int miss;int face;};vector<Tet> ts;
array<long long,10> cnt;int best;long long hits,ccount;ofstream extra;
void process(T X){
 int n=0,active=0,parent[32],nn=0; for(int t=0;t<nf;t++)parent[t]=t;
 auto root=[&](int x){while(x!=parent[x])x=parent[x];return x;};
 for(auto&r:ts){bool x=X.get(r.t[0]); if(x!=X.get(r.t[1])&&x==X.get(r.t[2])&&x!=X.get(r.t[3])){
   n++;int a=root(r.miss),b=root(r.face);active|=bit(r.miss)|bit(r.face); if(a!=b){parent[a]=b;nn++;}
 }}
 best=max(best,n);if(n<threshold)return;hits++;if(nn!=n-1)return;ccount++;
 if(extra.is_open())extra<<typ<<" "<<n<<" "<<X.lo<<" "<<X.hi<<" "<<active<<"\n";
}
void walk(int k,T X,U F){cnt[k]++;if(k==9){process(X);return;}U key=0;
 for(auto [i,j]:keybits[k])if(X.get(j))key|=1u<<i;
 auto it=lookup[k].find(key);if(it==lookup[k].end())return;
 for(auto e:it->second)if(pc(F&e.f)>=threshold)walk(k+1,X|e.set,F&e.f);
}
int main(int argc,char**argv){
 if(argc<3)return 1;if(argc>3)threshold=atoi(argv[3]);if(argc>4)extra.open(argv[4]);
 int index=0;for(int i=0;i<9;i++)for(int j=i+1;j<9;j++)for(int k=j+1;k<9;k++)trid[bit(i)|bit(j)|bit(k)]=index++;
 for(int h=0;h<9;h++){int ix=0;for(int j=0;j<9;j++)if(h!=j)for(int k=j+1;k<9;k++)if(k!=h)local[h][ix++]=trid[bit(h)|bit(j)|bit(k)];assert(ix==28);}
 ifstream file(argv[1]),bin(argv[2],ios::binary); Rec r;bool has=bool(bin.read((char*)&r,sizeof r));string id;
 while(file>>id>>nf){typ=stoi(id.substr(1));Fs.resize(nf);for(int&f:Fs)file>>f;ts.clear();for(int s=0;s<512;s++)if(pc(s)==4){vector<int>a;for(int k=0;k<nf;k++)if((Fs[k]&s)==s)a.push_back(k);if(a.empty())continue;assert(a.size()==2);Tet t;int q=0;for(int j=0;j<9;j++)if(s&bit(j))t.t[q++]=trid[s^bit(j)];t.miss=a[0];t.face=a[1];ts.push_back(t);}
 for(int h=0;h<9;h++){v[h].clear();seq[h]=h;}while(has&&r.id==U(typ)){v[r.i].push_back(r);has=bool(bin.read((char*)&r,sizeof r));}
 sort(seq.begin(),seq.end(),[](int a,int b){return v[a].size()!=v[b].size()?v[a].size()<v[b].size():a<b;});
 bool known[84]={};for(int k=0;k<9;k++){int h=seq[k];lookup[k].clear();keybits[k].clear();U mk=0;for(int j=0;j<28;j++)if(known[local[h][j]]){mk|=1u<<j;keybits[k].emplace_back(j,local[h][j]);}
 for(Rec q:v[h])for(int neg=0;neg<1+(k!=0);neg++){U p=q.sign^(neg?((1u<<28)-1):0);T X;for(int j=0;j<28;j++)if(p&bit(j))X.set(local[h][j]);lookup[k][p&mk].push_back({X,q.facets});}
 for(int j=0;j<28;j++)known[local[h][j]]=1;}
 cnt.fill(0);best=hits=ccount=0;walk(0,{0,0},(1u<<nf)-1);
 cout<<id<<" "<<nf;for(auto c:cnt)cout<<" "<<c;cout<<" "<<best<<" "<<hits<<" "<<ccount<<"\n";
 }
}
