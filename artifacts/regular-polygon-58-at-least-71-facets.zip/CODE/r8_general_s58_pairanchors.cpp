#define main oldmain
#include "r8_general_s58_fourlow_check.cpp"
#undef main
int main(int ac,char**av){ifstream q(av[1],ios::binary),t(av[2]);map<H,State>Q;string l;while(getline(t,l)){stringstream ss(l);int id,o;ss>>id;set<int>O;while(ss>>o)O.insert(o);q.seekg(32*(id-1));array<uint64_t,4>a;q.read((char*)a.data(),32);assert(q);H f;int j=0;for(int v=0;v<1024;v++)if(pc(v)==5){if(a[j/64]>>(j%64)&1)f.push_back(v|(O.count(v)?1024:0));++j;}assert(f.size()==34&&O.size()==3);auto K=canon(10,f,false).key;if(Q.count(K))continue;State P;P.facets=K;for(int v=0;v<10;v++){H F;for(int e:K)if(e&bit(v))F.push_back((e&(bit(v)-1))|((e>>(v+1))<<v));P.link[v]=canon(9,F,true);}Q[K]=P;}
 long long pairs=0, census=0, terminals=0;int at=0;for(auto&[key,P]:Q){vector<vector<H>>op(10);for(int j=0;j<10;j++){set<H>S;auto&T=P.link[j];
 for(auto&[k,R]:Q)for(int b=0;b<10;b++){auto&s=R.link[b];if(s.key!=T.key)continue;
 for(auto&t:T.maps){A I{},map{};for(int k=0;k<9;k++)I[t[k]]=k;
 for(int k=0;k<10;k++)if(k==b)map[k]=10;else{int v=s.maps[0][k-(k>b)],w=I[v];map[k]=w+(w>=j);}
 H a;for(int e:R.facets)a.push_back(permute(e&1023,map)|bit(j)|((e&1024)<<1));sort(a.begin(),a.end());S.insert(a);}}
 op[j].assign(S.begin(),S.end());}
 H star;for(int e:P.facets)star.push_back((e&1023)|1024|((e&1024)<<1));sort(star.begin(),star.end());

 for(int a=0;a<10;a++)for(auto&Z:op[a]){pairs++;set<int>F(star.begin(),star.end());F.insert(Z.begin(),Z.end());int L=1024|bit(a);array<int,2048>sub{};for(int u:F)for(int x=u&2047;x;x=(x-1)&(u&2047))sub[x]++;
 vector<int>H;for(int x=0;x<2048;x++)if(pc(x)==3&&(x&L)&&!sub[x])H.push_back(x);
 if(H.size()<6||H.size()>7)continue;
 for(int z=0;z<2048;z++)if((H.size()==7?z==0:pc(z)==3&&!(z&L))){int d[11]={};for(int x:H)for(int i=0;i<11;i++)d[i]+=x>>i&1;
 for(int i=0;i<11;i++)d[i]+=z>>i&1;assert(d[10]==4&&d[a]==4);vector<int>other;int ones=0;for(int i=0;i<11;i++)if(!(L&bit(i))){if(d[i]==3)other.push_back(i);if(d[i]==1)ones++;}
 if(other.size()!=2||ones!=7)continue;census++;
 // Compatible ambient would have the indicated four low vertices; keep every
 // h=3 marked vertex choice, together with ALL known colored A/B facets.
 for(int c:other){terminals++;cout<<a<<' '<<c<<' '<<(other[0]^other[1]^c)<<" 7";for(int x:H)cout<<' '<<x;if(z)cout<<' '<<z;cout<<' '<<F.size();for(int e:F)cout<<' '<<e;cout<<'\n';}}}
 cerr<<"anchor "<<++at<<" pairs "<<pairs<<" shells "<<census<<" pointed "<<terminals<<endl;}
 cerr<<"result pairs "<<pairs<<" shells "<<census<<" pointed "<<terminals<<endl;}
