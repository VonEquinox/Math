#!/bin/sh
# Exact proper 32-mark terminal in all f38 regular58 figures.
set -eu
cd "$(dirname "$0")/..";w=${WORK:-$(mktemp -d)};mkdir -p "$w";if [ -z "${WORK:-}" ];then trap 'rm -rf "$w"' EXIT;fi
c=${CXX:-c++};for s in r4_chord_concurrency r5_general_fasttree r7_general_mass_exactrect r6_general_closure r6_general_validate_slp;do "$c" -O3 -std=c++17 "CODE/$s.cpp" -o "$w/$s";done
"$c" -O3 -std=c++17 -DGROUPED_CLOSURE CODE/r6_general_closecheck.cpp -o "$w/bundle";mkdir -p "$w/empty"
"$w/r4_chord_concurrency" 58 1000037 668900 "$w/buckets" >"$w/chord.log";python3 CODE/r4_chord_triples_exact.py 58 "$w/buckets" "$w/exact";python3 CODE/r5_general_patterns35.py 58 "$w/exact" >"$w/p";test "$(wc -l <"$w/p")" -eq 26040
gzip -dc CERTIFICATES/r8_s58_f38_K32_masks.gz > "$w/ms"
if [ -n "${1:-}" ];then
 for s in r3_geom_quickp r3_geom_stream r3_geom_export r5_general_markedjoin r8_general_s58_intrinsic r8_general_s58_intrinsicjoin;do "$c" -O3 -std=c++17 "CODE/$s.cpp" -o "$w/$s";done
 if [ "$1" = --source ];then src=$2;else
  test "$1" = --rebuild;sed 's/if(nf>=33)/if(nf==38)/' CODE/r3_geom_fill.cpp > "$w/flo.cpp";"$c" -O3 -std=c++17 "$w/flo.cpp" -o "$w/fill";for s in canon links;do "$c" -O3 -std=c++17 "CODE/r3_geom_$s.cpp" -o "$w/$s";done
  "$w/fill" CERTIFICATES/r3_geom_vertexfigures.txt 0 1142 "$w/pointed" > "$w/fcount";"$w/canon" CERTIFICATES/r3_geom_vertexfigures.txt "$w/pointed" "$w/canonical" > "$w/ccount";"$w/links" CERTIFICATES/r3_geom_smalllinks.txt "$w/canonical" "$w/all" > "$w/lcount";src="$w/all"
 fi
 python3 - "$src" "$w/38" <<'PY'
from pathlib import Path
import hashlib,sys
v=Path(sys.argv[1]).read_bytes()
a=b''.join(v[i:i+32]for i in range(0,len(v),32)if int.from_bytes(v[i:i+32],'little').bit_count()==38)
assert (len(a),hashlib.sha256(a).hexdigest())==(65541*32,'a00cc53ab256d5f7404519d6f48fae896b3945d0c4df03f00e93b29e0cf94035')
Path(sys.argv[2]).write_bytes(a)
PY
 q="$w/geom";mkdir -p "$q/chunks";"$w/r3_geom_quickp" "$w/38" 38 1000000 0 "$q/q" 32 >"$q/q.log";cmp "$q/q" "$w/38"
 a=0;while [ "$a" -lt 65541 ];do p="$q/chunks/b$a";"$w/r3_geom_stream" "$q/q" 400 "$q/chi" "$a" 32 >"$p.ge";"$w/r3_geom_export" "$q/q" "$q/chi" >"$q/tmp";"$w/r8_general_s58_intrinsic" "$w/p" "$q/tmp" "$p.left" 3 >"$p.log";gzip -c "$q/tmp" >"$p.gz";a=$((a+400));done
 python3 CODE/r8_general_s58_gather36.py "$q/chunks" "$q";"$w/r8_general_s58_intrinsicjoin" "$w/p" "$q/raw" "$q/left" "$q/data" "$q/back" >"$q/head";cat "$q/head" "$q/data" >"$q/sys";"$w/r5_general_markedjoin" "$w/p" "$q/sys" 15000 58 >"$q/j";grep -q 'total=1272 unsat=1119 budget=0 candidates=153' "$q/j"
 : >"$q/none";python3 CODE/r5_general_massstream.py "$q/raw" "$q/back" "$q/j" "$q/m" 58 32 0 "$q/none";python3 CODE/r5_general_metalines.py "$q/m.meta" 58 > "$q/ms";cmp "$q/ms" "$w/ms"
fi
"$w/r5_general_fasttree" "$w/ms" "$w/eq" 9;seq 0 204 >"$w/ids";"$w/r7_general_mass_exactrect" "$w/eq" "$w/ids" 8 - "$w/p" > "$w/e";tail -1 "$w/e";grep -q '^total 197 empty / 205$' "$w/e"
awk '/ unresolved /{print $1}' "$w/e" >"$w/left";test "$(wc -l <"$w/left")" -eq 8
"$w/r6_general_closure" "$w/ms" "$w/left" "$w/sl" 8 4 3;"$w/r6_general_validate_slp" "$w/ms" "$w/sl";"$w/bundle" "$w/sl" "$w/empty" '' 8 2400 1021 >"$w/term";tail -1 "$w/term";grep -q '^total 8 empty / 8$' "$w/term"
echo 'No f38 proper K32. Balanced S58 six-dimensional ambient f>=70.'
