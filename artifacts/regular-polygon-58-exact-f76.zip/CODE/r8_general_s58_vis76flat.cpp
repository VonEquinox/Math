// E1 horizon, delete one hollow vertex A. Emit seed B C C visibility mask. All 8 other local links have 42 facets.
#include <bits/stdc++.h>
#ifdef __BMI2__
#include <immintrin.h>
#endif
using namespace std;using U=uint64_t;using V=vector<int>;int bit(int i){return 1<<i;}int pc(int x){return __builtin_popcount(x);}int wt(U x){return __builtin_popcountll(x);}
int pext(int x,int m){
#ifdef __BMI2__
return _pext_u32(x,m);
#else
int out=0,n=1;for(;m;m&=m-1,n*=2)if(x&(m&-m))out+=n;return out;
#endif
}
struct Old{int id;V F;int nb[50][10];};
struct Opt{U P,hash;int N0,c,d,pattern,obs;};
long long seeds=0,PV=0,optionN=0,look=0,joinN=0,proper=0;ofstream out;
void run(Old&o,int B,int emit){
 int mB=bit(B),f[20],fi[50],k=0;U sl[10]={};
 for(int i=0;i<50;i++){for(int j=0;j<10;j++)if(o.F[i]&bit(j))sl[j]|=U(1)<<i;if(!(o.F[i]&mB)){f[k]=i;fi[i]=k++;}}assert(k==20&&wt(sl[B])==30);
 // Linear packed exact encoding of nine integers. For any subset of old
 // facets 2v_j-e_j lies between -15 and 40, width < 64.
 U Q[1024]={};for(int s=1;s<1024;s++){int j=__builtin_ctz(s);Q[s]=Q[s&(s-1)]+(j==B?0:U(1)<<(6*(j-(j>B))));}
 int nb0[20]={};U delta[20][64]{};for(int i=0;i<20;i++){int v=f[i];for(int j=0;j<10;j++)if(o.F[v]&bit(j)){int u=o.nb[v][j];if(!(o.F[u]&mB))nb0[i]|=bit(fi[u]);}
 V ord;for(int s=nb0[i];s;s&=s-1)ord.push_back(__builtin_ctz(s));for(int t=0;t<(1<<ord.size());t++){U a=2*Q[o.F[v]];for(int j=0;j<ord.size();j++)if(t&bit(j))a-=Q[o.F[v]&o.F[f[ord[j]]]];delta[i][t]=a;}}

 const unsigned tab=1u<<21, mask=tab-1;vector<int>head(tab,-1),next(1u<<20);vector<U>keys(tab);unsigned used=0;
 auto loc=[&](U h){U v=h;v^=v>>33;v*=0xff51afd7ed558ccdULL;v^=v>>33;unsigned t=v&mask;while(head[t]!=-1 && keys[t]!=h)t=(t+1)&mask;return t;};
 auto save=[&](int m,U h){unsigned t=loc(h);next[m]=head[t];head[t]=m;keys[t]=h;};
 U hk=0;int active=0,cardinality=0;save(active,hk);for(int h=1;h<bit(20);h++){int t=__builtin_ctz(h),u=active&bit(t);U dd=delta[t][pext(active,nb0[t])]+(U(1)<<57);if(u){hk-=dd;cardinality--;}else{hk+=dd;cardinality++;}active^=bit(t);save(active,hk);}bool card[21]{};int numP=0;
 auto accept=[&](const Opt&k,int active){joinN++;U vis=k.P;for(int v=active;v;v&=v-1)vis|=U(1)<<f[__builtin_ctz(v)];assert(wt(vis)==14);
 V newF;int deg[11]={},oldTri[2048]={};for(int v=0;v<50;v++){if(!((vis>>v)&1))newF.push_back(o.F[v]);else for(int x=o.F[v];x;x&=x-1)if(!((vis>>o.nb[v][__builtin_ctz(x)])&1))newF.push_back((o.F[v]^(x&-x))|1024);}
 if(newF.size()!=76)return;for(int x:newF)for(int s=x;s;s=(s-1)&x){if(pc(s)==1)deg[__builtin_ctz(s)]++;if(pc(s)==3)oldTri[s]++;}
 bool ok=true;for(int i=0;i<11;i++){int w=i==B||i==10||i==k.c?40:42;if(deg[i]!=w)ok=false;}if(!ok)return;
 for(int s=0;s<2048;s++)if(pc(s)==3){bool hole=(s==(1024|mB|bit(k.c)));if((oldTri[s]!=0)==hole)ok=false;}if(!ok)return;proper++;
 if(emit){V star;out<<o.id<<' '<<B<<' '<<k.c<<' '<<k.d<<' '<<vis;out<<'\n';}
 };
 for(int c=B+1;c<10;c++){int d=c;U elig=sl[B]&~sl[c];assert(wt(elig)<=16);
 for(U P=elig;P;P=(P-1)&elig){int n=wt(P),count[10]={},aa[10]={},e=0;int cv=0;U least[20]={};int obs=0;
  for(U a=P;a;a&=a-1){int v=__builtin_ctzll(a);for(int j=0;j<10;j++)if(o.F[v]&bit(j)){count[j]++;int u=o.nb[v][j];if((P>>u)&1){if(v<u){for(int i=0;i<10;i++)if((o.F[v]&o.F[u]&bit(i)))aa[i]++;if((o.F[v]&o.F[u]&mB))e++;}}
     else if(j!=B){cv|=o.F[v]^bit(j);}else{int j0=fi[u];obs|=bit(j0);least[j0]+=Q[o.F[v]^mB];}}}
  // true A-B horizon contains every available old label except C.
  if(2*n-e!=5||cv!=(1023^bit(c)))continue;
  int n0=14-n;if(n0<0||n0>20)continue;numP++;card[n0]=true;
  U h=U(n0)<<57;for(int z=0;z<10;z++)if(z!=B){int target=z==c||z==d?5:6;
   h+=U((long long)target-2*count[z]+aa[z])*(U(1)<<(6*(z-(z>B))));}

  // sparse Gray update needs no per-pattern array
  U hh=h;unsigned last=0,t=0; // enumerate all subsets of obs, adding one edge correction per flip
  int pos[20],np=0;for(int m=obs;m;m&=m-1)pos[np++]=__builtin_ctz(m);
  for(int u=0;u<(1<<np);u++){if(u){int z=pos[__builtin_ctz(u)];if(t&bit(z))hh-=least[z];else hh+=least[z];t^=bit(z);}optionN++;unsigned j=loc(hh);
   for(int X=head[j];X!=-1;X=next[X])if(pc(X)==n0&&(X&obs)==t)accept(Opt{P,hh,n0,c,d,(int)t,obs},X);
  }
 }}PV+=numP;
}

int main(int ac,char**av){ifstream in(av[1]);int lo=stoi(av[2]),hi=stoi(av[3]);if(ac>4)out.open(av[4]);int id,n;while(in>>id>>n){Old o;o.id=id;o.F.resize(n);for(int&v:o.F)in>>v;if(id<lo||id>hi)continue;assert(n==50);for(int v=0;v<n;v++)for(int x=o.F[v];x;x&=x-1){int j=__builtin_ctz(x),r=o.F[v]^bit(j),z=-1;for(int u=0;u<n;u++)if(u!=v&&(o.F[u]&r)==r){assert(z<0);z=u;}assert(z>=0);o.nb[v][j]=z;}for(int B=0;B<10;B++)run(o,B,ac>4);seeds++;cerr<<"old "<<id<<" local B subsets "<<PV<<" match hashes "<<optionN<<" gray "<<look<<" hits "<<joinN<<" full consistent "<<proper<<endl;} }
