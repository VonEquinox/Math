#!/bin/sh
# Terminal target: source-independent check of all eight-star obligations and
# all E1-only exact metric masks. Upstream modes reconstruct either or both.
set -eu
cd "$(dirname "$0")/..";w=${WORK:-$(mktemp -d)};mkdir -p "$w/bin" "$w/terminal";if [ -z "${WORK:-}" ];then trap 'rm -rf "$w"' EXIT;fi
c=${CXX:-c++};b="$w/bin";q="$w/terminal";mode=${1:-};case "$mode" in ''|--horizon|--marked|--full);;*)exit 2;;esac
xz -dc CERTIFICATES/r9_s58_e1_alltypes.xz >"$w/T";xz -dc CERTIFICATES/r9_s58_e1_allrows.xz >"$w/R";xz -dc CERTIFICATES/r8_s58_e0_types.xz >"$w/T0";xz -dc CERTIFICATES/r8_s58_e0_cover.xz >"$w/C0";cp CERTIFICATES/r9_s58_e1_extra3916.txt "$w/C1"
(cd "$w";sha256sum -c <<'EOF'
598199b5d38d7d169c5a80fcdfca34235d907810f5aa4920fe62582f09e63b28  T
3e089bad9de11dfa2340f3dc9793c6716ec944e04d59b39836f743d9637eb371  R
2fae358159eb0e3aa7a489e58bd714ea2c90a6878821426236f98939f68c12c6  T0
a1ff41eff44fb81e5cc6e6c40d030ed9b5afcd48c470ead86a2479b1319da915  C0
EOF
)
python3 - "$w" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);T=(p/'T').read_bytes();U=(p/'T0').read_bytes();A=list(map(int,(p/'C0').read_text().split()));B=list(map(int,(p/'C1').read_text().split()));S=set(A+B)
assert T.startswith(U)and len(T)==68454*32 and len(U)==23204*32 and len(A)==5189 and len(B)==3916 and len(S)==9105 and min(S)>=1 and max(S)<=68454
(p/'selected').write_bytes(b''.join(T[32*i-32:32*i]for i in B));n=0
for r in(p/'R').open():
 i,*v=map(int,r.split());n+=1;assert i==n and len(v)==8 and v==sorted(v) and sum(t in S for t in v)>=2
assert n==369490
print('All 369490 eight-link obligations contain at least two of 9105 full types.')
PY
if [ "$mode" = --horizon ]||[ "$mode" = --full ];then
 seed=CERTIFICATES/r7_s60_horizon_51_seeds.txt;python3 CODE/r8_general_s58_visoldchi.py "$seed" >"$w/sign51"
 python3 - "$w" "$seed" <<'PY'
from pathlib import Path
import sys,hashlib
p=Path(sys.argv[1]);t=Path(sys.argv[2]).read_text().splitlines();g=(p/'sign51').read_text().splitlines();assert len(t)==len(g)==51
a=[];b=[]
for v,h in zip(t,g):
 s,k,*z=map(int,h.split());assert s==int(v.split()[0])and k in (0,1)and len(z)==k
 if k:a.append(v);b.append(h)
assert len(a)==37;(p/'old37').write_text('\n'.join(a)+'\n');(p/'sign37').write_text('\n'.join(b)+'\n')
assert hashlib.sha256((p/'old37').read_bytes()).hexdigest()=='1a7b9a4da89f76c1c6b6edce3de3f255594a9f9c337d06296a2d545c6a31214c'
PY
 for s in r8_general_s58_vis76flat r8_general_s58_vischi76quick r9_general_s58_e1verify;do "$c" -O3 -std=c++17 -w "CODE/$s.cpp" -o "$b/$s";done
 "$b/r8_general_s58_vis76flat" "$w/old37" 0 10000 /dev/stdout 2>"$w/vis.log" | "$b/r8_general_s58_vischi76quick" "$w/old37" "$w/sign37" 10000000 /dev/stdout 2>"$w/gp.log" | "$b/r9_general_s58_e1verify" "$w/old37" "$w/T" "$w/R" >"$w/verify" 2>"$w/verify.log"
 test "$(wc -l <"$w/vis.log")" -eq 37;tail -1 "$w/vis.log"|grep 'full consistent 3705994$';grep -q '^all 3705994 old balanced 3705994 facet-side propagation 3705994 old rank2 GP 1562520 ' "$w/gp.log"
 cat "$w/verify";grep -q '^all 1562520 E1 horizons, .*covering 12500160 local incidences; 369490 exact unordered eight-link rows; catalogue 68454 types validated$' "$w/verify"
fi
for s in r4_chord_concurrency r5_general_fasttree r7_general_mass_exactrect r6_general_closure r6_general_validate_slp;do "$c" -O3 -std=c++17 "CODE/$s.cpp" -o "$b/$s";done
"$c" -O3 -std=c++17 -DGROUPED_CLOSURE CODE/r6_general_closecheck.cpp -o "$b/bundle"
"$b/r4_chord_concurrency" 58 1000037 668900 "$w/buckets" >"$w/chord.log";python3 CODE/r4_chord_triples_exact.py 58 "$w/buckets" "$w/exact";python3 CODE/r5_general_patterns35.py 58 "$w/exact" >"$w/p";test "$(wc -l <"$w/p")" -eq 26040
gzip -dc CERTIFICATES/r9_s58_e1_full_support.gz >"$q/ms"
if [ "$mode" = --marked ]||[ "$mode" = --full ];then
 for s in r8_general_s58_streambi r3_geom_export r8_general_s58_intrinsic r8_general_s58_intrinsicjoin r5_general_markedjoin;do "$c" -O3 -std=c++17 "CODE/$s.cpp" -o "$b/$s";done
 sh CODE/r9_general_s58_selected32.sh "$b" "$w/selected" "$w/p" "$w/rebuilt";python3 CODE/r9_general_s58_classunion.py "$q/ms" -- "$w/rebuilt/ms"
fi
sh CODE/r9_general_s58_cohort_terminal.sh "$b" "$q" "$w/p"
python3 CODE/literature_exact_fold.py --verify 58
echo 'Given the preceding only-76 certificate, the regular 58-gon slack matrix has nonnegative rank 12.'
