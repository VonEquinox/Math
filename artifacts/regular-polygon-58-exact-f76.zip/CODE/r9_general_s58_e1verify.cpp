// Independently verify the complete all-root 76-facet horizon->8-link ledger.
// No use of production Star canonicalization. For a cache miss, construct all
// old/new ambient facets first, then find an actual ten-label facet bijection.
#define main oldmain_e0verify
#include "r8_general_s58_e0verify.cpp"
#undef main
struct Old{V f;vector<array<int,3>> ridge;U inc[10]{};};using Row=array<int,8>;
int main(int argc,char**av){ios::sync_with_stdio(false);cin.tie(nullptr);ifstream S(av[1]),T(av[2],ios::binary),rows(av[3]);int id,n,z;map<int,Old>S0;while(S>>id>>n){auto&o=S0[id];o.f.resize(n);for(int&m:o.f)S>>m;for(int i=0;i<n;i++){for(int m=o.f[i];m;m&=m-1)o.inc[__builtin_ctz(m)]|=U(1)<<i;for(int j=0;j<i;j++)if(w(o.f[i]&o.f[j])==5)o.ridge.push_back({i,j,(o.f[i]&o.f[j])|1024});}assert(o.ridge.size()==150);}
V masks;for(int i=0;i<1024;i++)if(w(i)==5)masks.push_back(i);Z bits;vector<Poly>P(1);unordered_map<U,V>B;
while(T.read((char*)bits.data(),32)){V a;for(int i=0;i<252;i++)if(bits[i/64]>>(i%64)&1)a.push_back(masks[i]);Poly p;p.set(a);for(int j:B[p.key])assert(!iso(p,P[j]));B[p.key].push_back(P.size());P.push_back(move(p));}
vector<Row>out;array<unordered_map<U,int>,10>cache;long long full=0,cuts=0;int last=-1,b,c,d;U vis;
while(cin>>id>>b>>c>>d>>vis){assert(c==d);if(last!=id){for(auto&a:cache)a.clear();last=id;}auto&o=S0.at(id);Row R;int j=0;V F;
for(int h=0;h<10;h++)if(h!=b&&h!=c){U m=vis&o.inc[h];auto[it,fresh]=cache[h].emplace(m,0);if(fresh){if(F.empty()){for(int i=0;i<50;i++)if(!(vis>>i&1))F.push_back(o.f[i]);for(auto[i,j,x]:o.ridge)if(((vis>>i)^(vis>>j))&1)F.push_back(x);assert(F.size()==76);}V v;for(int f:F)if(f>>h&1)v.push_back((f&((1<<h)-1))|((f>>(h+1))<<h));Poly p;p.set(v);int count=0;for(int k:B[p.key])if(iso(p,P[k])){it->second=k;count++;}assert(count==1);full++;}R[j++]=it->second;}assert(j==8);sort(R.begin(),R.end());out.push_back(R);if(++cuts%500000==0)cerr<<cuts<<" verified horizons\n";}
sort(out.begin(),out.end());out.erase(unique(out.begin(),out.end()),out.end());for(int j=0;j<out.size();j++){assert(rows>>z && z==j+1);for(int t:out[j]){assert(rows>>z && z==t);}}assert(!(rows>>z));cout<<"all "<<cuts<<" E1 horizons, "<<full<<" literal labelled f42 facet-bijection checks covering "<<8*cuts<<" local incidences; "<<out.size()<<" exact unordered eight-link rows; catalogue "<<P.size()-1<<" types validated\n";}
