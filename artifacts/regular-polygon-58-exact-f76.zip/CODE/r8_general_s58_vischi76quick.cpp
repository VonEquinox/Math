// Necessary oriented signs of A's uniform extension; safe even if old signs
// describe nonrealizable oriented matroids. Old chiro signs from independent
// balanced circuit enumeration. F75=complete graph, exactly ABC,ABD holes.
#include <bits/stdc++.h>
using namespace std;using U=uint64_t;using V=vector<int>;using A=__uint128_t;int pop(int m){return __builtin_popcount(m);}int lb(int m){return m&-m;}
struct Ridge{int t,f,g;array<pair<int,int>,5>L;};
struct Con{int t;array<int,5>x,p;array<int,32>allowed;array<short,243>tern;};
struct Rad{array<int,7>x,bit;int U0,p0;struct E{int r,neg;U mk,mi;};vector<E> pat;};
struct Seed{V F;array<U,1024>inc{};array<int,1024>c{};vector<Ridge>H;V X,sg;vector<Con>C;vector<Rad>R;vector<array<int,6>> G;bool dead=false;};
A read128(string s){A x=0;for(char c:s)x=10*x+(c-'0');return x;}
Seed start(V F,A sign){Seed s;s.F=F;int ct=0;for(int w=0;w<1024;w++)if(pop(w)==7)s.c[w]=(sign>>ct++)&1;
 for(int j=0;j<50;j++){int f=F[j];for(int t=f;t;t=(t-1)&f)s.inc[t]|=U(1)<<j;int h=lb(1023^f);s.X.push_back(f);s.sg.push_back(s.c[f|h]^(pop(f/(h<<1))%2));}
 for(int t=0;t<1024;t++)if(pop(t)==5){auto I=s.inc[t];if(I){assert(__builtin_popcountll(I)==2);int f=__builtin_ctzll(I);int g=__builtin_ctzll(I&(I-1));Ridge r;r.t=t;r.f=f;r.g=g;int x=F[f]^t,p=pop(t/(2*x))%2;int j=0;for(int u=(1023^t);u;u&=u-1){int y=lb(u);r.L[j++]={t|y,p^(pop(t/(2*y))%2)};}s.H.push_back(r);}
   Con a;a.t=t;int J[5],k=0;for(int u=1023^t;u;u&=u-1){J[k]=lb(u);a.x[k]=t|J[k];a.p[k++]=pop(t/(2*lb(u)))%2;}a.allowed.fill(0);
   for(int a0=0;a0<5;a0++){int q=0;for(int i=0;i<5;i++)if(i!=a0){int sg=s.c[t|J[i]|J[a0]]^(J[i]>J[a0])^(pop(t/(2*J[a0]))%2);q|=sg<<i;}
    for(int v:{q,q^(1<<a0)}){a.allowed[v]=a.allowed[31^v]=1;}}
   for(int i=0;i<243;i++){int p=i,mask=0,val=0;for(int z=0;z<5;z++,p/=3)if(p%3){mask|=1<<z;if(p%3==2)val|=1<<z;}
    short any=0,all=31,ok=0;for(int q=0;q<32;q++)if(a.allowed[q]&&((q^val)&mask)==0){any|=q;all&=q;ok=1;}a.tern[i]=ok?(((31^any)|all)&~mask)*32+all:-1;
   }s.C.push_back(a);}
 for(int t=0;t<1024;t++)if(pop(t)==7){Rad r;r.U0=t;r.p0=0;int j=0;for(int f=t;f;f&=f-1){int y=lb(f);r.x[j]=t^y;r.bit[j]=y;r.p0|=((j&1)^s.c[t])<<j;j++;}
  for(int g=0;g<128;g++)if(pop(g)==2||pop(g)==3){int N=0;for(int j=0;j<7;j++)if(g>>j&1)N|=r.bit[j];r.pat.push_back({g^r.p0,N,s.inc[N],s.inc[t^N]});}s.R.push_back(r);}
 // GPL for contractions on four old rows plus the new row A.
 for(int t=0;t<1024;t++)if(pop(t)==4){V w;for(int r=1023^t;r;r&=r-1)w.push_back(lb(r));for(int a=0;a<6;a++)for(int b=a+1;b<6;b++)for(int c=b+1;c<6;c++)for(int d=c+1;d<6;d++)
  s.G.push_back({t|w[a]|w[b],t|w[c]|w[d],t|w[a]|w[c],t|w[b]|w[d],t|w[a]|w[d],t|w[b]|w[c]});}return s;}
int main(int ac,char**av){ios::sync_with_stdio(false);cin.tie(nullptr);ifstream old(av[1]),chi(av[2]);map<int,Seed>S;int sd,n,ct;while(old>>sd>>n){V f(n);for(int&v:f)old>>v;int id;chi>>id>>ct;assert(sd==id&&(ct==0||ct==1));if(ct){string q;chi>>q;S[sd]=start(f,read128(q));}}
 int B,c,d;U vis;V H(38);long long num=0,live=0,rid=0,gp=0,rr=0,gp2=0,unk=0;int limit=ac>3?stoi(av[3]):INT_MAX;ostream* out=nullptr;ofstream file;if(ac>4){file.open(av[4]);out=&file;}
 while(num<limit&&cin>>sd>>B>>c>>d>>vis){num++;if(!S.count(sd))continue;live++;auto& old=S[sd];signed char x[1024];memset(x,-1,sizeof(x));
  for(int i=0;i<50;i++)x[old.X[i]]=old.sg[i]^(vis>>i&1);bool ok=true;
  for(auto&r:old.H)if(((vis>>r.f)^(vis>>r.g))&1){int base=x[old.F[r.f]];for(auto[k,h]:r.L){int v=base^h;if(x[k]!=-1&&x[k]!=v){ok=false;break;}x[k]=v;}if(!ok)break;}
  if(!ok)continue;rid++;bool repeat;
  do{repeat=false;for(auto&a:old.C){auto&i=a.x;int k=(1+x[i[0]])+3*(1+x[i[1]])+9*(1+x[i[2]])+27*(1+x[i[3]])+81*(1+x[i[4]]);
    int v=a.tern[k];if(v<0){ok=false;break;}for(int m=v>>5;m;m&=m-1){int j=__builtin_ctz(m);x[i[j]]=(v>>j)&1;repeat=true;}}
  if(!ok)break;
  }while(repeat);if(!ok)continue;gp++;
  // Stop after the rigorous old rank-two GP closure. The result is an outer cover.
  if(out){*out<<sd<<' '<<B<<' '<<c<<' '<<d<<' '<<vis;*out<<'\n';}
 }cerr<<"all "<<num<<" old balanced "<<live<<" facet-side propagation "<<rid<<" old rank2 GP "<<gp<<" new localized Radon-survivors "<<rr<<" new GP "<<gp2<<" nonfull sign assignments after propagation "<<unk<<"\n";
}
