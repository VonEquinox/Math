#!/usr/bin/env python3
"""Exact regular n-gon primal control, reconstructing the known reflection bound.
Columns U[:,t]/2 and rows V[t,:] are nonnegative factors of S. Internally:
X=exp(pi*i/(2*n)), arithmetic in Z[X]/(X**(2*n)+1), so no floats.
Returns a portable integer-angle description; --verify n indices (default n=25).
"""
import sys,json
from collections import defaultdict

def factor(n):
    if n<3: raise ValueError("n >= 3")
    R=list(range(1,2*n,2)); C=list(range(0,2*n,2)); m=n; stages=[]; terms=[]
    def sine_sign(q):
        u=q%(2*n)
        return 0 if u in (0,n) else 1 if u<n else -1
    def splus(q): # descriptor for 2 max(sin(pi*q/n),0)
        return ('2sin',q%(2*n)) if sine_sign(q)>0 else ('zero',)
    while m>4:
        axis=m-1; stages.append(axis)
        for eps in (1,-1):
            terms.append(([splus(eps*(q-axis)) for q in R],
                          [splus(-eps*(q-axis)) for q in C]))
        def fold(q):
            return (2*axis-q)%(2*n) if sine_sign(q-axis)>0 else q
        R=list(map(fold,R)); C=list(map(fold,C)); m=(m+1)//2
        assert sorted(set(C))==list(range(0,2*m,2))
        assert all(q%2 for q in R)
    for c in sorted(set(C)):
        terms.append(([('2slack',(q-c)%(2*n)) for q in R],
                      [('one',) if j==c else ('zero',) for j in C]))
    return stages,terms

def check(n, supplied=None):
    axis,terms=factor(n) if supplied is None else supplied
    assert all(len(U)==n and len(V)==n for U,V in terms)
    def poly(items): # reduce Laurent exponents using X**(2n)=-1
        co=defaultdict(int)
        for e,v in items:
            k,j=divmod(e,2*n);co[j]+=(-1 if k%2 else 1)*v
        return {j:v for j,v in co.items() if v}
    def ev(tok):
        if tok[0]=='zero': return {}
        if tok[0]=='one': return {0:1}
        q=tok[1]
        if tok[0]=='2sin': # 2 sin=(X^(2q)-X^(-2q))/i
            assert 0<q<n
            return poly([(2*q-n,1),(-2*q-n,-1)])
        assert tok[0]=='2slack' and q%2
        return poly([(2,1),(-2,1),(2*q,-1),(-2*q,-1)])
    uvs=[(list(map(ev,U)),list(map(ev,V))) for U,V in terms]
    for i in range(n):
        for j in range(n):
            s=poly((a+b,v*w) for U,V in uvs for a,v in U[i].items() for b,w in V[j].items())
            assert s==ev(('2slack',(2*i+1-2*j)%(2*n))),(n,i,j,s)
    k=(n-1).bit_length()
    sharp=2*k-int(4*n<=3*2**k)
    assert len(terms)==sharp
    return {'n':n,'fold_axes_in_pi_over_n':axis,'terms':len(terms),'identities_checked':n*n,'arithmetic':'Z[X]/(X^(2n)+1); no tolerance'}

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--check-certificate':
        with open(sys.argv[2]) as f: blob=json.load(f)
        assert blob['gauge']=='S=U*V/2'
        print(json.dumps(check(blob['n'],(blob['axes'],blob['summands'])),indent=2))
    elif len(sys.argv)>1 and sys.argv[1]=='--emit':
        n=int(sys.argv[2]);a,terms=factor(n);print(json.dumps({'n':n,'gauge':'S=U*V/2','axes':a,'summands':terms},separators=(',',':')))
    else:
        args=[int(x) for x in sys.argv[1:] if x!='--verify'] or [25]
        print(json.dumps([check(n) for n in args],indent=2))
