"""Recover possible rank-seven chirotopes of ten uniformly placed points using facet equalities and balanced old neighborly circuits. Never assumes rigidity without proof."""
from collections import Counter
from itertools import combinations
from pathlib import Path
import sys
ON=1023
masks=lambda k:[s for s in range(1024)if s.bit_count()==k]
B=masks(7)
from itertools import product
def solve(dom,ids,state,sol):
 while True:
  force={}
  for a,q in zip(dom,ids):
   old=state&q[0];v=state>>len(B)&q[0]
   elig=[m for m in a if (m&old)==v]
   if not elig:return
   any1,all1=0,q[0]
   for m in elig:any1|=m;all1&=m
   force0=(q[0]^any1)&~old;force1=all1&~old
   for s,x in ((force0,0),(force1,1)):
    while s:
     z=s&-s;s^=z
     if z in force and force[z]!=x:return
     force[z]=x
  if not force:break
  for z,x in force.items():state|=z|(x*z<<len(B))
 u=((1<<nc)-1)&~state
 if not u:
  sol.append(state>>len(B));return
 z=u&-u
 solve(dom,ids,state|z,sol);solve(dom,ids,state|z|(z<<len(B)),sol)
for line in open(sys.argv[1]):
 seed,n,*fac=map(int,line.split());d={s:s for s in B};sig={s:0 for s in B}
 def root(s):
  if d[s]!=s:
   p=d[s]; d[s],v=root(p);sig[s]^=v
  return d[s],sig[s]
 def link(s,t,v):
  i,a=root(s);j,b=root(t);
  if i!=j:d[j]=i;sig[j]=a^b^v
  else:assert a^b==v
 for f in fac:
  J=[(f|1<<i,(f>>(i+1)).bit_count()%2)for i in range(10)if not f>>i&1];s,v=J[0]
  for t,w in J[1:]:link(s,t,v^w)
 comps=sorted(set(root(s)[0]for s in B));nc=len(comps);D={r:1<<i for i,r in enumerate(comps)};dom=[];ids=[];F=set(fac);faces={s for s in masks(4) if any(s&f==s for f in fac)}
 for u in masks(8):
  J=[i for i in range(10)if u>>i&1]
  arr=[(D[r],v^(j&1)) for j,i in enumerate(J) for r,v in [root(u^1<<i)]]
  cc=sorted(set(d for d,_ in arr));vv=[]
  for bb in product([False,True],repeat=len(cc)):
   m=sum(d for d,b in zip(cc,bb)if b)
   pos=sum(1<<i for (d,v),i in zip(arr,J)if bool(m&d)^v)
   if pos.bit_count()==4 and not pos in faces and not (u^pos) in faces:vv.append(m)
  dom.append(vv);ids.append((sum(cc),))
 sol=[];solve(dom,ids,1,sol)
 print(seed,len(sol),*(sum(((int(bool(m&D[r]))^v)<<j)for j,s in enumerate(B) for r,v in [root(s)])for m in sol),flush=True)
