# Quantified metric robustness of the exact 33–36 lower bound

Let n=33,34,35,36. Let S be the right-cyclically labeled normalized
slack of another convex n-gon. Assume some positive row and column
rescalings arrange that at every positive cell
    (93/100) S_n[i,j] ≤ S[i,j] ≤ (107/100) S_n[i,j],
where S_n is the usual regular n-gon slack and the cyclic incidence
zeros coincide. Then **rank_+(S)≥11**. This does not assert an upper
bound of 11 away from the exactly regular polygon.

The exhaustive geometry admitted the possible width-ten support
templates for any convex target polygon, not only regular ones.
The exact regular terminal uses inequalities forced by two mandatory
private cells of the same rank-one term:
    S[a,b] S[i,j] ≤ S[a,j] S[i,b].
Repeat every original metric test with a stronger threshold, rejecting
only if the lower estimated regular left product is strictly greater
than 4/3 times the upper estimated right product. Directed rational
sine enclosures with scale 10^21 and integer product comparison are
used. Every one of the 18,743,581 / 462,838 / 6,946 / 42 candidate
alignments is still rejected. Because (107/93)^2<4/3, every selected
witness remains a strict contradiction after the stated perturbation.
If positive scaling of entries changes each row/column, the four
product ratio is unchanged, so this is a projective slack statement.
Cyclic reindexing and reversing the polygon reorder both matrices
within the same comparison box, preserving this conclusion.

A geometric sufficient condition is that all vertices of the convex
polygon lie on a circle with individual angular errors at most 1/600
radian (about 0.095 degrees) from equally spaced angles, after a shared
rotation. Scale radius to one. For a genuine side through neighboring
vertices the unit-normal slack equals twice the product of the two
sines of half the angular differences to those endpoints. On positive
cells the regular sine factors are at least sin(π/n)≥2/n≥1/18.
Each half-difference changes by at most 1/600, so each sine factor
changes relatively by at most .03. Their product stays between
.97² and 1.03² of its regular value, lying strictly in [.93,1.07].
The cyclic side/vertex order does not change under this perturbation.

This result quantifies openness of the regular lower bound, but
the explicit tolerance is not enough to identify arbitrary subsets
of the 49-grid with 33-, 34-, or 35-gons. Do not infer deletion
monotonicity for regular polygons from this theorem.

Replay: generate the strict product table with
    python3 CODE/r4_metric_compare.py n output.bin 4/3
and feed the complete ordered support templates of that target to
CODE/r4_metric_leaf.cpp (from the 25–48 master mathematical proof).
Recorded strengthened counts are CERTIFICATES/r5_robust33_36.txt.
