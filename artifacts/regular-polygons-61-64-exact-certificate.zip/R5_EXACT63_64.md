# Exact nonnegative rank 12 for the regular 63- and 64-gons

This is a finite computer-assisted proof. The full regular-polygon
formula is not resolved; in particular the regular 49-gon still has
rank either 11 or 12. The proved 25–48 range and the classification
inputs used here were delivered separately in the master archive
regular-polygons-25-48-exact-certificate.zip.

## Width-eleven deletion reduces both cases to 35 marked vertices

Write P_n for the regular polygon and S_n for its slack matrix.
The exact folding upper bound U(n) is 12 at n=63 and 64, with direct
cyclotomic identity rechecks in CERTIFICATES/r5_upper63_64_exact.txt.
Suppose instead that the regular polygon admitted width at most eleven.
Width ten cannot yield more than 36 corners, by the previous exact
geometric theorem (also sharp on an irregular rational example).

The two affine orthant lifts from an eleven-term factorization have
dimension sum at most 12 by Sylvester and rank(S_n)=3. On the smaller
side, polarity gives a polytope Q with eleven vertices in dimension
at most six whose interior plane section is the regular polygon up
to rotation and uniform scaling (the polar is also regular).
Dimension at most five permits at most 56 simplex facets by the cyclic
upper bound theorem, too few; equivalently, apply that bound after
generic ambient perturbation. Thus Q is six-dimensional.

Perturb the eleven ambient vertices to general position. The planar
sections converge in Hausdorff distance, and choose one approaching
corner for each of the n distinctly exposed regular corners in
disjoint neighborhoods. A perturbed section corner is supported on
a five-label ridge of the six-dimensional ambient polytope. It
survives six of the eleven single-label deletions, remaining strictly
exposed in the smaller section. The average retained marked count
is 6n/11, so some deletion retains at least 35 marked corners. Every
deletion polygon has width at most ten and consequently at most 36
corners. Pass to a subsequence fixing the chosen deletion label,
the 35 regular marked corner labels, and any at most one extra
vertex (bounded). The limiting polygon has 35 or 36 corners, contains
the 35 marked distinct grid points as vertices, and still has
extension complexity at most ten. Indeed select convergent exposed
corner and support-edge representatives in the approximants; their
slacks converge, and nonnegative rank at most ten is closed under
limits after normalizing each nonzero factor column to sum one.
If the extra vertex becomes redundant the same argument just takes
the slack submatrix for the remaining strict corners and edges.

It remains to exclude a width-ten polygon with 35 specified grid
vertices chosen in any positions of the regular n-grid and at most
one more unknown corner.

## All geometric templates and concurrency constraints

The previous exhaustive width-ten geometry gives 1,066 generic
35-corner and 42 generic 36-corner support cycles. Smaller dimensions
cannot realize either threshold. The complete high-length tail
of those raw catalogs is preserved as
CERTIFICATES/r5_general_full35raw.txt.gz. Importantly, the lists are
upper covers rather than claims of realizability. Each row mask is
the complement of a supporting ambient facet; each column mask is
an ambient corner ridge. A true slack factorization has no positive
coefficients outside these masks, including in degenerate limits.
Both polarities of every cycle are checked.

If the actual polygon has 35 corners and the generic cycle has 36,
choose the 35 approximating rows and columns in their alternating
boundary order. Exactly one adjacent row/column pair is omitted
(either neighbor of the dropped column). This selection is guaranteed
by choosing corners and the relative interior of edges in disjoint
angular neighborhoods in the perturbation. If a 36-corner polygon
has one unknown extra vertex, rotate so that extra vertex closes the
list. Drop its column and both incident sides; use an unconstrained
row mask for the artificial closing chord (it gives no singleton
entries). The remaining 34 genuine side rows pertain exactly to the
marked grid columns. The combined number of possibilities is
    2*1066 + 42*2*36*3 = 11204.
The generator explicitly visits every one.

If all four positions in two slack rows i,h and two columns j,k are
positive and permitted in one and the same single label, their
2-by-2 determinant is zero. The supporting lines of the two rows
and the chord through j,k must therefore be concurrent in the
projective plane: the two row forms restricted to the two-dimensional
span of the homogeneous column vectors are linearly dependent.
Distinct supporting lines remain distinct. If two of the three
chords share an endpoint but the third does not, the relation is
impossible (a line cannot contain three distinct conic vertices).
For disjoint endpoints, use the exact grid tables below.

Group the resulting conjunctions of chord constraints by simultaneous
dihedral permutations of the 35 marked indices. This yields 4,361
systems; keep ALL geometry/mask provenance for each, not just a
representative. Exact finite-domain propagation and search rules
out 4,360 at n=63 and 4,359 at n=64. There are no unresolved budgets.
For n=63 the sole surviving system comes from four raw cycles in
polarity 1. For n=64, there are four raw cycles in each polarity.
Every one of these backlinks has no omitted corner and comes from
the same 35-corner mask pair up to physical dihedral and latent-label
isomorphism. The complete provenance and the actual literal masks
are checked in CODE/r5_verify_type260_coverage.py and stored in
CERTIFICATES/r5_general_type260_masks.json.

The domain model is exact: after rotating the physical grid, write
the marked angles x_i=i+d_i, x_0=0, with d_i nondecreasing in
[0,N−35]. For each ordered six-tuple, the chord table lists all
relative gaps, so translate it through every compatible origin.
Intersection of possible projections to each one-variable domain
cannot cut a true solution; splitting non-singletons exhausts the
remaining finite possibilities.

## Necessary equations from the mixed cells

For label t, the positive private slack positions define a bipartite
graph on rows/columns. If a mixed positive cell (i,j) is connected
by a path of private positions bearing t, its t-th summand is the
alternating product/quotient of the known path values (the path has
odd length). When every allowed label is determined, the sum of these
expressions equals the slack at (i,j). Divide by that positive slack.

For marked points at angles x_i on the N-grid, put z_i=ζ_N^x_i and
write [a,b]=z_b−z_a for a<b in the marked cyclic order after unwrapping.
Up to a positive row scaling the actual slack at side i and point j is
the absolute sine product for chords (i,j) and (i+1,j). In any of the
above normalized path quotient expressions, row and column factors
cancel separately; in particular the sum of bracket exponents at
every physical vertex is zero. Thus replacing every absolute sine
by its ordered bracket preserves the products (all complex phases
and factors 2i cancel). The conclusion is unchanged by wrapping
angles by N as long as their original marked order is unwrapped.
For example, in polarity 1 the compulsory normalized equation at
(33,8) is
    1 = [7,34][8,32]/([7,32][8,34])
      + [32,33][32,34][8,10][8,11]/([10,32][11,32][8,33][8,34]).
Exact necessity can be replayed by constructing the private paths
from the two support masks, without taking this formula on trust.

If q has exact order N in F_p, with p prime and p∤N, reduction
ζ_N↦q preserves every such equation after clearing denominators.
Every bracket in a denominator is nonzero (distinct grid marks,
distinct powers of q). In independent replay with different primes
and direct enumeration of only the partial gap assignments needed,
the final masks yield:

| N | polarity | admissible first six anchors | tested mixed-cell projections and result |
|---:|---:|---:|---|
|63|0|0|none|
|63|1|572|(33,8): 162,162 tested, 0|
|64|0|150|(8,34): 33,684 tested, 0|
|64|1|683|(33,8): 192,984 tested, 18; (33,10): 302 tested, 0|

Other exact replays choose more intermediate variables but also
leave no survivor. Hence no width-11 lift is possible for S63 or
S64, and both have exact nonnegative rank 12.

## Exact chord-table source

In homogeneous coordinates (1,z,z^-1), a chord through two distinct
grid points a,b is the projective line (−z_a−z_b,1,z_a z_b).
Intersect every pair of distinct such lines over F_p, normalize
and hash the projective point. Each true zero determinant survives
reduction by the primitive-root argument, and all chord lines are
still distinct in the field. Hence any actual concurrent triple is
among buckets with at least three chords. Extract the triples with
six distinct endpoints, normalize the smallest marked angle to zero,
then validate every candidate determinant as an ordinary cyclotomic
polynomial identity modulo Φ_N. No geometric floating point is used.
The resulting tables for N=63 and 64 and the prime/root choices are
provided. CODE/r4_chord_concurrency.cpp and
CODE/r4_chord_triples_exact.py regenerate them offline.
