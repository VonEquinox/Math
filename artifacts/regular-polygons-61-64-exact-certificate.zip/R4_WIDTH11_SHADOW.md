# Universal deletion bound: width 11 implies at most 66 polygon corners

Let M_r be the maximum vertex count of a convex polygon that is a
projection of a polytope with at most r facets. For r with d≥2, we have
    M_r ≤ floor( r M_(r−1) / ceil((r+1)/2) ).
Using the exhaustive M_10≤36 proof, this gives M_11≤66. Thus any convex
polygon with 67 or more corners has extension complexity at least 12.
This does not prove exactness in the conjectured width-12 regular band
n=49,…,64 or the next conjectured width-13 band.

**Rank-balanced ambient dimension.** If a polygon has an r-term slack
factorization, the two factor affine-orthant lifts have dimensions
rank(U)−1 and rank(V)−1. One projects to the polygon and the other to its
polar (and positive coordinate rescaling preserves the face count).
Sylvester and ordinary slack rank 3 give dimension sum ≤r+1, so one
lift has d≤floor((r+1)/2). By ambient polarity its dual Q has at most r
vertices and a 2-plane section with n corners. If Q already has fewer
than r vertices, the M_(r−1) bound applies directly.

**Deletion count.** Take a sufficiently small generic perturbation so
Q is simplicial and the section remains at least n corners; the origin
remains ambient-interior and the perturbation does not enlarge d or r.
Each actual generic section vertex cuts the relative interior of a
(d−2)-face, with d−1 ambient vertex labels. Delete any other ambient
vertex and the section corner is still an exposed extreme point (it
belongs to the restricted section and restricting keeps extreme points).
Summed over all r possible deletions, at least (r−d+1)n old corners
are retained. Every deletion section has at most M_(r−1) corners: if
it is two-dimensional, polarize in the affine span of the smallest
ambient face containing it, choosing a point in their common relative
interior as origin. That face has at most r−1 vertices. Its polar has
at most r−1 facets and projects to the polar polygon. If the section
has dimension less than two it has at most two corners, and the bound
is automatic. Thus
    (r−d+1)n≤r M_(r−1),  r−d+1≥ceil((r+1)/2).

**Width 11 near equality.** For a 66-corner candidate in d=6 every
label appears in exactly 30 of the five-label corner supports; deletion
of every label retains exactly 36 old corners and creates none. Any
pair of consecutive retained supports in a deletion differs by one
label, because they lie in a common simplex facet of the deletion.
For 65 or 66 corners there is also a general budget: let D_a sum the
Johnson distances, |A∖B|, between consecutive retained corner
supports cyclically after discarding the corners incident with a.
Each D_a≤36, since the true deletion path between the retained corners
pivots one label per transition. Across all deletion labels, untouched
original transitions contribute 5n; bridged runs contribute ≥n because
each original step adds one label and starts one discarded run. Hence
    6n≤sum D_a≤396.
The possible excess over 6n is 0 for n=66 and at most 6 for n=65. These
conditions have not yet been used to rule out either n.
