#!/usr/bin/env python3
"""Check the full 35/36-cycle roster and every backlink to a surviving case."""
from collections import Counter
import argparse,gzip,json,re
def lines(path):
    op=gzip.open if path.endswith('.gz') else open
    with op(path,'rt') as f:return [tuple(map(int,l.split())) for l in f]
def canon(r,c):
    N=len(r)
    best=None
    for s in (1,-1):
        for d in range(N):
            k=[]
            for t in range(10):
                q=sum(1<<((i*s+d-(s<0))%N) for i,v in enumerate(r) if v>>t&1)
                z=sum(1<<((i*s+d)%N) for i,v in enumerate(c) if v>>t&1)
                k.append((q,z))
            k=tuple(sorted(k))
            best=k if best is None else min(k,best)
    return best
def main():
    p=argparse.ArgumentParser();p.add_argument('all35');p.add_argument('back')
    p.add_argument('join63');p.add_argument('join64');p.add_argument('masks')
    a=p.parse_args()
    orig=lines(a.all35)
    full=Counter()
    for n in (34,36,38,40,42):
        fn=f'CERTIFICATES/r4_s33_low{n}_templates.gz' if n<40 else f'CERTIFICATES/r3_geom_{n}_templates.gz'
        full.update(x for x in lines(fn) if x[1]>=35)
    assert Counter(orig)==full
    q=json.load(open(a.masks))
    cc={int(s):canon(d['r'],d['c']) for s,d in q.items()}
    records=lines(a.back);assert len(records)>0
    for N,lg in [(63,a.join63),(64,a.join64)]:
        got={}
        out=open(lg).read()
        R=re.search(r'total=(\d+) unsat=(\d+) budget=(\d+) candidates=(\d+)',out)
        assert R
        a0,b,c,d=map(int,R.groups());assert c==0 and b+d==a0
        for x in out.splitlines():
            if 'status=candidate' not in x:continue
            i=int(x.split()[0]);got[i]=0
        assert d==len(got)
        detail=Counter()
        for x in records:
            m,gid,shape,sw,tag,z=x
            if m not in got:continue
            got[m]+=1
            assert tag==0 and z==-1
            id,k,*S=orig[gid-1]
            assert id==shape and k==35
            r,c=S[:k],S[k:]
            if sw:r,c=c[1:]+c[:1],r
            assert canon(r,c)==cc[sw],(m,gid,sw)
            detail[sw]+=1
        assert min(got.values(),default=0)>0
        print(N,'input loops',len(orig),'systems',a0,'passes',d,'backlinks by genuine parity',dict(detail))
if __name__=='__main__':main()
