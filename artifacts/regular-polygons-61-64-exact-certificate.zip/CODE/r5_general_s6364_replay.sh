#!/bin/sh
# Replay the exact S63/S64 post-census proof. Optional arg "full" checks prior
# width-ten geometry exports too. Optional second arg "regenerate64" recomputes
# the exact N64 chord table in stdlib from field intersections + cyclotomics.
set -eu
cd "$(dirname "$0")/.."
w=$(mktemp -d)
trap 'rm -rf "$w"' EXIT HUP INT TERM
cxx=${CXX:-g++}
$cxx -O3 -std=c++17 CODE/r4_general_35templates.cpp -o "$w/emit"
$cxx -O3 -std=c++17 CODE/r5_general_gridjoin.cpp -o "$w/join"
gzip -dc CERTIFICATES/r5_general_full35raw.txt.gz > "$w/input"
"$w/emit" "$w/input" "$w/back" > "$w/systems"
if [ "${2:-}" = regenerate64 ]; then
 $cxx -O3 -std=c++17 CODE/r4_chord_concurrency.cpp -o "$w/buckets"
 "$w/buckets" 64 110000833 95103220 "$w/chords"
 python3 CODE/r4_chord_triples_exact.py 64 "$w/chords" "$w/64checked"
 gzip -dc CERTIFICATES/r5_general_64patterns.txt.gz > "$w/64reference"
 cmp "$w/64checked" "$w/64reference"
fi
for n in 63 64; do
 python3 CODE/r5_general_patterns35.py "$n" CERTIFICATES/r5_general_64patterns.txt.gz > "$w/p$n"
 "$w/join" "$w/p$n" "$w/systems" 100000 "$n" > "$w/j$n"
 tail -1 "$w/j$n"; cmp "$w/j$n" "CERTIFICATES/r5_general_gridjoin$n.txt"
done
python3 CODE/r5_general_type260_iso.py "$w/input" "$w/back" "$w/j63" "$w/j64" CERTIFICATES/r5_general_type260_masks.json
if [ "${1:-}" = full ]; then
 python3 CODE/r5_verify_type260_coverage.py "$w/input" "$w/back" "$w/j63" "$w/j64" CERTIFICATES/r5_general_type260_masks.json
fi
python3 CODE/r5_general_gridmass_verify.py > "$w/mass"
cmp "$w/mass" CERTIFICATES/r5_general_gridmass_independent.txt
cat "$w/mass"
