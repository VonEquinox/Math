from collections import Counter,defaultdict
from itertools import combinations,product
import json,sys,math
from pathlib import Path

def pattern(X):
 G=sorted({i for t in X for i in t});return tuple(sorted(tuple(sorted((G.index(i),G.index(j))))for i,j in X))
def nodetable(N):
 T=defaultdict(set)
 if N==63:
  for s in range(1,N):
   C=[(i,j)for i in range(1,N)for j in [(s-i)%N]if 0<i<j and s not in(i,j)]
   for a,b in combinations(C,2):
    X=[(0,s),a,b];I=tuple(sorted(sum((list(x)for x in X),[])));assert len(set(I))==6;T[pattern(X)].add(I)
 else:
  for l in open('/tmp/r4_regular64_matching_exact.txt'):
   z=list(map(int,l.split()));X=[(z[i],z[i+1])for i in (0,2,4)];T[tuple(X)].add(tuple(z[6:]))
 return T

def field(N):
 for q in range(100000+(1-100000)%N,10**7,N):
  if any(q%i==0 for i in range(2,math.isqrt(q)+1)):continue
  for a in range(2,q):
   if pow(a,N,q)==1 and all(pow(a,k,q)!=1 for k in range(1,N)):return q,a

def run(N,sw,formsfile):
 z=next(v for v in json.load(open('/tmp/r4_general_k35_fullodd.json'))if v['sw']==sw);n=35;eq=z['e'][0];I=sorted(eq);o=I[0];rel=lambda t:(t-o)%n;P=pattern([(eq[t],eq[t+1])for t in(0,2,4)]);S=nodetable(N)[P];q,a=field(N);R=[pow(a,j,q)for j in range(N)];ms=json.load(open(formsfile));
 for m in ms:
  m['vs']={i for t in m['t']for u,v,c in t for i in(u,v)}
 def compatible(anch):
  A=sorted((rel(i),j)for i,j in anch.items());return A[0]==(0,0) and all(d-c>=b-a for (a,c),(b,d)in zip(A,A[1:]+[(n,N)]))
 def val(m,anch):
  V=0
  for f in m['t']:
   v=1
   for i,j,p in f:
    t=(R[anch[j]]-R[anch[i]])%q;assert t;v=v*pow(t,p,q)%q
   V=(V+v)%q
  return V==1
 pool=[dict(zip(I,v)) for v in S if compatible(dict(zip(I,v)))];print('case',N,sw,'p/root',q,a,'anchors',len(pool),flush=True);used=[]
 for step in range(10):
  if not pool:break
  known=set(pool[0]);new=min((m for m in ms if (m['i'],m['j'])not in used),key=lambda m:(len(m['vs']-known),m['s'],m['i'],m['j']));U=sorted(new['vs']-known);used.append((new['i'],new['j']));
  if len(U)>3: print('stop: need variables',U);break
  states=[];tested=0
  for st in pool:
   Ds=[[a for a in range(N)if compatible(st|{u:a})]for u in U]
   for v in product(*Ds):
    d=st|dict(zip(U,v));
    if not compatible(d):continue
    tested+=1
    if val(new,d):states.append(d)
  pool=states;print(new['i'],new['j'],'new',U,'tested',tested,'pass',len(states),flush=True)
 return pool
if __name__=='__main__':
 N=int(sys.argv[1]);sw=int(sys.argv[2]);run(N,sw,sys.argv[3])
