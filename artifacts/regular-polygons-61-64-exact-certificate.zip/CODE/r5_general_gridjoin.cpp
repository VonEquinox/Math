// Join all modular six-endpoint concurrence tables on an integer cyclic grid.
#include <algorithm>
#include <array>
#include <vector>
#include <iostream>
#include <fstream>
#include <map>
#include <set>
#include <cassert>
#include <cstdint>
using namespace std;using W=uint64_t;using A=array<int,6>;using Tiny=array<uint8_t,6>;
int N=66,n,E,limit,loading=0;W nodes;bool abortd=false;W bit(int n){return W(1)<<n;}int first(W v){return __builtin_ctzll(v);}int last(W v){return 63-__builtin_clzll(v);}int pc(W v){return __builtin_popcountll(v);}using State=array<W,65>;
int sig(const A&p,const A&ordered){array<pair<int,int>,3>c;for(int j=0;j<3;j++){int a=lower_bound(ordered.begin(),ordered.end(),p[2*j])-ordered.begin(),b=lower_bound(ordered.begin(),ordered.end(),p[2*j+1])-ordered.begin();assert(a<6&&b<6);c[j]=minmax(a,b);}sort(c.begin(),c.end());int q=0;for(auto [a,b]:c)q=(q*6+a)*6+b;return q;}
struct Rel{A inds;vector<Tiny>tab;};vector<Rel>rels;int deg[65];map<int,vector<A>>table;
bool prop(State&D){bool ch=true;while(ch){ch=false;auto put=[&](int i,W w){W z=D[i]&w;if(z!=D[i])ch=true;return (D[i]=z)!=0;};for(int i=0;i+1<n;i++){int l=first(D[i]);if(!put(i+1,~(bit(l)-1)))return false;}for(int i=n-1;i>0;i--){int u=last(D[i]);if(!put(i-1,bit(u+1)-1))return false;}for(const auto&q:rels){W s[6]={};bool ok=false;for(auto &a:q.tab){bool z=true;for(int j=0;j<6;j++)if(!(D[q.inds[j]]&bit(a[j]))){z=false;break;}if(z){ok=true;for(int j=0;j<6;j++)s[j]|=bit(a[j]);}}if(!ok)return false;for(int j=0;j<6;j++)if(!put(q.inds[j],s[j]))return false;}}
return true;}
bool dfs(State d,vector<int>&wit){if(++nodes>(W)limit){abortd=true;return false;}if(!prop(d))return false;int j=-1;double cur=1e90;for(int i=0;i<n;i++)if(deg[i]&&pc(d[i])>1){double b=double(pc(d[i])*pc(d[i]))/deg[i];if(b<cur)cur=b,j=i;}if(j<0){for(int i=0;i<n;i++)wit.push_back(i+first(d[i]));return true;}W b=d[j],q=0;for(int t=0;t<pc(d[j])/2;t++){int k=first(b);q|=bit(k);b&=b-1;}auto e=d;e[j]=q;if(dfs(e,wit))return true;if(abortd)return false;d[j]=b;return dfs(d,wit);}
int main(int ac,char**av){if(ac<3)return 2;if(ac>4)N=stoi(av[4]);ifstream patterns(av[1]),cases(av[2]);if(ac>3)limit=stoi(av[3]);else limit=100000;A p;while(patterns>>p[0]>>p[1]>>p[2]>>p[3]>>p[4]>>p[5]){A a=p;sort(a.begin(),a.end());assert(a[0]==0&&a[5]<N&&adjacent_find(a.begin(),a.end())==a.end());table[sig(p,a)].push_back(a);}int ncase;cases>>n>>ncase;assert((n==35||n==36)&&table.size()&&N-n<63);E=N-n;int passed=0,failed=0,budget=0;for(int z=0;z<ncase;z++){int uid,src,sw,rot,nq;cases>>uid>>src>>sw>>rot>>nq;rels.clear();bool bad=false;fill(deg,deg+n,0);for(int t=0;t<nq;t++){for(int&v:p)cases>>v;A a=p;sort(a.begin(),a.end());if(adjacent_find(a.begin(),a.end())!=a.end()){bad=true;continue;}Rel q;q.inds=a;for(int i:a)deg[i]++;for(auto &b:table[sig(p,a)]){A d;for(int j=0;j<6;j++)d[j]=b[j]-a[j]+a[0];if(!is_sorted(d.begin(),d.end())||d[5]>E)continue;int mx=a[0]?E-d[5]:0;for(int add=0;add<=mx;add++){Tiny l;for(int j=0;j<6;j++)l[j]=d[j]+add;q.tab.push_back(l);}}if(q.tab.empty())bad=true;rels.push_back(move(q));}
 sort(rels.begin(),rels.end(),[](auto&a,auto&b){return a.tab.size()<b.tab.size();});nodes=0;abortd=false;State d;d.fill(bit(E+1)-1);d[0]=1;vector<int>ans;bool ok=!bad&&dfs(d,ans);if(ok)passed++;else if(abortd)budget++;else failed++;cout<<uid<<' '<<src<<' '<<sw<<' '<<rot<<" constraints="<<nq<<" relation_range="<<(rels.empty()?0ul:rels.front().tab.size())<<','<<(rels.empty()?0ul:rels.back().tab.size())<<" nodes="<<nodes<<" status="<<(ok?"candidate":abortd?"budget":"unsat");if(ok)for(int v:ans)cout<<' '<<v;cout<<endl;}cout<<"total="<<ncase<<" unsat="<<failed<<" budget="<<budget<<" candidates="<<passed<<'\n';}
