// Finite necessary test on any anchored collection of mixed identities.
// Random assignments discard tautologies ONLY (dropping constraints is safe).
// On a budget or large scope we explicitly retain unresolved, never UNSAT.
#include <bits/stdc++.h>
using namespace std;using U=uint64_t;using State=array<int8_t,40>;struct Term{int s;vector<pair<int,int>> fac;};struct Con{int type,i,j;U mask;vector<int>V;array<int,6> E;vector<Term> T;};int K,N,P,E,D[8][75][75],emb=0,num=0,root,base,at,cap=3000000,bcap=300000;long long tries;bool abortd;vector<Con> all;vector<State> New;mt19937 gen(3417);
int power(int a,int b){int r=1;while(b){if(b&1)r=r*a%P;a=a*a%P;b/=2;}return r;}
void init(){for(P=2;P<16000;P++){if((P-1)%N)continue;bool ok=true;for(int d=2;d*d<=P;d++)if(P%d==0)ok=false;if(ok)break;}assert(P<16000);for(root=2;root<P;root++){set<int>S;for(int i=0;i<N;i++)S.insert(power(root,i));if(S.size()==N&&power(root,N)==1)break;}assert(root<P);for(int e=1;e<N&&emb<8;e++)if(gcd(e,N)==1){int z=power(root,e),R[75];for(int i=0;i<N;i++)R[i]=power(z,i);for(int i=0;i<N;i++)for(int j=0;j<N;j++)D[emb][i][j]=(R[j]-R[i]+P)%P;emb++;}}
bool passes(const Con&c,const State&x){if(c.type==0){auto z=c.E;if(N%2){int v=(x[z[0]]+x[z[1]])%N;return v==(x[z[2]]+x[z[3]])%N&&v==(x[z[4]]+x[z[5]])%N;}
 // Determinant of chords (1,-(z1+z2),z1*z2) in the conic; evaluate all embeddings.
 for(int e=0;e<emb;e++){int a[3],b[3];for(int k=0;k<3;k++){int u=(1+D[e][0][x[z[2*k]]])%P,v=(1+D[e][0][x[z[2*k+1]]])%P;a[k]=(u+v)%P;b[k]=u*v%P;}if(((a[1]-a[0])*(b[2]-b[0])-(a[2]-a[0])*(b[1]-b[0]))%P)return false;}return true;
 }for(int e=0;e<emb;e++){int sum=0;for(auto&t:c.T){int v=t.s;for(auto [i,j]:t.fac)v=v*D[e][x[i]][x[j]]%P;sum+=v;}if(sum%P)return false;}return true;}
int relative(int i){return(i-base+K)%K;}
void rec(State&x,vector<int>&V,int l){if(abortd)return;if(l==(int)V.size()){if(++tries>cap){abortd=true;return;}if(passes(all[at],x)){New.push_back(x);if(int(New.size())>bcap)abortd=true;}return;}
 int j=V[l],q=relative(j),lo=q,hi=E+q;for(int i=0;i<K;i++)if(x[i]>=0){int t=relative(i);if(t<q)lo=max(lo,int(x[i])+q-t);else hi=min(hi,int(x[i])+q-t);}for(int v=lo;v<=hi&&!abortd;v++){x[j]=v;rec(x,V,l+1);}x[j]=-1;}
bool solve(int nc){if(all.empty()){cout<<" unresolved=empty";return false;}std::stable_sort(all.begin(),all.end(),[](const Con&a,const Con&b){return make_tuple(a.type,a.V.size())<make_tuple(b.type,b.V.size());});int first=0;
 // Pick a six-anchor equality when available; otherwise the smallest genuine mixed identity. All cyclic orders and unused fillers are still allowed.
 base=all[first].V[0];vector<State>st(1);st[0].fill(-1);st[0][base]=0;U known=1ull<<base;vector<bool>used(all.size());int steps=0;
 while(steps<min(nc,int(all.size()))){int bi=-1;tuple<int,int,int,int>score{100,10000,0,0};for(int i=0;i<(int)all.size();i++)if(!used[i]){auto&c=all[i];int vars=__builtin_popcountll(c.mask&~known);int deg=0;for(auto&t:c.T)deg+=t.fac.size();auto u=make_tuple(vars,c.type,int(c.V.size()),deg);if(u<score){score=u;bi=i;}}
 if(bi<0)break;at=bi;used[at]=1;tries=0;abortd=false;New.clear();vector<int>Uj;for(int i:all[at].V)if(!(known>>i&1))Uj.push_back(i);sort(Uj.begin(),Uj.end(),[](int i,int j){return relative(i)<relative(j);});
 for(auto&x:st){rec(x,Uj,0);if(abortd)break;}cout<<" |"<<all[at].type<<':'<<all[at].i<<','<<all[at].j<<':'<<Uj.size()<<':'<<tries<<':'<<New.size();steps++;
 if(abortd){cout<<" budget";return false;}if(New.empty()){cout<<" EMPTY";return true;}st.swap(New);known|=all[at].mask;
 }cout<<" surviving";return false;}
int main(int ac,char**av){if(ac<2)return 2;ifstream f(av[1]);int nc;f>>K>>N>>nc;init();E=N-K;int lo=ac>2?atoi(av[2]):0,hi=ac>3?atoi(av[3]):nc,lim=ac>4?atoi(av[4]):24;if(ac>5)cap=atoi(av[5]);int fail=0,done=0;cout<<"K "<<K<<" N "<<N<<" p "<<P<<" root "<<root<<" embeddings "<<emb<<endl;for(int a=0;a<nc;a++){int idx,ne,nm;f>>idx>>ne>>nm;all.clear();for(int i=0;i<ne;i++){Con c{};for(int&v:c.E){f>>v;c.mask|=1ull<<v;}for(int j=0;j<K;j++)if(c.mask>>j&1)c.V.push_back(j);c.i=i;all.push_back(c);}
 for(int i=0;i<nm;i++){Con c{};int h,t;f>>h>>t>>c.i>>c.j;c.V.resize(h);for(int&v:c.V){f>>v;c.mask|=1ull<<v;}c.type=1;for(int j=0;j<t;j++){Term x;int s;f>>x.s>>s;x.fac.resize(s);for(auto&u:x.fac)f>>u.first>>u.second;c.T.push_back(move(x));}if(idx<lo||idx>=hi)continue;
 bool non=false;vector<int>perm(N);iota(perm.begin(),perm.end(),0);State z{};for(int j=0;j<6&&!non;j++){shuffle(perm.begin(),perm.end(),gen);copy(perm.begin(),perm.begin()+K,z.begin());non=!passes(c,z);}if(non)all.push_back(move(c));}
 if(idx<lo||idx>=hi)continue;cout<<idx<<" nc="<<all.size();if(solve(lim))done++;else fail++;cout<<endl;}
 cout<<"total "<<done<<" empty, "<<fail<<" unresolved"<<endl;}
