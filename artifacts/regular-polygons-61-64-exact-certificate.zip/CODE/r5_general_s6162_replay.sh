#!/bin/sh
# Full post-census proof for regular N=61,62; optional "full" checks earlier
# complete width-ten geometry archives and regenerates every N62 chord triple.
set -eu
cd "$(dirname "$0")/..";w=$(mktemp -d)
trap 'rm -rf "$w"' EXIT HUP INT TERM
cxx=${CXX:-g++}
$cxx -O3 -std=c++17 CODE/r5_general_marked34.cpp -o "$w/mark"
$cxx -O3 -std=c++17 CODE/r5_general_markedjoin.cpp -o "$w/join"
$cxx -O3 -std=c++17 CODE/r5_general_massdiff.cpp -o "$w/mass"
gzip -dc CERTIFICATES/r5_general_full34raw.txt.gz > "$w/raw"
if [ "${1:-}" = full ]; then
 python3 CODE/r5_general_replay34_cover.py "$w/raw" 34
 $cxx -O3 -std=c++17 CODE/r4_chord_concurrency.cpp -o "$w/chd"
 "$w/chd" 62 109000403 8221012 "$w/buckets"
 python3 CODE/r4_chord_triples_exact.py 62 "$w/buckets" "$w/ex"
 gzip -dc CERTIFICATES/r5_general_62patterns.txt.gz > "$w/check"; cmp "$w/check" "$w/ex"
fi
for N in 61 62; do
 python3 CODE/r5_general_patterns35.py "$N" CERTIFICATES/r5_general_62patterns.txt.gz > "$w/p"
 "$w/mark" "$w/raw" "$w/back" "$N" "$w/sysdata" > "$w/head"
 cat "$w/head" "$w/sysdata" > "$w/sys"
 "$w/join" "$w/p" "$w/sys" 1000 "$N" > "$w/joins";tail -1 "$w/joins"
 # This program includes both possible/timeout layouts; the canonical key
 # includes *all* label supports and the exact ignored rows.
 python3 CODE/r5_general_massstream.py "$w/raw" "$w/back" "$w/joins" "$w/st" "$N" 34 11
 awk 'NR==1{for(i=0;i<$3;i++)print i}' "$w/st.dat" > "$w/ids"
 "$w/mass" "$w/st.dat" "$w/ids" 8 > "$w/a"
 tail -1 "$w/a";awk '/ unresolved /{print $1}' "$w/a" > "$w/left"
 if [ -s "$w/left" ]; then
  "$w/mass" "$w/st.dat" "$w/left" 11 > "$w/b";cat "$w/b"
  awk '/ unresolved /{bad=1} END{exit bad}' "$w/b"
 fi
 python3 - "$w" "$N" <<'PY'
from pathlib import Path
import re,sys
w=Path(sys.argv[1]);N=int(sys.argv[2]);s=(w/'joins').read_text();a,b,h,c=map(int,re.search(r'total=(\d+) unsat=(\d+) budget=(\d+) candidates=(\d+)',s).groups());assert a==b+h+c and h==0
m=int((w/'st.dat').open().readline().split()[2]);p=set(map(int,(w/'ids').read_text().split()));assert p==set(range(m))
for f in ('a','b'):
 if f=='b'and not(w/'left').read_text().strip():continue
 for l in (w/f).read_text().splitlines():
  if l and l[0].isdigit() and ' EMPTY' in l:p.discard(int(l.split()[0]))
assert not p and (m,a,c)==({61:(210,63,42),62:(521,79835,138)}[N]);print('All complete full-mask classes refuted at N='+str(N))
PY
done
