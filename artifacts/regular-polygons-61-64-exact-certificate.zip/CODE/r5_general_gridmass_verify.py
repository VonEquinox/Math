'''Independent last-leaf audit for 63,64. Enumerate ALL six-coordinate
assignments directly, determine modulus/primitive root independently, expand
private paths as DIRECTED complex q_ij=(z_j−z_i)(z_j−z_(i+1)), and use only
one or two necessary mixed-cell equations. No saved table or previous numeric
products used in this verifier. All inequalities earlier are just cyclic order.'''
import json,math
from pathlib import Path
from collections import Counter,deque
from itertools import combinations_with_replacement
P=Path(__file__).resolve().parents[1]/'CERTIFICATES';Z=json.loads((P/'r5_general_type260_masks.json').read_text());k=35

def tokens(r,c,i,j):
 G=[{}for t in range(10)];mask=r[i]&c[j];assert mask.bit_count()==2
 for a in range(k):
  for b in range(k):
   d=r[a]&c[b]
   if b in(a,(a+1)%k)or d.bit_count()!=1:continue
   t=d.bit_length()-1;G[t].setdefault(a,set()).add(k+b);G[t].setdefault(k+b,set()).add(a)
 res=[]
 for t in range(10):
  if not mask>>t&1:continue
  g=G[t];q=deque([i]);pred={i:i}
  while q and j+k not in pred:
   u=q.popleft()
   for v in sorted(g.get(u,[]),reverse=True):
    if v not in pred:q.append(v);pred[v]=u
  assert k+j in pred;v=k+j;edges=[]
  while v!=i:
   u=pred[v];edges.append((min(u,v),max(u,v)-k));v=u
  edges=edges[::-1]+[(i,j)];A=Counter();sg=1
  for h,(a,b)in enumerate(edges):
   # Signed ratios of ACTUAL q_ab in polynomial conic coordinates, not
   # sine-magnitude identities. Each q_ab has both factors z_b−z_endpoint.
   for l in (a,(a+1)%k):
    assert b!=l
    if b<l:sg=-sg
    A[tuple(sorted((b,l)))]+=(-1)**h
  M={a:v for a,v in A.items()if v};weights=Counter()
  for (a,b),v in M.items():weights[a]+=v;weights[b]+=v
  assert all(v==0 for v in weights.values());res.append((sg,M))
 return res

def modulus(n):
 for p in range(10**6+(1-10**6)%n,2*10**6,n):
  if any(p%a==0 for a in range(2,math.isqrt(p)+1)):continue
  for g in range(2,1000):
   z=pow(g,(p-1)//n,p);R=[pow(z,a,p)for a in range(n)];
   if len(set(R))==n:return p,z,R
 raise ValueError('no field')

def run(n,sw,cases):
 r=Z[str(sw)]['r'];c=Z[str(sw)]['c'];rect=Z[str(sw)]['e'];assert len(rect)==1;rect=rect[0];I=sorted(rect);off=I[0];ix=lambda j:(j-off)%k;K=[ix(i)for i in I];E=n-k;p,z,R=modulus(n);table=[];slot=[I.index(j)for j in rect];D=lambda a,b:(a-b)%p
 # Ordered assignments satisfying all intervening source-point density bounds.
 for Y in combinations_with_replacement(range(E+1),5):
  B=[0]+[q+y for q,y in zip(K[1:],Y)];u,v,w,x,y,ll=[R[B[j]]for j in slot];a=(u+v)%p;b=u*v%p;c1=(w+x)%p;d=w*x%p;f=(y+ll)%p;g=y*ll%p
  if ((c1-a)*(g-b)-(f-a)*(d-b))%p==0:table.append(dict(zip(I,B)))
 print('N,sw,p,z,concurrent',n,sw,p,z,len(table),flush=True)
 def enumerate_more(st,V):
  src=sorted((ix(i),i)for i in st);src.append((k,off));ordered=sorted(V,key=ix)
  def rec(l,d):
   if l==len(ordered):yield d;return
   j=ordered[l];q=ix(j);lo=0;hi=n
   for v,a in d.items():
    b=ix(v)
    if b<q:lo=max(lo,a+q-b)
    elif q<b:hi=min(hi,a-(b-q))
   hi=min(hi,n-k+q)
   for h in range(lo,hi+1):yield from rec(l+1,d|{j:h})
  yield from rec(0,st)
 def ok(form,st):
  total=0
  for sg,expr in form:
   a=sg;b=1
   for (i,j),v in expr.items():
    diff=D(R[st[j]],R[st[i]]);assert diff
    if v>0:a=a*pow(diff,v,p)%p
    else:b=b*pow(diff,-v,p)%p
   total=(total+a*pow(b,p-2,p))%p
  return total==1
 for i,j in cases:
  if not table:break
  f=tokens(r,c,i,j);vs={v for _,b in f for e in b for v in e};rest=vs-set(table[0]);nt=[];count=0
  for st in table:
   for x in enumerate_more(st,rest):
    count+=1
    if ok(f,x):nt.append(x)
  print('cell',i,j,'new',sorted(rest),'tried',count,'admitted',len(nt),flush=True);table=nt
 assert not table
run(63,1,[(33,8),(33,10)]);run(63,0,[(8,34)]);run(64,1,[(33,8),(33,10)]);run(64,0,[(8,34)])
