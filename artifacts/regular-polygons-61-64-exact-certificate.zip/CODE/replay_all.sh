#!/bin/sh
# Core proof from the exact prior width-ten 35/36-cycle list.
set -eu
cd "$(dirname "$0")/.."
w=$(mktemp -d);trap 'rm -rf "$w"' EXIT
cxx=${CXX:-g++}
python3 CODE/literature_exact_fold.py --verify 63 64 >"$w/upper"
cmp "$w/upper" CERTIFICATES/r5_upper63_64_exact.txt
sh CODE/r5_general_s6364_replay.sh terminal
for n in 63 64;do
 python3 CODE/r5_check_type260_mass.py "$n" "CERTIFICATES/r5_general_${n}patterns.txt.gz" CERTIFICATES/r5_general_type260_masks.json
done
if [ "${1:-}" = "regenerate-chords" ];then
 "$cxx" -O3 -std=c++17 CODE/r4_chord_concurrency.cpp -o "$w/chords"
 for n in 63 64;do
  if [ "$n" = 63 ];then p=90000667;root=31764090;else p=110000833;root=95103220;fi
  "$w/chords" "$n" "$p" "$root" "$w/buckets"
  python3 CODE/r4_chord_triples_exact.py "$n" "$w/buckets" "$w/rebuilt"
  gzip -dc "CERTIFICATES/r5_general_${n}patterns.txt.gz" | cmp - "$w/rebuilt"
 done
fi
echo 'Verified exact 12 for both regular 63 and regular 64.'
