// Keep only marked consecutive generic vertex pairs as honest side rows;
// whenever a corner position was discarded, ignore the straddling side.
// This deliberately relaxes even genuine positives and covers old unmarked
// corners and generic degenerations in one proof. Odd-grid combinatorics
// used only if argv[3] odd, then print necessary lists and all back-pointers.
#include <bits/stdc++.h>
using namespace std;using W=uint64_t;using E=array<int,6>;using M=vector<E>;
#ifndef MARKED_K
#define MARKED_K 34
#endif
const int K=MARKED_K; int n,N,r[36],c[36],ranks[36],sgid,sh,sw,id,bad=0;vector<E> all;
array<long long,12> countsc{};map<M,int> table;int nb=0;ofstream back,ex;
int wrap(int x){return (x%K+K)%K;}
E canon(E a){array<pair<int,int>,3> p;for(int i=0;i<3;i++)p[i]=minmax(a[i*2],a[i*2+1]);sort(p.begin(),p.end());for(int i=0;i<3;i++){a[2*i]=p[i].first;a[2*i+1]=p[i].second;}return a;}
#include "r5_general_marked34_tables.hpp"
bool bt(int a,int b,int i){return a<b?a<i&&i<b:a<i||i<b;}
int parset(M const&G){array<int,K> p;p.fill(-1);map<pair<int,int>,int> cl;
 for(auto t:G){int a=t[0],b=t[2],j=t[4],h=t[5];if(a>b)swap(a,b);
   if(p[a]!=-1&&p[a]!=b||p[b]!=-1&&p[b]!=a)return 1;p[a]=b;p[b]=a;
   // Side midpoints in angular coordinates x obey difference N, strictly
   // forcing 2*(b-a)<=N and 2*(K-(b-a))<=N.
   if(2*(b-a)>N||2*(K-(b-a))>N)return 2;
   // All endpoints of a parallel chord except the two support sides lie
   // on opposite chains of boundary between the sides.
   if(bt(a,b,j)==bt(a,b,h))return 3;
   for(auto u:{minmax(t[0],t[1]),minmax(t[2],t[3]),minmax(t[4],t[5])}){
    auto q=pair<int,int>{u.first,u.second};auto[it,ok]=cl.emplace(q,a);if(!ok&&it->second!=a)return 4; // a repeated direction gives three support sides
   }
 }
 for(int a=0;a<K;a++)if(p[a]>a)for(int b=a+1;b<K;b++)if(p[b]>b)
 if(bt(a,p[a],b)==bt(a,p[a],p[b]))return 5;
 for(auto it=cl.begin();it!=cl.end();++it)for(auto jt=next(it);jt!=cl.end();++jt)if(it->second==jt->second){
  auto[a,b]=it->first;auto[c,d]=jt->first;if(a==c||a==d||b==c||b==d||bt(a,b,c)!=bt(a,b,d))return 6;
 }
 return 0;
}
void test(W gone){countsc[0]++;int p=0;for(int i=0;i<n;i++)ranks[i]=(gone>>i&1)?-1:p++;
 M X;for(auto t:all){bool has=false;for(int&a:t){a=ranks[a];if(a<0){has=true;break;}}if(!has)X.push_back(t);}
 if(N%2){int q=parset(X);if(q){countsc[q]++;return;}}else if(!maxg.empty()){for(auto &u:X)if(!sextmay(u)){countsc[8]++;return;}}
 for(auto&a:X)a=canon(a);sort(X.begin(),X.end());X.erase(unique(X.begin(),X.end()),X.end());
 M key;bool first=true;for(int sg:{1,-1})for(int h=0;h<K;h++){auto Y=X;for(auto&a:Y){for(int&i:a)i=wrap(h+sg*i);a=canon(a);}sort(Y.begin(),Y.end());if(first||Y<key)key=move(Y),first=false;}
 auto [it,ok]=table.emplace(key,table.size()+1);int i=it->second;back<<i<<' '<<sgid<<' '<<sh<<' '<<sw<<' '<<gone<<'\n';countsc[7]++;
 if(ok){int cnt[K]={};for(auto t:key)for(int u:t)cnt[u]++;int h=max_element(cnt,cnt+K)-cnt;ex<<i<<' '<<sgid<<' '<<sw<<' '<<h<<' '<<key.size()<<'\n';for(auto e:key){for(int u:e)ex<<wrap(u-h)<<' ';ex<<'\n';}}
}
void run(){int M[36][36];all.clear();for(int i=0;i<n;i++)for(int j=0;j<n;j++){int s=r[i]&c[j];assert((s!=0)==(i!=j&&(i+1)%n!=j));M[i][j]=s&&(s&(s-1))==0?s:0;}
 for(int i=0;i<n;i++)for(int h=i+1;h<n;h++){int js[36],cnt=0;for(int j=0;j<n;j++)if(M[i][j]&&M[i][j]==M[h][j])js[cnt++]=j;
  for(int a=0;a<cnt;a++)for(int b=a+1;b<cnt;b++)if(M[i][js[a]]==M[i][js[b]]){E t{i,(i+1)%n,h,(h+1)%n,js[a],js[b]};auto v=t;sort(v.begin(),v.end());assert(adjacent_find(v.begin(),v.end())==v.end());all.push_back(t);}}
 if(n==K)test(0);else if(n==K+1){for(int i=0;i<n;i++)test(1ull<<i);}else if(n==K+2){for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)test((1ull<<i)|(1ull<<j));}else{assert(n==K+3);for(int i=0;i<n;i++)for(int j=i+1;j<n;j++)for(int h=j+1;h<n;h++)test((1ull<<i)|(1ull<<j)|(1ull<<h));}
}
int main(int ac,char**av){if(ac<5)return 2;ifstream f(av[1]);back.open(av[2]);N=atoi(av[3]);ex.open(av[4]);if(ac>5)loadtables(av[5]);while(f>>sh>>n){assert(K<=n&&n<=36);sgid++;int R[36],C[36];for(int i=0;i<n;i++)f>>R[i];for(int i=0;i<n;i++)f>>C[i];for(sw=0;sw<2;sw++){for(int i=0;i<n;i++){r[i]=sw?C[(i+1)%n]:R[i];c[i]=sw?R[i]:C[i];}run();}}
 cout<<K<<' '<<table.size()<<'\n';cerr<<"source="<<sgid<<" systems="<<table.size()<<" counts(total..pass)=";for(auto a:countsc)cerr<<' '<<a;cerr<<'\n';}
