// Independent terminal replay: iterate *all* leaves, no prefix multiplicity inference.
// Input: requested side count, ordered templates, rigorously strict products table.
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
using namespace std;
int n,N,m,omit[6],row[50],col[50],W[100],diffs[50][50];
bool zeros[50];vector<unsigned char> signs;
uint64_t tried=0,stricts=0,holes=0,accepted=0;
struct Anch{int i,j,d;};
Anch pool[10][1000];int sizes[10];
int inspect(int i,int j){
 const int d=diffs[i][j];if(zeros[d])return 0;
 const int x=row[i]&col[j];if(!x)return 1;
 if(x&(x-1))return 0;
 const int k=__builtin_ctz(x),r=sizes[k];
 for(int z=0;z<r;z++){
    auto a=pool[k][z];const unsigned p=d*n+a.d,q=diffs[i][a.j]*n+diffs[a.i][j];
    if(signs[p*n*n+q])return 2;
 }
 pool[k][sizes[k]++]={i,j,d};return 0;
}
void leaf(int s){
 ++tried;fill(sizes,sizes+10,0);col[0]=W[2*s];int p=2*s,at=0;
 for(int i=1;i<2*n;i++){
   ++p;while(at<m&&omit[at]==i-1){++at;p+=2;}
   const int l=i/2,v=W[p%(2*N)];
   if(i&1){
      row[l]=v;
      for(int j=0;j<=l;++j){int c=inspect(l,j);if(c){if(c==1)++holes;else ++stricts;return;}}
   }else{
      col[l]=v;
      for(int j=0;j<l;++j){int c=inspect(j,l);if(c){if(c==1)++holes;else ++stricts;return;}}
   }
 }
 ++accepted;
}
void selections(int z,int prev,int s){
 if(z==m){leaf(s);return;}
 for(int n0=prev;n0<2*n;n0++){omit[z]=n0;selections(z+1,n0,s);}
}
int main(int argc,char **argv){
 if(argc<4)return 1;
 n=stoi(argv[1]);assert(0<n&&n<50);
 ifstream src(argv[2]),f(argv[3],ios::binary);assert(src&&f);
 signs.resize(n*n*n*n);
 for(int j=0;j<n;j++){char c;f.get(c);zeros[j]=c!=0;}
 f.read(reinterpret_cast<char*>(signs.data()),signs.size());assert(f);
 for(int i=0;i<n;i++)for(int j=0;j<n;j++)diffs[i][j]=(n+i-j)%n;
 int id;uint64_t templates=0;
 while(src>>id>>N){
   m=N-n;assert(m>=0&&m<=5);
   for(int i=0;i<N;i++)src>>W[2*i+1];
   for(int i=0;i<N;i++)src>>W[2*i];
   ++templates;
   for(int s=0;s<=m;s++)selections(0,0,s);
 }
 assert(tried==stricts+holes+accepted);
 cout<<"n "<<n<<" templates "<<templates<<" tried "<<tried<<" holes "<<holes<<" strict "<<stricts<<" accepted "<<accepted<<'\n';
 return accepted ? 2:0;
}
