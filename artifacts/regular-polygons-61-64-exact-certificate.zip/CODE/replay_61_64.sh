#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
t=$(mktemp -d);trap 'rm -rf "$t"' EXIT
python3 CODE/literature_exact_fold.py --verify 61 62 > "$t/upper"
cmp "$t/upper" CERTIFICATES/r5_upper61_62_exact.txt
sh CODE/r5_general_s6162_replay.sh "${1:-}"
if [ "${1:-}" = full ];then
 sh CODE/r5_general_s6364_replay.sh full regenerate64
fi
sh CODE/replay_all.sh
echo 'Verified exact nonnegative rank 12 at n=61, 62, 63 and 64.'
