#include <cstdio>
#include <iostream>
#include <fstream>
#include <algorithm>
#include <array>
#include <vector>
#include <map>
#include <set>
#include <cassert>
#include <cstdint>
using namespace std;const int n=35;using A=array<int,6>;using Q=vector<A>;using W=uint64_t;
map<Q,int>db;vector<array<int,5>>meta;vector<Q>cands;ofstream back;int raw,hole,repeat,badrep;
int md(int x){return (x%n+n)%n;}int bit(int x){return 1<<x;}
A ord(A a){array<pair<int,int>,3>b;for(int i=0;i<3;i++)b[i]=minmax(a[2*i],a[2*i+1]);sort(b.begin(),b.end());for(int i=0;i<3;i++)a[2*i]=b[i].first,a[2*i+1]=b[i].second;return a;}
void emit(int gid,int shape,int sw,int tag,int z,const vector<int>&r,const vector<int>&c){raw++;assert(r.size()==n&&c.size()==n);W masks[10][n]={};for(int i=0;i<n;i++)for(int j=0;j<n;j++)if(j!=i&&j!=(i+1)%n){int v=r[i]&c[j];if(!v){hole++;return;}if(!(v&(v-1)))masks[__builtin_ctz(v)][i]|=(W(1)<<j);}
 Q X;for(auto&g:masks)for(int i=0;i<n;i++)for(int h=i+1;h<n;h++){W w=g[i]&g[h];while(w){int j=__builtin_ctzll(w);w&=w-1;for(W o=w;o;o&=o-1){int k=__builtin_ctzll(o);A a={i,(i+1)%n,h,(h+1)%n,j,k};A b=a;sort(b.begin(),b.end());if(adjacent_find(b.begin(),b.end())!=b.end()){badrep++;return;}X.push_back(ord(a));}}}
 sort(X.begin(),X.end());X.erase(unique(X.begin(),X.end()),X.end());Q key;bool init=false;for(int sg:{1,-1})for(int t=0;t<n;t++){Q y=X;for(auto&a:y){for(int&k:a)k=md(t+sg*k);a=ord(a);}sort(y.begin(),y.end());if(!init||y<key)key=move(y),init=true;}
 int p;auto it=db.find(key);if(it==db.end()){p=cands.size();db[key]=p;cands.push_back(key);meta.push_back({gid,shape,sw,tag,z});}else{p=it->second;repeat++;}back<<p+1<<' '<<gid<<' '<<shape<<' '<<sw<<' '<<tag<<' '<<z<<'\n';}
int main(int ac,char**av){if(ac<3)return 2;ifstream in(av[1]);back.open(av[2]);int id,N,gid=0;while(in>>id>>N){gid++;vector<int>R(N),C(N);for(int&v:R)in>>v;for(int&v:C)in>>v;assert(N==35||N==36);for(int sw=0;sw<2;sw++){const vector<int>r=sw?vector<int>(C):R,c=sw?R:C;vector<int>RR=r;if(sw)rotate(RR.begin(),RR.begin()+1,RR.end());if(N==35){emit(gid,id,sw,0,-1,RR,c);continue;}for(int t=0;t<N;t++){
 // Cyclic order C_t, R_t, C_{t+1}; dropping either adjacent row+column preserves honesty.
 for(int dir:{0,1}){vector<int>r2,c2;int base=dir?(t+1)%N:t;for(int u=0;u<n;u++){c2.push_back(c[(base+1+u)%N]);r2.push_back(RR[(t+1+u)%N]);} // if delete R_t,C_(t+1), r_(t+1) comes BEFORE next surviving C_(t+2); the edge after C_(t+2) is R_(t+2)
 if(dir)rotate(r2.begin(),r2.begin()+1,r2.end());emit(gid,id,sw,dir+1,t,r2,c2);}
 vector<int>r2,c2;for(int u=0;u<n;u++){int j=(t+1+u)%N;c2.push_back(c[j]);r2.push_back(u+1==n?1023:RR[j]);}emit(gid,id,sw,3,t,r2,c2);
 }}}
 cout<<n<<' '<<cands.size()<<'\n';for(int j=0;j<int(cands.size());j++){auto X=cands[j];int count[n]={};for(auto a:X)for(int i:a)count[i]++;int t=max_element(count,count+n)-count;cout<<j+1<<' '<<meta[j][0]<<' '<<meta[j][2]<<' '<<t<<' '<<X.size()<<'\n';for(auto a:X){for(int i:a)cout<<md(i-t)<<' ';cout<<'\n';}}cerr<<"raw="<<raw<<" holes="<<hole<<" repeated-endpoint="<<badrep<<" congruent="<<repeat<<" unique="<<cands.size()<<'\n';}
