#!/usr/bin/env python3
"""Strict metric-product comparison via directed rational sine products."""
from fractions import Fraction as F
from math import floor,ceil,factorial
import sys
def arctan(a):
    m=40
    x=sum((-1)**j*F(1,(2*j+1)*a**(2*j+1)) for j in range(m))
    return x,x+F(1,(2*m+1)*a**(2*m+1))
a,b=arctan(5);c,d=arctan(239);L=16*a-4*d;U=16*b-4*c
n=int(sys.argv[1]);D=10**21
ratio=F(sys.argv[3]) if len(sys.argv)>3 else F(1)
assert ratio>=1
def sin(k):
    m=28
    t=(L+U)*F(k,2*n)
    val=sum((-1)**j*t**(2*j+1)/factorial(2*j+1) for j in range(m))
    e=t**(2*m+1)/factorial(2*m+1)+(U-L)*F(k,2*n)
    return max(0,val-e),val+e
V=[];zero=[]
for i in range(n):
    d=2*i+1;d=min(d,2*n-d)
    if d==1:V.append((0,0));zero.append(1);continue
    a,b=sin((d-1)//2);c,e=sin((d+1)//2)
    V.append((floor(D*2*a*c),ceil(D*2*b*e)));zero.append(0)
assert all(x>0 for (x,y),z in zip(V,zero) if not z)
A=[x*z for x,y in V for z,w in V]
B=[y*w for x,y in V for z,w in V]
with open(sys.argv[2],'wb') as f:
    f.write(bytes(zero));f.write(bytes(x*ratio.denominator>y*ratio.numerator for x in A for y in B))
