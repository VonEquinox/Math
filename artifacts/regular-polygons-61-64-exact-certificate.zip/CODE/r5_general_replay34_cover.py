import sys,gzip
from collections import Counter
files=[f'CERTIFICATES/r4_s33_low{n}_templates.gz' if n<40 else f'CERTIFICATES/r3_geom_{n}_templates.gz'for n in[34,36,38,40,42]]
K=int(sys.argv[2]);F=Counter()
for f in files:
 for s in gzip.open(f,'rt'):
  if int(s.split(maxsplit=2)[1])>=K:F[tuple(map(int,s.split()))]+=1
A=Counter(tuple(map(int,s.split()))for s in open(sys.argv[1]));assert A==F
print('Full parent census multiset agrees:',dict(sorted(Counter({n:sum(v for l,v in A.items()if l[1]==n)for n in range(K,37)}).items())))
