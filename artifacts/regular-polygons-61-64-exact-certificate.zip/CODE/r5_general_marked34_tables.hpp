// In a marked private rectangle, the first two chords are polygon SIDES:
// each corresponds to a 1-gap in the LOGICAL 34-vertex order. Therefore
// only four other circular gaps can vary. For each positional matching and
// designation of those two sides, the 3D suffix-max table below gives the
// exact test that one allowed physical sextuple dominates the six logical
// gap lengths componentwise.
using Block=array<unsigned char,(K+1)*(K+1)*(K+1)>;map<int,Block> maxg;
int addrs(int a,int b,int c){return (a*(K+1)+b)*(K+1)+c;}
int parseM(E p,array<int,6>&q,array<int,6>&ratio,int cyc){q=p;sort(q.begin(),q.end());int a0[6];for(int i=0;i<6;i++){
 ratio[i]=(q[(i+1)%6]-q[i]+cyc)%cyc;a0[i]=lower_bound(q.begin(),q.end(),p[i])-q.begin();}
 E v{};copy(a0,a0+6,v.begin());v=canon(v);int sig=0;for(int x:v)sig=sig*6+x;return sig;}
int edslot(int p,int q){return (p+1)%6==q?p:(q+1)%6==p?q:-1;}
void loadtables(const string&f){ifstream in(f);E p;while(in>>p[0]>>p[1]>>p[2]>>p[3]>>p[4]>>p[5]){E I,G;int sig=parseM(p,I,G,N);int sl[3];for(int t=0;t<3;t++)sl[t]=edslot(lower_bound(I.begin(),I.end(),p[2*t])-I.begin(),lower_bound(I.begin(),I.end(),p[2*t+1])-I.begin());
 for(int t=0;t<3;t++)for(int u=t+1;u<3;u++)if(sl[t]>=0&&sl[u]>=0){int m=(1<<sl[t])|(1<<sl[u]);auto&b=maxg[sig*64+m];int A[4],ct=0;for(int z=0;z<6;z++)if(!(m>>z&1))A[ct++]=G[z];assert(ct==4);int x=addrs(min(K,A[0]),min(K,A[1]),min(K,A[2]));b[x]=max(int(b[x]),A[3]);}}
 for(auto&[idx,b]:maxg)for(int a=K;a>=0;a--)for(int c=K;c>=0;c--)for(int d=K;d>=0;d--){int x=addrs(a,c,d);if(a<K)b[x]=max(b[x],b[addrs(a+1,c,d)]);if(c<K)b[x]=max(b[x],b[addrs(a,c+1,d)]);if(d<K)b[x]=max(b[x],b[addrs(a,c,d+1)]);}}
bool sextmay(const E&p){E I,G;int sig=parseM(p,I,G,K),m=0;for(int h:{0,2}){int a=lower_bound(I.begin(),I.end(),p[h])-I.begin(),b=lower_bound(I.begin(),I.end(),p[h+1])-I.begin(),s=edslot(a,b);assert(s>=0&&G[s]==1);m|=1<<s;}
 auto it=maxg.find(sig*64+m);if(it==maxg.end())return false;int A[4],ct=0;for(int z=0;z<6;z++)if(!(m>>z&1))A[ct++]=G[z];assert(ct==4);return it->second[addrs(A[0],A[1],A[2])]>=A[3];}
