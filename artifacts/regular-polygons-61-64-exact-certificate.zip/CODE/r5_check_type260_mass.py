#!/usr/bin/env python3
"""Independent exact finite-domain check of the last 35-corner support forms.

Inputs are the two concrete masks (type 260), exact normalized allowed
grid-concurrence sextuples, and the requested grid order 63 or 64.
The front-end classification reducing all possible shadows to these masks
is a separate proof step.
"""
import argparse,json
from collections import deque,Counter,defaultdict
from itertools import combinations_with_replacement,product
from math import isqrt
import gzip

M=35

def field(n):
    p=(1_000_000//n+1)*n+1
    while any(p%d==0 for d in range(2,isqrt(p)+1)):p+=n
    q=(p-1)//n
    r=next(x for b in range(2,p) if len({pow(x:=pow(b,q,p),j,p) for j in range(n)})==n)
    return p,r

def signature(W):
    d={v:i for i,v in enumerate(sorted(W))}
    a=sorted(tuple(sorted((d[x],d[y]))) for x,y in zip(W[::2],W[1::2]))
    return tuple(x for z in a for x in z)

def build_mass(U,V,i,j):
    C=[]
    for t in range(10):
        if not ((U[i]&V[j])&(1<<t)):continue
        graph=[[] for _ in range(2*M)]
        for u in range(M):
            for v in range(M):
                if v not in (u,(u+1)%M) and U[u]&V[v]==1<<t:
                    graph[u].append(M+v);graph[M+v].append(u)
        q=deque([i]);paths={i:[]}
        while q:
            u=q.popleft()
            for v in graph[u]:
                if v in paths:continue
                a,b=min(u,v),max(u,v)-M
                paths[v]=paths[u]+[(a,b)]
                q.append(v)
        assert M+j in paths,(i,j,t)
        path=paths[M+j]
        assert len(path)%2==1
        b=Counter()
        for a,c,sg in [(a,c,1 if k%2==0 else -1) for k,(a,c) in enumerate(path)]+[(i,j,-1)]:
            b[tuple(sorted((a,c)))]+=sg
            b[tuple(sorted(((a+1)%M,c)))]+=sg
        scal=Counter()
        for (a,c),v in b.items():scal[a]+=v;scal[c]+=v
        assert not any(scal.values()),(i,j,t)
        C.append({k:v for k,v in b.items() if v})
    assert len(C)>=2
    return C

def main():
    p=argparse.ArgumentParser()
    p.add_argument('n',type=int);p.add_argument('matching_table');p.add_argument('masks')
    a=p.parse_args();N=a.n;P,q=field(N);z=[pow(q,i,P) for i in range(N)]
    cases=json.load(open(a.masks))
    tables=defaultdict(list)
    op=gzip.open if a.matching_table.endswith('.gz') else open
    for line in op(a.matching_table,'rt'):
        v=tuple(map(int,line.split()));assert len(v)==12
        tables[v[:6]].append(v[6:])
    dif=[[None if i==j else (z[j]-z[i])%P for j in range(N)] for i in range(N)]
    dinv=[[None if y is None else pow(y,-1,P) for y in x] for x in dif]
    for s in (0,1):
        case=cases[str(s)];eq=tuple(case['e'][0]);I=sorted(eq);o=I[0]
        rot=lambda i:(i-o)%M
        def ok(anch):
            a=sorted((rot(i),v) for i,v in anch.items())+[(M,N)]
            return all(x-y<=u-v for (y,v),(x,u) in zip(a,a[1:]))
        states=[dict(zip(I,v)) for v in tables[signature(eq)] if ok(dict(zip(I,v)))]
        print('grid',N,'orientation',s,'prime',P,'root',q,'anchors',len(states),flush=True)
        target=([(8,34)] if s==0 else [(33,8),(33,10)])
        for i,j in target:
            if not states:break
            A=build_mass(case['r'],case['c'],i,j)
            keys=sorted(set(k for t in A for x in t for k in x),key=rot)
            need=[k for k in keys if k not in states[0]]
            def expand(fixed):
                if not need:yield fixed;return
                L=sorted((rot(i),j) for i,j in fixed.items())+[(M,N)]
                pool=[];nodes=[]
                for (u,x),(v,y) in zip(L,L[1:]):
                    h=[i for i in need if u<rot(i)<v]
                    if not h:continue
                    pool.append(combinations_with_replacement(range(x-u,y-v+1),len(h)))
                    nodes+=h
                for e in product(*pool):
                    yield fixed | {k:g+rot(k) for k,g in zip(nodes,(u for r in e for u in r))}
            def iszero(x):
                s=0
                for t in A:
                    b=1
                    for (u,v),sg in t.items():
                        d=(dinv if sg<0 else dif)[x[u]][x[v]]
                        b=b*(d if abs(sg)==1 else pow(d,abs(sg),P))%P
                    s=(s+b)%P
                return s==1
            out=[];n=0
            for fixed in states:
                for x in expand(fixed):
                    n+=1
                    if iszero(x):out.append(x)
            states=out
            print('mixed cell',i,j,'extra marks',need,'tested',n,'left',len(states),flush=True)
        assert not states,N
if __name__=='__main__':main()
