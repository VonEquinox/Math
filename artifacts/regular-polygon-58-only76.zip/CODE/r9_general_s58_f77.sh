#!/bin/sh
# Default: old 42099-item complete atlas, 5-of-11 multicover, every arithmetic
# support refutation. --marked: reproduce marked cases from all 5189 chosen f42
# masks. --full <upstream Firsching XZ>: also exact-coordinate catalogue rebuild.
set -eu
cd "$(dirname "$0")/..";w=${WORK:-$(mktemp -d)};mkdir -p "$w/bin" "$w/terminal";if [ -z "${WORK:-}" ];then trap 'rm -rf "$w"' EXIT;fi
mode=${1:-};case "$mode" in '') WORK="$w/atlas" sh CODE/r8_general_s58_e0_replay.sh;;--marked)WORK="$w/atlas" sh CODE/r8_general_s58_e0_replay.sh;;--full)WORK="$w/atlas" sh CODE/r8_general_s58_e0_replay.sh --source "$2";;*)exit 2;;esac
q="$w/terminal";b="$w/bin";c=${CXX:-c++}
for s in r4_chord_concurrency r5_general_fasttree r7_general_mass_exactrect r6_general_closure r6_general_validate_slp;do "$c" -O3 -std=c++17 "CODE/$s.cpp" -o "$b/$s";done
"$c" -O3 -std=c++17 -DGROUPED_CLOSURE CODE/r6_general_closecheck.cpp -o "$b/bundle"
"$b/r4_chord_concurrency" 58 1000037 668900 "$w/buckets" >"$w/chord.log";python3 CODE/r4_chord_triples_exact.py 58 "$w/buckets" "$w/exact";python3 CODE/r5_general_patterns35.py 58 "$w/exact" >"$w/p";test "$(wc -l <"$w/p")" -eq 26040
gzip -dc CERTIFICATES/r9_s58_f77_full_support.gz >"$q/ms"
if [ -n "$mode" ];then
 xz -dc CERTIFICATES/r8_s58_e0_types.xz >"$w/A";xz -dc CERTIFICATES/r8_s58_e0_cover.xz >"$w/S"
 python3 - "$w" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);f=(p/'A').read_bytes();v=list(map(int,(p/'S').read_text().split()));assert len(v)==len(set(v))==5189 and len(f)==23204*32;(p/'selected').write_bytes(b''.join(f[32*i-32:32*i]for i in v))
PY
 for s in r8_general_s58_streambi r3_geom_export r8_general_s58_intrinsic r8_general_s58_intrinsicjoin r5_general_markedjoin;do "$c" -O3 -std=c++17 "CODE/$s.cpp" -o "$b/$s";done
 sh CODE/r9_general_s58_selected32.sh "$b" "$w/selected" "$w/p" "$w/mark";python3 CODE/r9_general_s58_classunion.py "$q/ms" -- "$w/mark/ms"
fi
sh CODE/r9_general_s58_cohort_terminal.sh "$b" "$q" "$w/p";echo 'No proper regular58 width-eleven balanced model has 77 ambient facets.'
