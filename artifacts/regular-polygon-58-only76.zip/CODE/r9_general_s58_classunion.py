"""Compare two full support-class unions up to only proven allowed coordinate reindexings."""
from pathlib import Path
import sys,hashlib
from r5_general_massprep import sig
def classes(paths):
 u=set();n=0
 for p in paths:
  rows=list(Path(p).read_text().splitlines());K,N,nc=map(int,rows[0].split());assert (K,N)==(32,58) and len(rows)==nc+1
  for t in rows[1:]:
   z=list(map(int,t.split()));assert len(z)==2*K;k=sig(z[:K],z[K:]);u.add(k)
  n+=nc
 return u,n
if __name__=='__main__':
 j=sys.argv.index('--');a,n=classes(sys.argv[1:j]);b,m=classes(sys.argv[j+1:]);assert a==b;print('checked support-class union',len(a),'from',n,'and',m,'input representatives')
