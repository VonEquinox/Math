// S33: exhaustive outer cover of ten-vertex simplicial 5-types having a marked
// universal vertex, via 4-ball abstract interior flips on the nine-point vertex figure.
// Inherited case data: lines label #tetra_facets masks, exactly nine vertices.
#include <algorithm>
#include <array>
#include <cassert>
#include <vector>
#include <iostream>
#include <fstream>
#include <unordered_set>
#include <cstdlib>
#include <string>
#include <cstdint>
using namespace std;using A=__uint128_t;using L=uint64_t;
int pc(int i){return __builtin_popcount(i);}int mass(A p){return __builtin_popcountll((L)p)+__builtin_popcountll(L(p>>64));}
A one(int i){return A(1)<<i;}struct H{size_t operator()(A x)const{return (L)x+0x9e3779b97f4a7c15ULL*L(x>>64);}};
int label[512];A co[512];struct Sw{A al;array<int,6> ix;array<A,64> forbid;};vector<Sw> sws;
int main(int argc,char**argv){if(argc<2)return 1;int lo=argc>2?atoi(argv[2]):0,hi=argc>3?atoi(argv[3]):100000;ofstream out;if(argc>4)out.open(argv[4],ios::binary);vector<int>sp;
 for(int i=0;i<512;i++)if(pc(i)==5){label[i]=sp.size();sp.push_back(i);}assert(sp.size()==126);
 for(int s=0;s<512;s++)for(int j=0;j<126;j++)if((sp[j]&s)==s)co[s]|=one(j);
 for(int S=0;S<512;S++)if(pc(S)==6){int k=0;Sw w{};int vx[6];for(int j=0;j<9;j++)if((S>>j)&1){vx[k]=1<<j;w.ix[k++]=label[S^(1<<j)];w.al|=one(w.ix[k-1]);}
  for(int u=0;u<64;u++){int X=0;for(int j=0;j<6;j++)if(u>>j&1)X|=vx[j];w.forbid[u]=(co[S^X]&~w.al)|co[X];}
  sws.push_back(w);}
 ifstream fs(argv[1]);string name;int n;for(int t=0;fs>>name>>n;t++){
 vector<int>F(n);for(int&f:F)fs>>f;if(t<lo||t>=hi)continue;A T0=0;for(int f:F)if(!(f&1))T0|=one(label[f|1]);
 unordered_set<A,H> done;vector<A> Q(1,T0);done.insert(T0);array<int,50> h{};long long count=0,nt=0;int id=stoi(name.substr(1));
 for(size_t pos=0;pos<Q.size();pos++){auto T=Q[pos];int nf=n+mass(T);assert(nf<=42);h[nf]++;if(nf>=33){count++;if(out){L l=T,hh=T>>64;out.write((char*)&id,4);out.write((char*)&l,8);out.write((char*)&hh,8);}}
  for(auto &w:sws){A active=T&w.al;int p=mass(active);if(p<2||p>4)continue;int u=0;for(int j=0;j<6;j++)u|=int((active>>w.ix[j])&1)<<j;
    if(T&w.forbid[u])continue;A next=T^w.al;nt++;if(done.insert(next).second)Q.push_back(next);}
 }
 cout<<name<<" "<<n<<" "<<Q.size()<<" "<<count<<" "<<nt;for(int z=34;z<=42;z+=2)cout<<" "<<h[z];cout<<endl;
 }}
