'''Generate completely determined mixed-cell equations in conic brackets and a full mask isomorphism ledger for a filtered list of templates.'''
import json,sys
from collections import Counter,deque,defaultdict
from functools import lru_cache
from r5_general_type260_iso import transform
def expr(path,target,k):
 e=Counter();s=1
 for h,(a,b)in enumerate(path+[target]):
  for j in (a,(a+1)%k):
   assert b!=j
   if b<j:s=-s
   e[tuple(sorted((b,j)))]+=(-1)**h
 weights=Counter()
 for (a,b),t in e.items():weights[a]+=t;weights[b]+=t
 assert all(not v for v in weights.values())
 return s,tuple(sorted((a,b,t) for (a,b),t in e.items()if t))
def rules(r,c,extended=False):
 k=len(r);G=[defaultdict(list)for t in range(10)];eqs=set();P=[{}for t in G]
 # Rows marked -1 cannot be used for any constraint: completely ignored even if a private graph permits a lower bound.
 for i in range(k):
  if r[i]<0:continue
  for j in range(k):
   z=r[i]&c[j];assert bool(z)==(j not in(i,(i+1)%k))
   if z>0 and not z&(z-1):t=z.bit_length()-1;G[t][i].append(k+j);G[t][k+j].append(i)
 for t,g in enumerate(G):
  q=[]
  for a in range(k):
   seen={a:[]};q=deque([a])
   while q:
    u=q.popleft()
    for v in g[u]:
     if v not in seen:seen[v]=seen[u]+[(min(u,v),max(u,v)-k)];q.append(v)
   for j in range(k):
    if k+j in seen:P[t][a,j]=seen[k+j]
  for i in range(k):
   for h in range(i+1,k):
    X=[j for j in range(k)if j+k in g[i]and j+k in g[h]]
    for t1,j in enumerate(X):
     for l in X[:t1]:eqs.add((i,(i+1)%k,h,(h+1)%k,j,l))
 mass=[]
 for i in range(k):
  if r[i]<0:continue
  for j in range(k):
   labs=[a for a in range(10)if r[i]&c[j]&(1<<a)]
   if len(labs)<2 or not all((i,j) in P[a]for a in labs):continue
   terms=[expr(P[a][i,j],(i,j),k)for a in labs]
   terms.append((-1,()))
   union=set((a,b)for s,v in terms for a,b,n in v)
   dd={(a,b):min(dict(((c,d),n)for c,d,n in v).get((a,b),0)for s,v in terms)for a,b in union}
   rr=[]
   for s,v in terms:
    vv=dict(((a,b),n)for a,b,n in v);L=[]
    for a,b in sorted(union):L.extend([(a,b)]*(vv.get((a,b),0)-dd[a,b]))
    rr.append((s,tuple(L)))
   d=Counter()
   for s,L in rr:d[L]+=s
   H=tuple(sorted((s,L)for L,s in d.items()if s));V=sorted({a for s,L in H for e in L for a in e})
   if H:mass.append((len(V),sum(len(t[1])for t in H), i,j,V,H))
 return list(sorted(eqs)),sorted(mass)
def sig(r,c):
 # Canonicalize including exact positions of artificially untrusted rows after arbitrary relabel; bypass slow per-cell expansion using cyclic bitmap actions.
 k=len(r);rr=[v if v>=0 else 1023 for v in r];mx=(1<<k)-1
 def rot(s,h):return ((s<<h)|(s>>(k-h)))&mx
 opts=[]
 for sg in (1,-1):
  A=transform(rr,c,sg,0)
  for h in range(k):opts.append(tuple(sorted((rot(a,h),rot(b,h))for a,b in A)))
 return min(opts)
def main():
 raw,back,join,out=sys.argv[1:5];N=int(sys.argv[5]);S={int(l.split()[0])for l in open(join)if 'status=candidate'in l or 'status=budget'in l};
 K=int(sys.argv[6])if len(sys.argv)>6 else 34;rd=[list(map(int,l.split()))for l in open(raw)];all=[];sgn={};led=defaultdict(list)
 for l in open(back):
  u,g,s,sw,mask=map(int,l.split())
  if u not in S:continue
  id,n,*v=rd[g-1];assert id==s;R=v[:n];C=v[n:];G=[a for a in range(n)if not mask>>a&1]
  if sw:R,C=C[1:]+C[:1],R
  c=[C[a]for a in G];r=[R[a]if G[(i+1)%K]==(a+1)%n else -1 for i,a in enumerate(G)]
  ks=sig(r,c)
  if ks not in sgn:
   eq,mass=rules(r,c);ii=len(all);sgn[ks]=ii;all.append(dict(sw=sw,shape=s,r=r,c=c,e=eq,m=mass,gid=g,gone=mask))
  led[sgn[ks]].append([u,g,s,sw,mask])
 print('candidate raw',sum(map(len,led.values())),'full mask classes',len(all),'concurrency counts',Counter(len(a['e'])for a in all),'lowest arity mass and empty',Counter(a['m'][0][0]if a['m']else None for a in all));json.dump(dict(N=N,K=K,cases=all,back=led),open(out,'w'),separators=(',',':'))
 with open(out+'.dat','w')as f:
  print(K,N,len(all),file=f)
  for idx,a in enumerate(all):
   print(idx,len(a['e']),len(a['m']),file=f)
   for v in a['e']:print(*v,file=f)
   for s,d,i,j,V,terms in a['m']:
    print(s,len(terms),i,j,*V,*(x for h,L in terms for x in [h,len(L),*(z for v in L for z in v)]),file=f)
if __name__=='__main__':main()
