// Alternative propagation: for each exact equality enumerate only the RELATIVE
// gap offsets of its own involved vertices. Such local normalization is valid
// by rotation invariance of homogeneous conic identities; each rectangle
// condition is also rotation invariant. Bounds closure mixes different local
// orders, never forces unrelated origins to coincide.
#define main oldmain
#include "r5_general_markedmass.cpp"
#undef main
string bounds_path;int B[40][40],Lw[40][40],Hh[40][40],X[40];State val;Con* active;long long visited=0,accepted=0,bgt=14000000;bool budget=false;
void enumrel(int j){if(budget)return;auto&V=active->V;if(j==int(V.size())){if(++visited>bgt){budget=true;return;}if(!passes(*active,val))return;++accepted;
 for(int u=0;u<j;u++)for(int v=u+1;v<j;v++){int i=V[u],k=V[v],x=X[k]-X[i];Hh[i][k]=max(Hh[i][k],x);Lw[i][k]=min(Lw[i][k],x);}return;}
 int i=V[j],lo=0,hi=j?E:0;for(int h=0;h<j;h++){int b=V[h];lo=max(lo,X[b]-B[i][b]);hi=min(hi,X[b]+B[b][i]);}for(int g=lo;g<=hi&&!budget;g++){X[i]=g;val[i]=g+i;enumrel(j+1);}}
// Exact complete table of normalized triples of concurrent chords.
using A6=array<int,6>;
map<int,vector<A6>> rtable;
int sigrect(A6 a,const A6&v){
 array<pair<int,int>,3> e;
 for(int j=0;j<3;j++){int i=lower_bound(v.begin(),v.end(),a[2*j])-v.begin(),h=lower_bound(v.begin(),v.end(),a[2*j+1])-v.begin();assert(i<6&&h<6);e[j]=minmax(i,h);}
 sort(e.begin(),e.end());int c=0;for(auto[i,j]:e)c=(c*6+i)*6+j;return c;
}
void loadrect(const char* p){
 ifstream f(p);assert(f);A6 u;
 while(f>>u[0]>>u[1]>>u[2]>>u[3]>>u[4]>>u[5]){auto v=u;sort(v.begin(),v.end());assert(v[0]==0&&v[5]<N&&adjacent_find(v.begin(),v.end())==v.end());rtable[sigrect(u,v)].push_back(v);}
 assert(!rtable.empty());
}
void exact_rectangle(const Con&c){
 A6 u;copy(c.V.begin(),c.V.end(),u.begin());assert(c.V.size()==6);
 auto it=rtable.find(sigrect(c.E,u));if(it==rtable.end())return;
 for(auto x:it->second){++visited;bool ok=true;for(int i=0;i<6;i++)x[i]-=u[i]-u[0];
  if(x[5]>E||!is_sorted(x.begin(),x.end()))continue;
  for(int i=0;i<6&&ok;i++)for(int j=i+1;j<6;j++)if(x[j]-x[i]>B[u[i]][u[j]]||x[i]-x[j]>B[u[j]][u[i]]){ok=false;break;}
  if(!ok)continue;++accepted;for(int i=0;i<6;i++)for(int j=i+1;j<6;j++){int a=u[i],b=u[j],d=x[j]-x[i];Lw[a][b]=min(Lw[a][b],d);Hh[a][b]=max(Hh[a][b],d);}
 }
}
bool closure(){for(int b=0;b<K;b++)for(int i=0;i<K;i++)for(int j=0;j<K;j++)B[i][j]=min(B[i][j],B[i][b]+B[b][j]);for(int i=0;i<K;i++)if(B[i][i]<0)return false;return true;}
bool advance(int idx,int maxscope){std::stable_sort(all.begin(),all.end(),[](const Con&a,const Con&b){int u=0,v=0;for(auto&t:a.T)u+=t.fac.size();for(auto&t:b.T)v+=t.fac.size();return make_tuple(a.V.size(),a.type,u)<make_tuple(b.V.size(),b.type,v);});
 for(int i=0;i<K;i++)for(int j=0;j<K;j++)B[i][j]=i<j?E:0;if(!bounds_path.empty()){ifstream f(bounds_path+"/"+to_string(idx)+".bounds");if(f)for(int i=0;i<K;i++)for(int j=0;j<K;j++){int q;f>>q;assert(f);B[i][j]=min(B[i][j],q);}}
 int used=0,skips=0;for(int round=0;round<8;round++){bool change=false;int j=0;for(auto&c:all){if(int(c.V.size())>maxscope)continue;active=&c;accepted=visited=0;budget=false;for(int i:c.V)for(int b:c.V)Lw[i][b]=99,Hh[i][b]=-1;if(!c.type&&!rtable.empty())exact_rectangle(c);else enumrel(0);if(budget){skips++;continue;}used++;
 if(!accepted){cout<<" EMPTY round="<<round<<" pos="<<j<<" cell "<<c.i<<','<<c.j<<" scope="<<c.V.size()<<" tried="<<visited<<" checked="<<used<<" skipped="<<skips;return true;}
 bool up=false;for(int i:c.V)for(int b:c.V)if(i<b){if(B[i][b]>Hh[i][b])up=true,B[i][b]=Hh[i][b];if(B[b][i]>-Lw[i][b])up=true,B[b][i]=-Lw[i][b];}
 if(up){change=true;if(!closure()){cout<<" EMPTY closure";return true;}}j++;}if(!change)break;}if(!bounds_path.empty()){ofstream f(bounds_path+"/"+to_string(idx)+".bounds");for(int i=0;i<K;i++){for(int j=0;j<K;j++)f<<B[i][j]<<' ';f<<'\n';}}
 cout<<" unresolved checked="<<used<<" skipped="<<skips;return false;}
int main(int ac,char**av){if(ac<3)return 2;if(ac>4&&string(av[4])!="-")bounds_path=av[4];ifstream f(av[1]),ids(av[2]);set<int>chosen;int j;while(ids>>j)chosen.insert(j);int nc;f>>K>>N>>nc;init();E=N-K;if(ac>5&&string(av[5])!="-")loadrect(av[5]);int mx=ac>3?atoi(av[3]):8,done=0;cout<<"K "<<K<<" N "<<N<<" p "<<P<<" root "<<root<<" emb "<<emb<<endl;for(int a=0;a<nc;a++){int idx,ne,nm;f>>idx>>ne>>nm;all.clear();for(int i=0;i<ne;i++){Con c{};for(int&v:c.E){f>>v;c.mask|=1ull<<v;}for(int j=0;j<K;j++)if(c.mask>>j&1)c.V.push_back(j);c.i=i;all.push_back(c);}
 for(int i=0;i<nm;i++){Con c{};int h,t;f>>h>>t>>c.i>>c.j;c.V.resize(h);for(int&v:c.V)f>>v;c.type=1;for(int j=0;j<t;j++){Term x;int s;f>>x.s>>s;x.fac.resize(s);for(auto&u:x.fac)f>>u.first>>u.second;c.T.push_back(move(x));}if(!chosen.count(idx)||h>mx)continue;
 bool non=false;vector<int>perm(N);iota(perm.begin(),perm.end(),0);State z{};for(int j=0;j<6&&!non;j++){shuffle(perm.begin(),perm.end(),gen);copy(perm.begin(),perm.begin()+K,z.begin());non=!passes(c,z);}if(non)all.push_back(move(c));}
 if(!chosen.count(idx))continue;cout<<idx<<" nc="<<all.size();if(advance(idx,mx))done++;cout<<endl;}cout<<"total "<<done<<" empty / "<<chosen.size()<<endl;return 0;}
