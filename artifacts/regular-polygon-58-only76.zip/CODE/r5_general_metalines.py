import json,sys
L=json.load(open(sys.argv[1]));print(len(L[0]['r']),sys.argv[2],len(L))
for m in L:print(*m['r'],*m['c'])
