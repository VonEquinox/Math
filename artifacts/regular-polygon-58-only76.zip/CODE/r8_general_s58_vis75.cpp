// Exact combinatorial horizon overcover of E=2 shared-pair ambient Q.
// Delete one common low A (new bit 10) from Q. Old f=50; all old triples
// remain faces. At the other common low B the sole two missing pairs are BC,BD.
// Every old facet containing BC or BD is invisible. Signed 0/1 visibility
// is represented combinatorially; nonrealizable cuts are allowed.
#include <bits/stdc++.h>
#ifdef __BMI2__
#include <immintrin.h>
#endif
using namespace std;using U=uint64_t;using V=vector<int>;int bit(int i){return 1<<i;}int pc(int x){return __builtin_popcount(x);}int wt(U x){return __builtin_popcountll(x);}
int pext(int x,int m){
#ifdef __BMI2__
return _pext_u32(x,m);
#else
int out=0,n=1;for(;m;m&=m-1,n*=2)if(x&(m&-m))out+=n;return out;
#endif
}
struct Old{int id;V F;int nb[50][10];};
struct Opt{U P,hash;int N0,c,d,pattern,obs;};
long long seeds=0,PV=0,optionN=0,look=0,joinN=0,proper=0;ofstream out;
void run(Old&o,int B,int emit){
 int mB=bit(B),f[20],fi[50],k=0;U sl[10]={};
 for(int i=0;i<50;i++){for(int j=0;j<10;j++)if(o.F[i]&bit(j))sl[j]|=U(1)<<i;if(!(o.F[i]&mB)){f[k]=i;fi[i]=k++;}}assert(k==20&&wt(sl[B])==30);
 // Linear packed exact encoding of nine integers. For any subset of old
 // facets 2v_j-e_j lies between -15 and 40, width < 64.
 U Q[1024]={};for(int s=1;s<1024;s++){int j=__builtin_ctz(s);Q[s]=Q[s&(s-1)]+(j==B?0:U(1)<<(6*(j-(j>B))));}
 int nb0[20]={};U delta[20][64]{};for(int i=0;i<20;i++){int v=f[i];for(int j=0;j<10;j++)if(o.F[v]&bit(j)){int u=o.nb[v][j];if(!(o.F[u]&mB))nb0[i]|=bit(fi[u]);}
 V ord;for(int s=nb0[i];s;s&=s-1)ord.push_back(__builtin_ctz(s));for(int t=0;t<(1<<ord.size());t++){U a=2*Q[o.F[v]];for(int j=0;j<ord.size();j++)if(t&bit(j))a-=Q[o.F[v]&o.F[f[ord[j]]]];delta[i][t]=a;}}
 unordered_map<U,vector<Opt>> wanted;bool card[21]{};int numP=0;
 for(int c=0;c<10;c++)for(int d=0;d<c;d++)if(c!=B&&d!=B){U elig=sl[B]&~(sl[c]|sl[d]);assert(wt(elig)<=9);
 for(U P=elig;P;P=(P-1)&elig){int n=wt(P),count[10]={},aa[10]={},e=0;int cv=0;U least[20]={};int obs=0;
  for(U a=P;a;a&=a-1){int v=__builtin_ctzll(a);for(int j=0;j<10;j++)if(o.F[v]&bit(j)){count[j]++;int u=o.nb[v][j];if((P>>u)&1){if(v<u){for(int i=0;i<10;i++)if((o.F[v]&o.F[u]&bit(i)))aa[i]++;if((o.F[v]&o.F[u]&mB))e++;}}
     else if(j!=B){cv|=o.F[v]^bit(j);}else{int j0=fi[u];obs|=bit(j0);least[j0]+=Q[o.F[v]^mB];}}}
  // true A-B horizon has 9-2 neighbors: exactly C,D do not occur in it.
  if(2*n-e!=4||cv!=(1023^bit(c)^bit(d)))continue;
  numP++;int n0=13-n;assert(n0>=0&&n0<=20);card[n0]=true;
  U h=U(n0)<<57;for(int z=0;z<10;z++)if(z!=B){int target=z==c||z==d?5:6;
   h+=U((long long)target-2*count[z]+aa[z])*(U(1)<<(6*(z-(z>B))));}
  for(int s=obs;;s=(s-1)&obs){U hh=h;for(int t=s;t;t&=t-1)hh+=least[__builtin_ctz(t)];wanted[hh].push_back(Opt{P,hh,n0,c,d,s,obs});optionN++;if(!s)break;}
 }}
 PV+=numP;if(wanted.empty())return;
 U hk=0;int active=0,cardinality=0;for(int h=1;h<bit(20);h++){int t=__builtin_ctz(h),u=active&bit(t);U dd=delta[t][pext(active,nb0[t])]+(U(1)<<57);if(u){hk-=dd;cardinality--;}else{hk+=dd;cardinality++;}active^=bit(t);if(!card[cardinality])continue;look++;
 auto it=wanted.find(hk);if(it==wanted.end())continue;for(auto &k:it->second){if((active&k.obs)!=k.pattern||cardinality!=k.N0)continue;joinN++;U vis=k.P;for(int v=active;v;v&=v-1)vis|=U(1)<<f[__builtin_ctz(v)];assert(wt(vis)==13);
 V newF;int deg[11]={},oldTri[2048]={};for(int v=0;v<50;v++){if(!((vis>>v)&1))newF.push_back(o.F[v]);else for(int x=o.F[v];x;x&=x-1)if(!((vis>>o.nb[v][__builtin_ctz(x)])&1))newF.push_back((o.F[v]^(x&-x))|1024);}
 if(newF.size()!=75)continue;for(int x:newF)for(int s=x;s;s=(s-1)&x){if(pc(s)==1)deg[__builtin_ctz(s)]++;if(pc(s)==3)oldTri[s]++;}
 bool ok=true;for(int i=0;i<11;i++){int w=i==B||i==10?38:i==k.c||i==k.d?40:42;if(deg[i]!=w)ok=false;}if(!ok)continue;
 for(int s=0;s<2048;s++)if(pc(s)==3){bool hole=(s==(1024|mB|bit(k.c)))||(s==(1024|mB|bit(k.d)));if((oldTri[s]!=0)==hole)ok=false;}if(!ok)continue;proper++;
 if(emit){V star;for(int g:newF)if(g&1024)star.push_back(g^1024);sort(star.begin(),star.end());out<<o.id<<' '<<B<<' '<<k.c<<' '<<k.d<<' '<<vis;for(int g:star)out<<' '<<g;out<<'\n';}
 }}
}
int main(int ac,char**av){ifstream in(av[1]);int lo=stoi(av[2]),hi=stoi(av[3]);if(ac>4)out.open(av[4]);int id,n;while(in>>id>>n){Old o;o.id=id;o.F.resize(n);for(int&v:o.F)in>>v;if(id<lo||id>hi)continue;assert(n==50);for(int v=0;v<n;v++)for(int x=o.F[v];x;x&=x-1){int j=__builtin_ctz(x),r=o.F[v]^bit(j),z=-1;for(int u=0;u<n;u++)if(u!=v&&(o.F[u]&r)==r){assert(z<0);z=u;}assert(z>=0);o.nb[v][j]=z;}for(int B=0;B<10;B++)run(o,B,ac>4);seeds++;cerr<<"old "<<id<<" local B subsets "<<PV<<" match hashes "<<optionN<<" gray "<<look<<" hits "<<joinN<<" full consistent "<<proper<<endl;} }
