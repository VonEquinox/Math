// All intrinsic and proper-global concurrences, preserving exact marked origin
// backlinks after angular system deduplication. Literal filters are not tilted.
#define main raw_sieve_main
#include "r8_general_s58_intrinsic.cpp"
#undef main
using E=array<int,6>;using Sys=vector<E>;
E canon(E p){array<pair<int,int>,3>q;for(int j=0;j<3;j++)q[j]=minmax(p[2*j],p[2*j+1]);sort(q.begin(),q.end());for(int j=0;j<3;j++){p[2*j]=q[j].first;p[2*j+1]=q[j].second;}return p;}
int main(int ac,char**av){ifstream p(av[1]),f(av[2]),l(av[3]);ofstream info(av[4]),back(av[5]);map<int,vector<pair<int,W>>>left;int gid,shape;W init;while(l>>gid>>shape>>init)left[gid].push_back({shape,init});
 ios::sync_with_stdio(false);array<int,6>a;while(p>>a[0]>>a[1]>>a[2]>>a[3]>>a[4]>>a[5]){auto q=a;sort(q.begin(),q.end());auto b=a;for(int&x:b)x=lower_bound(q.begin(),q.end(),x)-q.begin();table[sig(b)];}
 map<Sys,int> D;long long raw=0;for(int gid=1;f>>shape>>n;gid++){for(int i=0;i<n;i++)f>>r[i];for(int i=0;i<n;i++)f>>c[i];if(!left.count(gid))continue;
 rr.clear();bad.clear();global();local();sort(rr.begin(),rr.end());rr.erase(unique(rr.begin(),rr.end(),[](auto&a,auto&b){return !(a<b)&&!(b<a);}),rr.end());
 for(auto[sh,h]:left[gid]){assert(sh==shape&&pc(h)==n-K);int v[42],m=0;for(int i=0;i<n;i++)v[i]=h&bt(i)?-1:m++;assert(m==K);for(auto g:bad)assert(g&h);
  Sys base;for(auto&q:rr)if(!(q.m&h)){E e{};int x=q.s;for(int j=5;j>=0;j--){e[j]=v[q.v[x%6]];x/=6;}base.push_back(e);}
  Sys best;bool start=true;for(int d:{1,-1})for(int c=0;c<K;c++){Sys w=base;for(auto&e:w){for(auto&j:e)j=(c+d*j+K)%K;e=canon(e);}sort(w.begin(),w.end());if(start||w<best)best=w,start=false;}
  auto[it,ok]=D.emplace(best,D.size()+1);int id=it->second;back<<id<<' '<<gid<<' '<<shape<<" 1 "<<h<<'\n';raw++;
  if(ok){int count[K]={};for(auto&e:best)for(int i:e)count[i]++;int rot=max_element(count,count+K)-count;info<<id<<' '<<gid<<" 1 "<<rot<<' '<<best.size()<<'\n';for(auto&e:best){for(auto i:e)info<<(i-rot+K)%K<<' ';info<<'\n';}}
 }}
 cout<<K<<' '<<D.size()<<'\n';cerr<<"raw layouts "<<raw<<", unique exact full-intrinsic conjunctions "<<D.size()<<"\n";
}
