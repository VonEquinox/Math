// Finite exact tests of additively and multiplicatively inferred rank-one
// masses on a cyclic marked grid. No numeric inequality or root rounding.
#include <bits/stdc++.h>
using namespace std;using W=uint64_t;
struct E{int op,i,j,k;};struct Chk{vector<E>ops;int root0=0,root1=0;};struct Rel{vector<Chk>others;vector<E>ops;vector<int>v;int maskid,root0,root1;W mask;};
int K,N,P,root,eb,extra,prbase,B[40][40],slo[12][12],shi[12][12],eg[12],pnt[12],D[4][160][160];
int fixed_cut=-1;int lim=5000000,ins,outs,ps[4][80],invP[100000];bool abort0;
int pw(int a,int b){long long r=1;while(b){if(b&1)r=r*a%P;a=1LL*a*a%P;b/=2;}return r;}
void init(){
#if defined(PARABOLA_MOD) || defined(PARABOLA_CUT)
#ifdef PARABOLA_MOD
 P=N; for(int i=2;i*i<=P;i++)assert(P%i);
#else
 for(P=max(2*N+1,prbase);P<90000;P++){bool ok=true;for(int i=2;i*i<=P;i++)if(P%i==0)ok=false;if(ok)break;}
#endif
 for(int i=1;i<P;i++)invP[i]=pw(i,P-2);for(int i=0;i<2*N;i++)for(int j=0;j<2*N;j++)D[0][i][j]=((j-i)%P+P)%P;
 eb=1;root=0;return;
#endif
 for(P=prbase;P<90000;P++){if((P-1)%N)continue;bool prime=true;for(int v=2;v*v<=P;v++)if(P%v==0)prime=false;if(prime)break;}assert(P<90000);for(root=2;root<P;root++){if(pw(root,N)!=1)continue;bool good=true;for(int d=1;d<N;d++)if(pw(root,d)==1)good=false;if(good)break;}assert(root<P);
 for(int a=1;a<P;a++)invP[a]=pw(a,P-2);
 for(int k=1;k<N&&eb<4;k++)if(gcd(k,N)==1){for(int x=0;x<N;x++)ps[eb][x]=pw(root,k*x);for(int x=0;x<N;x++)for(int y=0;y<N;y++)D[eb][x][y]=(ps[eb][y]-ps[eb][x]+P)%P;eb++;}}
template<class T> bool onepass(T const&r,int t){int v[256];assert(r.ops.size()<256);int j=0;for(auto e:r.ops){if(!e.op){int a=pnt[e.i],b=pnt[e.j],c=pnt[e.k];v[j++]=1LL*D[t][a][c]*D[t][b][c]%P;}else if(e.op==1){v[j++]=(v[e.i]+P-v[e.j])%P;}else{assert(v[e.k]);v[j++]=(1LL*v[e.i]*v[e.j]%P)*invP[v[e.k]]%P;}}return v[r.root0]==v[r.root1];}
bool pass(Rel const&r){
#ifdef PARABOLA_CUT
 if(fixed_cut>=0){
 for(int j=0;j<int(r.v.size());j++)if(r.v[j]<=fixed_cut)pnt[j]+=N;
 bool ans=onepass(r,0);for(auto&c:r.others)if(ans&&!onepass(c,0))ans=false;
 for(int j=0;j<int(r.v.size());j++)if(r.v[j]<=fixed_cut)pnt[j]-=N;
 return ans;
 }
 bool ok=false;for(int cut=0;cut<int(r.v.size());cut++){
  bool admiss=onepass(r,0);for(auto&c:r.others)if(admiss&&!onepass(c,0))admiss=false;
  if(admiss)ok=true;
  pnt[cut]+=N;
 }
 for(int i=0;i<int(r.v.size());i++)pnt[i]-=N;
 return ok;
#endif
 for(int t=0;t<eb;t++){if(!onepass(r,t))return false;for(auto&c:r.others)if(!onepass(c,t))return false;}return true;}
void loop(Rel const&r,int h){if(abort0)return;if(h==r.v.size()){if(++ins>lim){abort0=true;return;}if(!pass(r))return;outs++;for(int a=0;a<h;a++)for(int b=a+1;b<h;b++){int k=eg[b]-eg[a];slo[a][b]=min(slo[a][b],k);shi[a][b]=max(shi[a][b],k);}return;}
 int i=r.v[h],l=0,u=h?extra:0;for(int a=0;a<h;a++){int j=r.v[a];l=max(l,eg[a]-B[i][j]);u=min(u,eg[a]+B[j][i]);}
 for(int g=l;g<=u&&!abort0;g++){eg[h]=g;pnt[h]=i+g;loop(r,h+1);}}
bool tri(){for(int k=0;k<K;k++)for(int i=0;i<K;i++)for(int j=0;j<K;j++)B[i][j]=min(B[i][j],B[i][k]+B[k][j]);for(int i=0;i<K;i++)if(B[i][i]<0)return false;return true;}
bool solve(int id,vector<Rel>&rr,int maxsc,int maxrel,const string&before,const string&after){for(int i=0;i<K;i++)for(int j=0;j<K;j++)B[i][j]=i<j?extra:0;ifstream bb(before+"/"+to_string(id)+".bounds");if(bb){for(int i=0;i<K;i++)for(int j=0;j<K;j++){int x;bb>>x;assert(bb);B[i][j]=min(x,B[i][j]);}}
 int checked=0,sk=0;for(int r=0;r<6;r++){bool change=false;int nt=0;for(auto &c:rr){int s=c.v.size();if(s>maxsc||nt++>=maxrel)break;for(int i=0;i<s;i++)for(int j=i+1;j<s;j++)slo[i][j]=100,shi[i][j]=-100;ins=outs=0;abort0=false;loop(c,0);
 if(abort0){sk++;continue;}checked++;if(!outs){cout<<" EMPTY cycle "<<r<<" rel "<<c.maskid<<" scope "<<s<<" tried "<<ins<<" constraints "<<checked<<" skipped "<<sk;return true;}
 bool ch=false;for(int i=0;i<s;i++)for(int j=i+1;j<s;j++){int a=c.v[i],b=c.v[j];if(B[a][b]>shi[i][j])B[a][b]=shi[i][j],ch=true;if(B[b][a]>-slo[i][j])B[b][a]=-slo[i][j],ch=true;}
 if(ch){change=true;if(!tri()){cout<<" EMPTY closure";return true;}}}if(!change)break;}
 if(!after.empty()){ofstream o(after+"/"+to_string(id)+".bounds");for(int i=0;i<K;i++){for(int j=0;j<K;j++)o<<B[i][j]<<' ';o<<'\n';}}
 cout<<" unresolved checked "<<checked<<" skipped "<<sk;return false;}
#ifdef GROUPED_CLOSURE
#include "r6_general_bundle.hpp"
#endif
int main(int ac,char**av){ifstream f(av[1]);string before=av[2],after=av[3];int maxsc=atoi(av[4]),maxrel=atoi(av[5]);prbase=ac>6?atoi(av[6]):2;lim=ac>7?atoi(av[7]):5000000;int nc;f>>K>>N>>nc;assert(K<=36&&N<80);extra=N-K;init();cout<<"N "<<N<<" K "<<K<<" prime "<<P<<" root "<<root<<" embeddings "<<eb<<endl;int done=0;
 for(int a=0;a<nc;a++){int id,n,nh;f>>id>>n>>nh;vector<E>ds(n);for(int i=0;i<n;i++){auto&e=ds[i];f>>e.op>>e.i>>e.j>>e.k;if(e.op){assert(e.i<i&&e.j<i);if(e.op==2)assert(e.k<i&&ds[e.k].op==0);}}
 vector<Rel>rr;for(int q=0;q<nh;q++){int x,y;W mask;f>>x>>y>>mask;if(__builtin_popcountll(mask)>maxsc)continue;Rel r;r.maskid=q;r.mask=mask;int pos[40];fill(pos,pos+40,-1);for(int j=0;j<K;j++)if(mask>>j&1)pos[j]=r.v.size(),r.v.push_back(j);
 map<int,int> ids;function<int(int)> flat=[&](int a){auto it=ids.find(a);if(it!=ids.end())return it->second;auto e=ds[a];if(!e.op){int i=e.i,j=e.j;e.i=pos[i];e.j=pos[(i+1)%K];e.k=pos[j];assert(e.i>=0&&e.j>=0&&e.k>=0);}else{e.i=flat(e.i);e.j=flat(e.j);if(e.op==2)e.k=flat(e.k);}int i=r.ops.size();r.ops.push_back(e);ids[a]=i;return i;};
 r.root0=flat(x);r.root1=flat(y);rr.push_back(move(r));}
 sort(rr.begin(),rr.end(),[](const Rel&a,const Rel&b){return make_tuple(a.v.size(),a.ops.size(),a.maskid)<make_tuple(b.v.size(),b.ops.size(),b.maskid);});
#ifdef GROUPED_CLOSURE
 bundle(rr);
#endif
 cout<<id<<" rules "<<rr.size();
#ifdef PARABOLA_SEPARATE
 {vector<int>ok;ostringstream buf;auto orig=cout.rdbuf(buf.rdbuf());for(fixed_cut=0;fixed_cut<K;fixed_cut++){bool no=solve(id,rr,maxsc,maxrel,before,"");if(!no)ok.push_back(fixed_cut);buf.str("");buf.clear();}
 cout.rdbuf(orig);if(ok.empty()){cout<<" EMPTY all "<<K<<" cuts";done++;}else{cout<<" unresolved "<<ok.size()<<" cuts";for(int h:ok)cout<<' '<<h;}}
#else
 if(solve(id,rr,maxsc,maxrel,before,after))done++;
#endif
 cout<<endl;}
 cout<<"total "<<done<<" empty / "<<nc<<endl;}
