// Jointly enforce local identities sharing a small angular scope. Every inner
// equation is reindexed to the same outer local offset frame. The heuristic
// cap merely drops possible necessary constraints.
void bundle(vector<Rel>&old){
 map<W,vector<int>> by;for(int i=0;i<old.size();i++)by[old[i].mask].push_back(i);vector<Rel>out;
 for(auto &[w,ii]:by){Rel g=old[ii.front()];int pos[40];fill(pos,pos+40,-1);for(int i=0;i<int(g.v.size());i++)pos[g.v[i]]=i;
 auto put=[&](int id){const auto &v=old[id];Chk c{v.ops,v.root0,v.root1};for(auto &e:c.ops)if(e.op==0){e.i=pos[v.v[e.i]];e.j=pos[v.v[e.j]];e.k=pos[v.v[e.k]];assert(e.i>=0&&e.j>=0&&e.k>=0);}g.others.push_back(move(c));};
 for(auto &[q,v]:by){if(q!=w&&((q&w)==q)){put(v[0]);if(v.size()>1&&g.others.size()<12)put(v[1]);}}
 for(int j=1;j<min<int>(ii.size(),12);j++)put(ii[j]);out.push_back(move(g));}
 sort(out.begin(),out.end(),[](const Rel&a,const Rel&b){return make_tuple(a.v.size(),a.others.empty(),a.ops.size(),-int(a.others.size()),a.maskid)<make_tuple(b.v.size(),b.others.empty(),b.ops.size(),-int(b.others.size()),b.maskid);});old.swap(out);
}
