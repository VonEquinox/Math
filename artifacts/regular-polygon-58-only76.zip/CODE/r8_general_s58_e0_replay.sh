#!/bin/sh
# Default checks all 463,089 direct isomorphisms without a GMP dependency.
# Optional first and second args: --source /path/to/neighborly11_6inscribed.txt.xz
set -eu
base=$(pwd); work=$(mktemp -d); trap 'rm -rf "$work"' EXIT
cd "$work"
for x in facets types instances cover; do xz -dc "$base/CERTIFICATES/r8_s58_e0_${x}.xz" >"$x"; done
sha256sum -c <<'EOF'
050e8673d4ab5bceec7d155b37e27b9d5078cfc46257cfb18bee2bd1aa9d1a59  facets
2fae358159eb0e3aa7a489e58bd714ea2c90a6878821426236f98939f68c12c6  types
35f507e6dd80768ea991a960aacd2da3fce9b0b4a1f47be5f475d36489d7bbe8  instances
a1ff41eff44fb81e5cc6e6c40d030ed9b5afcd48c470ead86a2479b1319da915  cover
EOF
test "$(wc -l < facets)" = 42099
test "$(wc -c < types)" = 742528
test "$(wc -l < instances)" = 42099
test "$(wc -l < cover)" = 5189
${CXX:-c++} -O3 -std=c++17 "$base/CODE/r8_general_s58_e0verify.cpp" -o verify
./verify facets instances types
awk 'NR==FNR {if($1<1||$1>23204||seen[$1]++)exit 1;next} {if(NF!=12)exit 1;n=0;for(i=2;i<=NF;i++)n+=($i in seen);if(n<5)exit 1}' cover instances
${CXX:-c++} -O3 -std=c++17 "$base/CODE/r8_general_s58_multicover.cpp" -o greedy
./greedy instances 11 5 rebuilt; cmp cover rebuilt
if [ "${1:-}" = "--source" ];then
 case "$2" in /*) src=$2;; *) src="$base/$2";; esac
 printf '%s  %s\n' 0f3192d6625a18fc02cc88785a372500e2709fd8391b586752f05cc39f6af98f "$src" | sha256sum -c -
 ${CXX:-c++} -O3 -std=c++17 "$base/CODE/r8_general_exact11_6.cpp" -lgmpxx -lgmp -o ex
 ${CXX:-c++} -O3 -std=c++17 "$base/CODE/r8_general_s58_e0links.cpp" -o classify
 xz -dc "$src" | ./ex >rebuiltfacets; cmp facets rebuiltfacets
 ./classify rebuilttypes <rebuiltfacets >rebuiltinstances
 cmp instances rebuiltinstances; cmp types rebuilttypes
fi
echo "all 42099 rows have at least five of the 5189 selected local types; this is a reduction, not a rank exclusion"
