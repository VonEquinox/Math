// Independent derivation checker: infer exact meaning "sum of these latent
// labels in physical cell (i,j)" for every symbolic expression. It does not
// use the producer's paths, signature hashes, or any field evaluation.
#include <bits/stdc++.h>
using namespace std;using W=uint64_t;struct Tag{int i,j,s;bool operator==(Tag const&b)const{return i==b.i&&j==b.j&&s==b.s;}};int K,N,RR[40],CC[40];
int main(int ac,char**av){ifstream meta(av[1]),f(av[2]);int m,n,k,N2;meta>>K>>N>>m;f>>k>>N2>>n;assert(k==K&&N==N2);int id=-1,nd,nr,src=-1;long long nn=0,nq=0;
 for(int a=0;a<n;a++){f>>id>>nd>>nr;assert(src<id&&id<m);do{for(int i=0;i<K;i++)meta>>RR[i];for(int j=0;j<K;j++)meta>>CC[j];src++;}while(src<id);
 vector<Tag> g;vector<W>scope;nn+=nd;nq+=nr;for(int p=0;p<nd;p++){int op,i,j,h;f>>op>>i>>j>>h;
 if(!op){assert(i>=0&&i<K&&j>=0&&j<K&&RR[i]>=0&&j!=i&&j!=(i+1)%K);int z=RR[i]&CC[j];assert(z>0);g.push_back({i,j,z});scope.push_back(1ull<<i|1ull<<((i+1)%K)|1ull<<j);continue;}
 assert(0<=i&&i<p&&0<=j&&j<p);Tag u=g[i],v=g[j];W w=scope[i]|scope[j];if(op==1){assert(u.i==v.i&&u.j==v.j&&(u.s&v.s)==v.s);g.push_back({u.i,u.j,u.s^v.s});}
 else{assert(op==2&&0<=h&&h<p);Tag b=g[h];assert(b.s&&(b.s&(b.s-1))==0);assert(u.s==v.s&&u.s==b.s&&RR[b.i]>=0&&(RR[b.i]&CC[b.j])==b.s);if(!(u.j==b.j&&v.i==b.i))swap(u,v);assert(u.j==b.j&&v.i==b.i);g.push_back({u.i,v.j,b.s});w|=scope[h];}scope.push_back(w);}
 for(int j=0;j<nr;j++){int x,y;W w;f>>x>>y>>w;assert(x>=0&&x<nd&&y>=0&&y<nd&&g[x]==g[y]&&w==(scope[x]|scope[y]));}
 }cout<<"independent typed proof "<<n<<" classes "<<nn<<" nodes "<<nq<<" valid identities\n";}
