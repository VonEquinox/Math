#!/bin/sh
# Default: cover and exact terminal. --horizon: regenerate graph.
# --marked: regenerate all proper local templates, via 9,285 shapes.
# --full: both regenerations. Linux /dev/stdout and /dev/stdin for streaming.
set -eu
cd "$(dirname "$0")/..";w=${WORK:-$(mktemp -d)};mkdir -p "$w";if [ -z "${WORK:-}" ];then trap 'rm -rf "$w"' EXIT;fi
c=${CXX:-c++};mode=${1:-};case "$mode" in ''|--horizon|--marked|--full);;*)exit 2;;esac
xz -dc CERTIFICATES/r8_s58_all_f38.bin.xz >"$w/38";xz -dc CERTIFICATES/r8_s58_F75_compatibility.xz >"$w/edges"
cat CERTIFICATES/r8_s58_F75_cover9285.txt >"$w/cover";gzip -dc CERTIFICATES/r8_s58_F75_marks.gz >"$w/ms"
(cd "$w";sha256sum -c <<'EOF'
a00cc53ab256d5f7404519d6f48fae896b3945d0c4df03f00e93b29e0cf94035  38
54b3e93b72e9bf639eeff8581f04cd36642bb46b4cc1a6b2b392eae443b812fa  edges
9b4733977fdcb9e6be4853584b2e57971fd2863fc289022dce0ea421a8459548  ms
EOF
)
python3 - "$w" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);a=list(map(int,(p/'cover').read_text().split()));assert len(set(a))==len(a)==9285 and a==sorted(a)
S=set(a);ns=set();n=loop=0
for line in(p/'edges').open():
 i,j=map(int,line.split());assert 1<=i<=j<=65541 and (i in S or j in S);ns.update((i,j));n+=1;loop+=i==j
assert (n,loop,len(ns))==(989927,1200,16913)
f=(p/'38').read_bytes();(p/'selected').write_bytes(b''.join(f[32*j-32:32*j] for j in a))
print('All 989927 shape pairs covered, including 1200 loops; 9285 selected source types')
PY
if [ "$mode" = --horizon ]||[ "$mode" = --full ];then
 for s in r8_general_s58_vis75 r8_general_s58_f75cover;do "$c" -O3 -std=c++17 "CODE/$s.cpp" -o "$w/$s";done
 old=CERTIFICATES/r7_s60_horizon_51_seeds.txt
 "$w/r8_general_s58_vis75" "$old" 0 10000 /dev/stdout 2>"$w/geo.log" | "$w/r8_general_s58_f75cover" "$w/38" /dev/stdin "$old" "$w/rebuilt.edges" 2>"$w/cover.log"
 cat "$w/cover.log"; cmp "$w/edges" "$w/rebuilt.edges"
fi
for s in r4_chord_concurrency r5_general_fasttree r7_general_mass_exactrect r6_general_closure r6_general_validate_slp;do "$c" -O3 -std=c++17 "CODE/$s.cpp" -o "$w/$s";done
"$c" -O3 -std=c++17 -DGROUPED_CLOSURE CODE/r6_general_closecheck.cpp -o "$w/bundle";mkdir -p "$w/empty"
"$w/r4_chord_concurrency" 58 1000037 668900 "$w/buckets" >"$w/chord.log";python3 CODE/r4_chord_triples_exact.py 58 "$w/buckets" "$w/exact";python3 CODE/r5_general_patterns35.py 58 "$w/exact" >"$w/p";test "$(wc -l <"$w/p")" -eq 26040
if [ "$mode" = --marked ]||[ "$mode" = --full ];then
 for s in r8_general_s58_streambi r3_geom_export r5_general_markedjoin;do "$c" -O3 -std=c++17 "CODE/$s.cpp" -o "$w/$s";done
 sed 's/const int K=32,N=58/const int K=31,N=58/' CODE/r8_general_s58_intrinsic.cpp >"$w/s31.cpp";sed 's/"r8_general_s58_intrinsic.cpp"/"s31.cpp"/' CODE/r8_general_s58_intrinsicjoin.cpp >"$w/j31.cpp"
 "$c" -O3 -std=c++17 "$w/s31.cpp" -o "$w/s31";"$c" -O3 -std=c++17 "$w/j31.cpp" -o "$w/j31"
 q="$w/mark";mkdir -p "$q/chunks";i=0
 while [ "$i" -lt 9285 ];do t="$q/chunks/b$i";"$w/r8_general_s58_streambi" "$w/selected" 128 "$q/ch" "$i" 31 >"$t.geo";"$w/r3_geom_export" "$w/selected" "$q/ch" >"$q/tmp";"$w/s31" "$w/p" "$q/tmp" "$t.left" 3 >"$t.log";gzip -c "$q/tmp" >"$t.gz";i=$((i+128));done
 python3 CODE/r8_general_s58_gather36.py "$q/chunks" "$q";"$w/j31" "$w/p" "$q/raw" "$q/left" "$q/sysdata" "$q/back" >"$q/head";cat "$q/head" "$q/sysdata" >"$q/sys"
 "$w/r5_general_markedjoin" "$w/p" "$q/sys" 15000 58 >"$q/j";tail -1 "$q/j";grep -q '^total=315 unsat=289 budget=0 candidates=26$' "$q/j"
 : >"$q/none";python3 CODE/r5_general_massstream.py "$q/raw" "$q/back" "$q/j" "$q/m" 58 31 0 "$q/none";python3 CODE/r5_general_metalines.py "$q/m.meta" 58 >"$q/rebuilt"
 PYTHONPATH=CODE python3 - "$w/ms" "$q/rebuilt" <<'PY'
from r5_general_massprep import sig
from pathlib import Path
import sys
def classes(p):
 rows=[list(map(int,r.split()))for r in Path(p).read_text().splitlines()];assert rows[0]==[31,58,37]
 return {sig(t[:31],t[31:])for t in rows[1:]}
a,b=map(classes,sys.argv[1:]);assert len(a)==37 and a==b
print('all 37 full marked support classes agree, up to cyclic relabeling and factor permutation')
PY
fi
"$w/r5_general_fasttree" "$w/ms" "$w/eq" 9;seq 0 36 >"$w/ids"
"$w/r7_general_mass_exactrect" "$w/eq" "$w/ids" 8 - "$w/p" >"$w/e";tail -1 "$w/e";grep -q '^total 34 empty / 37$' "$w/e"
awk '/ unresolved /{print $1}' "$w/e" >"$w/l2";test "$(wc -l <"$w/l2")" = 3
"$w/r6_general_closure" "$w/ms" "$w/l2" "$w/sl" 8 4 3;"$w/r6_general_validate_slp" "$w/ms" "$w/sl";"$w/bundle" "$w/sl" "$w/empty" '' 8 2400 1021 >"$w/t";tail -1 "$w/t";grep -q '^total 3 empty / 3$' "$w/t"
echo 'At 75 ambient facets regular58 requires a (40,32) vertex figure. This does not exclude the entire facet count.'
