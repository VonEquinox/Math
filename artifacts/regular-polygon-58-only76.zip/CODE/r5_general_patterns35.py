'''Write all normalized necessary 3-chord patterns: use Heineken for odd N (equivalent sum of endpoints mod N); for even N read exact checked finite table.'''
import gzip,sys
from itertools import combinations
from collections import defaultdict
N=int(sys.argv[1]);src=sys.argv[2]if len(sys.argv)>2 else None
T=defaultdict(set)
if N%2:
 for s in range(1,N):
  chords=[(i,(s-i)%N)for i in range(1,N)if i<(s-i)%N and s not in(i,(s-i)%N)]
  for a,b in combinations(chords,2):
   A=[(0,s),a,b];I=tuple(sorted(v for edge in A for v in edge));assert len(set(I))==6
   M=tuple(sorted(tuple(sorted((I.index(i),I.index(j))))for i,j in A));T[M].add(I)
else:
 with (gzip.open(src,'rt')if src.endswith('.gz')else open(src))as f:
  for l in f:
   v=list(map(int,l.split()));ma=tuple(tuple(v[i:i+2])for i in(0,2,4));T[ma].add(tuple(v[6:]));
for ma in sorted(T):
 for a in sorted(T[ma]):print(*(a[i]for t in ma for i in t))
