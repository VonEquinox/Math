// Necessary chord concurrence table on a regular N-grid via a finite field.
// Each chord a,b has line (-z^a-z^b,1,z^(a+b)) in (1,z,z^-1) coordinates.
// Output lists every mod-p concurrence bucket with >=3 distinct lines.
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
using namespace std;using U=uint64_t;using I=long long;
int M;I p,rt;
I mm(I a,I b){return (a*b)%p;}
I norm(I a){a%=p;return a<0?a+p:a;}
I powm(I a,I t){I q=1;for(;t;t>>=1,a=mm(a,a))if(t&1)q=mm(q,a);return q;}
struct Rec{U key;uint16_t a,b;};
int main(int ac,char**av){
 if(ac<4)return 2;
 M=stoi(av[1]);p=stoll(av[2]);rt=stoll(av[3]);assert(p>1&&p<1000000000&&powm(rt,M)==1);
 vector<I> z(M,1);for(int j=1;j<M;j++)z[j]=mm(z[j-1],rt);
 auto test=z;sort(test.begin(),test.end());assert(adjacent_find(test.begin(),test.end())==test.end());
 vector<pair<int,int>> id;vector<array<I,3>> L;
 for(int a=0;a<M;a++)for(int b=a+1;b<M;b++){
   id.push_back({a,b});L.push_back({norm(-z[a]-z[b]),1,mm(z[a],z[b])});}
 assert(L.size()<65536);
 vector<Rec> A;A.reserve(L.size()*(L.size()-1)/2);
 for(int i=0;i<int(L.size());i++)for(int j=i+1;j<int(L.size());j++){
   auto x=L[i],y=L[j];I a=norm(y[2]-x[2]),b=norm(mm(x[2],y[0])-mm(x[0],y[2])),c=norm(x[0]-y[0]);
   U key;if(a){I s=powm(a,p-2);key=mm(s,b)*p+mm(s,c);}
   else if(b){I s=powm(b,p-2);key=U(p)*p+mm(s,c);}
   else{assert(c);key=U(p)*p+p;}
   A.push_back({key,(uint16_t)i,(uint16_t)j});
 }
 sort(A.begin(),A.end(),[](auto x,auto y){return x.key<y.key;});
 uint64_t kk=0,triples=0;int maxm=0;ofstream out;if(ac>4)out.open(av[4]);
 for(size_t i=0,j;i<A.size();i=j){
  j=i+1;while(j<A.size()&&A[j].key==A[i].key)++j;
  if(j-i==1)continue;
  vector<int>D;for(size_t h=i;h<j;h++){D.push_back(A[h].a);D.push_back(A[h].b);}
  sort(D.begin(),D.end());D.erase(unique(D.begin(),D.end()),D.end());
  int d=D.size();assert(size_t(d*(d-1)/2)==j-i);
  ++kk;maxm=max(d,maxm);
  for(int a=0;a<d;a++)for(int b=a+1;b<d;b++)for(int c=b+1;c<d;c++){
   auto x=id[D[a]],y=id[D[b]],w=id[D[c]];
   array<int,6>z{x.first,x.second,y.first,y.second,w.first,w.second};
   sort(z.begin(),z.end());if(adjacent_find(z.begin(),z.end())==z.end())++triples;}
  if(out){out<<A[i].key<<" "<<d;for(int k:D)out<<" "<<id[k].first<<" "<<id[k].second;out<<'\n';}
 }
 cout<<"grid "<<M<<" prime "<<p<<" lines "<<L.size()<<" multi_intersections "<<kk
     <<" max_multiplicity "<<maxm<<" triple_distinct_endpoints "<<triples<<"\n";
}
