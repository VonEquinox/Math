"""Collect every surviving labeled selection with a transparent raw-cycle backlink."""
from pathlib import Path
from collections import defaultdict
import gzip,sys
p=Path(sys.argv[1]);q=Path(sys.argv[2]);q.mkdir(exist_ok=True)
files=sorted(p.glob('b*.gz'),key=lambda s:int(s.stem[1:]))
k=0;g=0
with (q/'raw').open('wb')as r,(q/'left').open('w')as o,(q/'src').open('w')as s:
 for z in files:
  l=defaultdict(list)
  for row in z.with_suffix('.left').read_text().splitlines():
   i,n,m=map(int,row.split());l[i].append((n,m))
  if not l:continue
  with gzip.open(z,'rb')as f:
   for t,row in enumerate(f,1):
    if t in l:
     k+=1;r.write(row);print(k,z.stem,t,file=s)
     assert all(n==int(row.split(maxsplit=1)[0]) for n,_ in l[t])
     for n,m in l.pop(t):print(k,n,m,file=o);g+=1
  assert not l
print(len(files),'geometric blocks',k,'active source cycles',g,'surviving layouts',flush=True)
