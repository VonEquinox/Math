#!/usr/bin/env python3
'''Certify the full label supports of all surviving 35-cycle masks (not merely their rectangle equations). Usage: raw_masks, backlinks, N63/64 join logs, two standard masks.'''
import sys,json,re
from collections import defaultdict
from pathlib import Path
def lines(s):return [tuple(map(int,e.split()))for e in Path(s).read_text().splitlines()]
def transform(R,C,sg,h):
 n=len(R);out=[]
 for label in range(10):
  rr=sum(1<<((h+sg*i-(sg==-1))%n)for i,r in enumerate(R)if r>>label&1)
  cc=sum(1<<((h+sg*j)%n)for j,c in enumerate(C)if c>>label&1)
  out.append((rr,cc))
 return out
def main():
 raw=lines(sys.argv[1]);back=lines(sys.argv[2]);mask=json.load(open(sys.argv[5]))
 assert len(raw)==1108 and len(back)==11204
 for n,fn,expected in [(63,sys.argv[3],{1:4}),(64,sys.argv[4],{1:4,0:4})]:
  info=Path(fn).read_text()
  total,unsat,budget,cands=map(int,re.search(r'total=(\d+) unsat=(\d+) budget=(\d+) candidates=(\d+)',info).groups())
  S={int(l.split()[0])for l in info.splitlines()if 'status=candidate'in l}
  assert len(S)==cands and not budget and unsat+cands==total==4361
  hist=defaultdict(int);ids=set()
  for idx,gid,shape,sw,kind,cut in back:
   if idx not in S:continue
   assert (shape,kind,cut)==(260,0,-1);ids.add(idx);hist[sw]+=1
   sh,k,*m=raw[gid-1];assert (sh,k)==(260,35)
   r,c=m[:k],m[k:]
   if sw:r,c=c[1:]+c[:1],r
   B=mask[str(sw)];target=transform(B['r'],B['c'],1,0)
   assert len(set(target))==10
   found=False
   for sg in (1,-1):
    for h in range(k):
     A=transform(r,c,sg,h)
     if set(A)==set(target):
      print(n,idx,gid,sw,'h',h,'sg',sg,'permutation',*(target.index(a)for a in A));found=True;break
    if found:break
   assert found
  assert hist==expected and ids==S
if __name__=='__main__':main()
