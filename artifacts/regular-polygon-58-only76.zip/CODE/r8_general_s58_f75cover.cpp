// Invariant-only inclusion test. A hash collision may ADD candidates, never
// delete a genuine isomorph. The test is a sieve and is not used as a positive.
#include <bits/stdc++.h>
using namespace std;using U=uint64_t;using V=vector<int>;int w(U x){return __builtin_popcountll(x);}U H(U h,U y){return (h^y)*1099511628211ULL;}
U key(const V&F){U inc[10]={},t=1,A[10];for(int f:F){for(int v=f;v;v&=v-1)inc[__builtin_ctz(v)]|=t;t<<=1;}int deg[10];for(int i=0;i<10;i++)deg[i]=w(inc[i]);for(int i=0;i<10;i++){int Y[9],n=0;for(int j=0;j<10;j++)if(i!=j)Y[n++]=64*deg[j]+w(inc[i]&inc[j]);sort(Y,Y+9);U h=H(14695981039346656037ULL,deg[i]);for(int y:Y)h=H(h,y);A[i]=h;}sort(A,A+10);U h=41;for(U a:A)h=H(h,a);return h;}

int main(int ac,char**av){ifstream f(av[1],ios::binary),in(av[2]),old(av[3]);V words;for(int s=0;s<1024;s++)if(w(s)==5)words.push_back(s);array<U,4>Q;unordered_map<U,V>K;int id=0;while(f.read((char*)Q.data(),32)){V F;id++;for(int j=0;j<252;j++)if(Q[j/64]>>(j%64)&1)F.push_back(words[j]);K[key(F)].push_back(id);}
 map<int,V>S;int t,n;while(old>>t>>n){V f(n);for(int&i:f)old>>i;S[t]=f;}int seed,B,c,d;U vis;long long k=0,found=0;unordered_set<U>edges;int pres[65542]={};bool rootable[65542]={};while(in>>seed>>B>>c>>d>>vis){V a(38),b;for(int&i:a)in>>i;assert(in);k++;auto i=K.find(key(a));if(i==K.end())continue;for(int v:i->second)rootable[v]=true;
 auto del=[&](int m){return(m&((1<<B)-1))|((m>>(B+1))<<B);};
 for(int m:a)if(m&(1<<B))b.push_back(del(1024|m));auto&s=S[seed];for(int j=0;j<50;j++)if(!(vis>>j&1)&&(s[j]&(1<<B)))b.push_back(del(s[j]));assert(b.size()==38);auto j=K.find(key(b));if(j==K.end())continue;found++;for(int x:i->second)for(int y:j->second){pres[x]=pres[y]=1;edges.insert(U(min(x,y))<<32|U(max(x,y)));}
 }ofstream out(av[4]);vector<U>v(edges.begin(),edges.end());sort(v.begin(),v.end());long long kept=0;int loop=0;for(U q:v){int x=q>>32,y=uint32_t(q);if(!rootable[x]||!rootable[y])continue;kept++;loop+=x==y;out<<x<<' '<<y<<'\n';}
 cerr<<"horizons "<<k<<" double-catalog "<<found<<" outer vertices "<<accumulate(pres,pres+65542,0)<<" edges "<<edges.size()<<" reciprocal-root filtered "<<kept<<" forced loops "<<loop<<endl;}
