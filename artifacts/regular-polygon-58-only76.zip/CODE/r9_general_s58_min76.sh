#!/bin/sh
# Default replays all exact cohort refutations. --upstream also rebuilds the
# 133881-source complete metric; --full additionally reconstructs that catalogue.
set -eu
cd "$(dirname "$0")/..";w=${WORK:-$(mktemp -d)};mkdir -p "$w/bin";if [ -z "${WORK:-}" ];then trap 'rm -rf "$w"' EXIT;fi
c=${CXX:-c++};b="$w/bin";mode=${1:-};case "$mode" in ''|--upstream|--full);;*)exit 2;;esac
for s in r4_chord_concurrency r5_general_fasttree r7_general_mass_exactrect r6_general_closure r6_general_validate_slp;do "$c" -O3 -std=c++17 "CODE/$s.cpp" -o "$b/$s";done
"$c" -O3 -std=c++17 -DGROUPED_CLOSURE CODE/r6_general_closecheck.cpp -o "$b/bundle"
"$b/r4_chord_concurrency" 58 1000037 668900 "$w/buckets" >"$w/chord.log";python3 CODE/r4_chord_triples_exact.py 58 "$w/buckets" "$w/exact";python3 CODE/r5_general_patterns35.py 58 "$w/exact" >"$w/p";test "$(wc -l <"$w/p")" -eq 26040
xz -dc CERTIFICATES/r9_s58_f40_all.xz >"$w/40";(cd "$w";echo '803b2af80283802e1ffb887c0e9e8489493a9a4272efd0c343d5fcea05175ac7  40' |sha256sum -c -)
if [ "$mode" = --full ];then
 sed 's/if(nf>=33)/if(nf==40)/' CODE/r3_geom_fill.cpp >"$w/fill.cpp";"$c" -O3 -std=c++17 "$w/fill.cpp" -o "$b/fill"
 for s in canon links;do "$c" -O3 -std=c++17 "CODE/r3_geom_$s.cpp" -o "$b/$s";done
 "$b/fill" CERTIFICATES/r3_geom_vertexfigures.txt 0 1142 "$w/pointed" >"$w/fcount";"$b/canon" CERTIFICATES/r3_geom_vertexfigures.txt "$w/pointed" "$w/canonical" >"$w/ccount";"$b/links" CERTIFICATES/r3_geom_smalllinks.txt "$w/canonical" "$w/all" >"$w/lcount";cmp "$w/all" "$w/40"
fi
mkdir -p "$w/cohort";for src in CERTIFICATES/r9_s58_f40_cohort*.gz;do name=$(basename "$src" .gz);t="$w/cohort/$name";mkdir -p "$t";gzip -dc "$src" >"$t/ms";done
python3 - "$w" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);C=set(range(0,133881,400));seen=set()
for t in Path('CERTIFICATES/r9_s58_f40_ledger.txt').read_text().splitlines():
 i,j,n,k,whole,*cuts=map(int,t.split());assert i in C and i not in seen and j==min(i+400,133881)and k==sum(cuts);seen.add(i)
 assert (p/'cohort'/('r9_s58_f40_cohort'+str(whole))/'ms').exists()
assert seen==C
PY
if [ -n "$mode" ];then
 for s in r8_general_s58_streambi r3_geom_export r8_general_s58_intrinsic r8_general_s58_intrinsicjoin r5_general_markedjoin;do "$c" -O3 -std=c++17 "CODE/$s.cpp" -o "$b/$s";done
 q="$w/mark";mkdir -p "$q/chunks";i=0;while [ "$i" -lt 133881 ];do t="$q/chunks/b$i";"$b/r8_general_s58_streambi" "$w/40" 400 "$q/ch" "$i" 32 >"$t.geo";"$b/r3_geom_export" "$w/40" "$q/ch" >"$q/tmp";"$b/r8_general_s58_intrinsic" "$w/p" "$q/tmp" "$t.left" 3 >"$t.log";gzip -c "$q/tmp" >"$t.gz";i=$((i+400));done
 python3 CODE/r8_general_s58_gather36.py "$q/chunks" "$q";"$b/r8_general_s58_intrinsicjoin" "$w/p" "$q/raw" "$q/left" "$q/data" "$q/back" >"$q/head";cat "$q/head" "$q/data" >"$q/sys";"$b/r5_general_markedjoin" "$w/p" "$q/sys" 15000 58 >"$q/j";tail -1 "$q/j";grep -q ' budget=0 ' "$q/j"
 : >"$q/none";python3 CODE/r5_general_massstream.py "$q/raw" "$q/back" "$q/j" "$q/m" 58 32 0 "$q/none";python3 CODE/r5_general_metalines.py "$q/m.meta" 58 >"$q/rebuild"
 python3 CODE/r9_general_s58_classunion.py "$w"/cohort/*/ms -- "$q/rebuild"
fi
for t in "$w"/cohort/*;do echo "Cohort $(basename "$t")";sh CODE/r9_general_s58_cohort_terminal.sh "$b" "$t" "$w/p";done
echo 'No regular58 proper (40,32) vertex figure. With the preceding low-star and F75 exclusions every balanced ambient has 76 or 77 facets.'
