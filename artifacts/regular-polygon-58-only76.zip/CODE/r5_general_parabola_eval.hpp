// The integer-arithmetic parabola: a chosen local frame can differ from the
// genuine increasing physical order by a cyclic cut. Test all these cuts per
// identity; before this use p=N and translation on F_N, which erases the cut.
// Every check is necessary; genuine solutions pass one cut in every modulus.
void initpara(){P=N;for(int d=2;d*d<=N;d++)assert(N%d);emb=1;root=0;}
// Explicit value of one local equality at the unwrapped finite-field integers.
bool ptest(const Con&c,const array<int,40>&x,int p){if(c.type==0){int a[3],b[3];for(int k=0;k<3;k++){int u=x[c.E[2*k]],v=x[c.E[2*k+1]];a[k]=u+v;b[k]=u*v;}long long det=1LL*(a[0]-a[1])*(b[0]-b[2])-1LL*(a[0]-a[2])*(b[0]-b[1]);return det%p==0;}
 long long sum=0;for(auto&t:c.T){long long v=t.s;for(auto [i,j]:t.fac)v=v*(x[j]-x[i])%p;sum+=v;}return sum%p==0;}
bool passespara(const Con&c,const State&z){array<int,40>x{};for(int i:c.V)x[i]=z[i];if(!ptest(c,x,N))return false;for(int i:c.V){if(ptest(c,x,1000003)&&ptest(c,x,1000033))return true;x[i]+=N;}return false;}
