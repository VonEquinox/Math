// Relax gluing/data strictly on triangle face signs; combine local facet masks by UNION as an outer approximation.
// r=10, d=5 complete contracted signature join on supplied simplicial candidate face masks.
// Usage: join input.bin maxcases [out_chirotops.txt] [startcase]. Keeps all cases no early stop.
#include <algorithm>
#include <array>
#include <cassert>
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <unordered_map>
#include <unordered_set>
#include <cstdint>
using namespace std;using A=__uint128_t;using U=uint64_t;const int all=1023;int K=33;int b(int i){return 1<<i;}int pc(int s){return __builtin_popcount(s);}int po(U s){return __builtin_popcountll(s);}A B(int j){return A(1)<<j;}
struct H{size_t operator()(A x)const{return U(x)^(0x9e3779b97f4a7c15ull*U(x>>64));}};
vector<int> F;vector<array<int,4>> T;vector<array<int,2>> sides;int tid[1024],pi,anchor,orderp[10],pos[10],id;int good[1024];U mixed[1024];struct Rec{U code,fac;};vector<Rec>options[10];
U allinv[10][1024][10],allflip[10][1024],(*invtab)[10],*fliptab,parity,facsign,firstbit;
struct Flat{
 struct Ent{U key,mask;};vector<Ent> e;vector<int> ids;
 Flat(){e.assign(1<<16,{~0ull,0});}
 void clear(){for(int j:ids)e[j].key=~0ull;ids.clear();}
 void add(U key,U value){
  if(ids.size()*5>=e.size()*3){auto old=move(e);auto oo=move(ids);e.assign(old.size()*2,{~0ull,0});ids.clear();ids.reserve(oo.size()*2);for(int j:oo)add(old[j].key,old[j].mask);}
  U h=key;h^=h>>33;h*=0xff51afd7ed558ccdull;h^=h>>33;size_t x=h&(e.size()-1);
  while(e[x].key!=~0ull&&e[x].key!=key)x=(x+1)&(e.size()-1);
  if(e[x].key==~0ull){e[x]={key,value};ids.push_back(x);}else e[x].mask|=value;
 }
} accum;
int tri(int a,int b0,int c){return tid[b(a)|b(b0)|b(c)];}
void sweep(int S0,int S,int left,U fac,int level,U inv){if(!good[S]||po(fac&=mixed[S])<K)return;
 if(!left){if(orderp[1]>orderp[8])return;U mask=(inv^fliptab[S0]^parity)&facsign;if(mask&firstbit)mask^=facsign;accum.add(mask,fac);return;}
 if((left&(left-1))==0 && __builtin_ctz(left)<orderp[1])return;int v=left;while(v){int j=__builtin_ctz(v);v&=v-1;orderp[level]=j;pos[j]=level;sweep(S0,S^b(j),left^b(j),fac,level+1,inv^invtab[left^b(j)][j]);}
}

U allback[10][1024][10],(*backtab)[10];long long calls[7]{};
template<int k> __attribute__((always_inline)) inline void mid(int L,int R,int free,U fac,U inv,U norm){
 // Before the last remaining label, the two new sign cuts are complements
 // of the already tested left and right frontier cuts, so no new constraint.
 if constexpr(k==1){U m=(inv^norm)&facsign;if(m&firstbit)m^=facsign;accum.add(m,fac);return;}
 else{for(int t=free;t;t&=t-1){int j=__builtin_ctz(t),q=free^b(j);
 if constexpr(k%2==0){int X=L^b(j);if(!good[X])continue;U f=fac&mixed[X];if(po(f)<K)continue;mid<k-1>(X,R,q,f,inv^invtab[q][j],norm);}
 else{int X=R^b(j);if(!good[X])continue;U f=fac&mixed[X];if(po(f)<K)continue;mid<k-1>(L,X,q,f,inv^backtab[q][j],norm);}
 }}
}
void bidir(int S,int rest){int left=S^b(anchor);if(!good[left])return;U F=mixed[S]&mixed[left];if(po(F)<K)return;int free=rest^b(anchor);U norm=fliptab[S]^parity;
 for(int t=free;t;t&=t-1){int i=__builtin_ctz(t),q=free^b(i),L=left^b(i);if(!good[L])continue;U f=F&mixed[L];if(po(f)<K)continue;U inv=invtab[q][i];
 for(int u=t&(t-1);u;u&=u-1){int j=__builtin_ctz(u),R=S^b(j);if(!good[R])continue;U g=f&mixed[R];if(po(g)<K)continue;int W=q^b(j);mid<6>(L,R,W,g,inv^backtab[W][j],norm);}
 }}
struct V{A val;U fac;};unordered_map<A,vector<V>,H> group[10];A keymask[10];long long cand=0,conn=0,nodes=0;array<long long,43> hist{};ofstream extra;unordered_set<A,H> seenRidge;
void join(int at,A vals,U Fkeep){nodes++;if(at==10){cand++;A rmask=0;int parent[42],hits=0,merges=0;for(int i=0;i<42;i++)parent[i]=i;auto root=[&](int i){while(parent[i]!=i)i=parent[i];return i;};for(int i=0;i<(int)T.size();i++){int s=0;for(int j=0;j<4;j++)s|=int((vals>>T[i][j])&1)<<j;if(s!=5&&s!=10)continue;hits++;rmask|=B(i);auto q=sides[i];int a=root(q[0]),b=root(q[1]);if(a!=b){parent[a]=b;merges++;}}
 if(hits>=K&&merges==hits-1){conn++;hist[hits]++;if(seenRidge.insert(rmask).second&&extra.is_open())extra<<id<<" "<<hits<<" "<<U(vals)<<" "<<U(vals>>64)<<"\n";}return;}
 auto p=group[at].find(vals&keymask[at]);if(p==group[at].end())return;
 for(auto &v:p->second)if(po(v.fac&Fkeep)>=K)join(at+1,vals|v.val,Fkeep&v.fac);
}
int main(int argc,char**argv){if(argc<2)return 1;if(argc>5)K=stoi(argv[5]);int maxcase=argc>2?stoi(argv[2]):1000000;if(argc>3&&string(argv[3])!="-")extra.open(argv[3]);int first=argc>4?stoi(argv[4]):0;int ix=0;for(int i=0;i<10;i++)for(int j=i+1;j<10;j++)for(int k=j+1;k<10;k++)tid[b(i)|b(j)|b(k)]=ix++;assert(ix==120);
 vector<int>sub;for(int s=0;s<=all;s++)if(pc(s)==5)sub.push_back(s);ifstream bin(argv[1],ios::binary);array<U,4> Q;id=0;
 while(bin.read((char*)&Q[0],32)&&id<first+maxcase){
  ++id;if(id<=first)continue;F.clear();for(int j=0;j<252;j++)if(Q[j/64]>>(j%64)&1)F.push_back(sub[j]);int nf=F.size(); assert(nf>=K&&nf<=42);
  bool has[1024]={};for(int f:F)for(int s=f;s;s=(s-1)&f)has[s]=1;int chi[1024]={};for(int s=1;s<1024;s++)if(has[s])chi[s]=pc(s)%2?1:-1;
  for(int i=1;i<1024;i<<=1)for(int s=0;s<1024;s++)if(s&i)chi[s]+=chi[s^i];
  T.clear();sides.clear();for(int s=0;s<=all;s++)if(pc(s)==4&&has[s]){array<int,4>q;int k=0;for(int j=0;j<10;j++)if(s&b(j))q[k++]=tid[s^b(j)];T.push_back(q);array<int,2>r;int z=0;for(int f=0;f<nf;f++)if((s&F[f])==s){assert(z<2);r[z++]=f;}assert(z==2);sides.push_back(r);}
  U incidence[10]={},touches[1024]={};for(int i=0;i<nf;i++)for(int j=0;j<10;j++)if(F[i]&b(j))incidence[j]|=1ull<<i;for(int s=1;s<1024;s++)touches[s]=touches[s&(s-1)]|incidence[__builtin_ctz(s)];
  long long op=0;for(pi=0;pi<10;pi++){options[pi].clear();int rest=all^b(pi);anchor=__builtin_ctz(rest);orderp[0]=anchor;pos[anchor]=0;
   U invbase[10][10]={},sgn[10]={};int ji=0;parity=facsign=0;accum.clear();
   for(int j=0;j<10;j++)if(j!=pi)for(int l=j+1;l<10;l++)if(l!=pi){U bt=1ull<<ji++;invbase[j][l]=bt;sgn[j]|=bt;sgn[l]|=bt;if((pi>j)^(pi>l))parity|=bt;if(has[b(j)|b(l)|b(pi)])facsign|=bt;}
   invtab=allinv[pi];backtab=allback[pi];fliptab=allflip[pi];firstbit=facsign&-facsign;
   if(id==first+1)for(int s=1;s<=1023;s++){int v=__builtin_ctz(s),r=s&(s-1);fliptab[s]=fliptab[r]^sgn[v];for(int j=0;j<10;j++){invtab[s][j]=invtab[r][j]|invbase[v][j];backtab[s][j]=backtab[r][j]|invbase[j][v];}}

   for(int S=0;S<=all;S++)if(!(S&b(pi))){int X=rest^S;if(S>X){good[S]=good[X];mixed[S]=mixed[X];continue;}mixed[S]=0;good[S]=chi[S]==1&&chi[X]==1&&chi[S|b(pi)]==1&&chi[X|b(pi)]==1;if(!good[S])continue;
    mixed[S]=touches[S]&touches[X];good[S]=po(mixed[S])>=K;}
   for(int S=0;S<=all;S++)if(!(S&(b(pi)|b(anchor)))&&good[S])bidir(S,rest);for(int j:accum.ids)options[pi].push_back({accum.e[j].key,accum.e[j].mask});op+=options[pi].size();
  }
  array<int,10> seq;for(int i=0;i<10;i++)seq[i]=i;sort(seq.begin(),seq.end(),[](int x,int y){return options[x].size()!=options[y].size()?options[x].size()<options[y].size():x<y;});

  cand=0;conn=0;nodes=1;hist.fill(0);seenRidge.clear();
  vector<V> cur,nxt;cur.push_back({0,(1ull<<nf)-1});A known=0;
  vector<int> heads,chain;vector<A> keys;
  for(int k=0;k<10&&!cur.empty();k++){
   int i=seq[k];vector<int>loc;A mask=0;for(int j=0;j<10;j++)if(j!=i)for(int l=j+1;l<10;l++)if(l!=i){int z=tri(i,j,l);loc.push_back(z);if(has[b(i)|b(j)|b(l)])mask|=B(z);}
   A key=known&mask;known|=mask;
   A stretch[4][512]={};for(int a=0;a<4;a++)for(int m=1;m<512;m++)stretch[a][m]=stretch[a][m&(m-1)]|B(loc[9*a+__builtin_ctz(m)]);
   int nb=po(U(key))+po(U(key>>64));size_t bound=min<size_t>(cur.size(),size_t(1)<<nb),cap=16;while(cap<bound*2)cap*=2;
   heads.assign(cap,-1);chain.resize(cur.size());keys.resize(cap);
   auto bucket=[&](A x){U y=U(x)^(U(x>>64)*0x9e3779b97f4a7c15ull);y^=y>>33;y*=0xff51afd7ed558ccdull;y^=y>>33;size_t ix=y&(cap-1);while(heads[ix]!=-1&&keys[ix]!=x)ix=(ix+1)&(cap-1);return ix;};
   for(int j=0;j<int(cur.size());j++){A x=cur[j].val&key;size_t ix=bucket(x);chain[j]=heads[ix];heads[ix]=j;keys[ix]=x;}
   nxt.clear();for(const auto&r:options[i]){A x=stretch[0][r.code&511]|stretch[1][(r.code>>9)&511]|stretch[2][(r.code>>18)&511]|stretch[3][(r.code>>27)&511];
    for(int ss=0;ss<1+(k>0);ss++,x^=mask){for(int j=heads[bucket(x&key)];j!=-1;j=chain[j]){U f=r.fac&cur[j].fac;if(po(f)<K)continue;A v=x|cur[j].val;if(k==9){join(10,v,f);}else{nodes++;nxt.push_back({v,f});}}}
   }
   nxt.swap(cur);
  }
  cout<<id<<" "<<nf<<" "<<op<<" "<<nodes<<" "<<cand<<" "<<conn;for(int z=K;z<=nf;z++)cout<<" "<<hist[z];cout<<" "<<seenRidge.size()<<'\n';if(id%100==0)cout.flush();
 }
}
