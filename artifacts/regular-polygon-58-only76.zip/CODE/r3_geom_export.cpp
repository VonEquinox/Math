// Reconstruct all cyclic support templates from recorded signed face triangles.
// One type at a time; any sign table actually induced by a generic section has
// exactly two crossing tetrahedral ridges at every touched ambient facet.
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <vector>
using namespace std;using U=uint64_t;using A=__uint128_t;
int pc(int s){return __builtin_popcount(s);}int b(int i){return 1<<i;}
int main(int argc,char**argv){if(argc<3)return 1;ios::sync_with_stdio(false);cin.tie(nullptr);
ifstream q(argv[1],ios::binary),src(argv[2]);assert(q&&src);
vector<int>all;for(int s=0;s<1024;s++)if(pc(s)==5)all.push_back(s);assert(all.size()==252);
int tri[1024],ord=0;for(int i=0;i<10;i++)for(int j=i+1;j<10;j++)for(int k=j+1;k<10;k++)tri[b(i)|b(j)|b(k)]=ord++;
int id,N,last=0;U lo,hi;
struct Ridge{int t;array<int,2>f;array<int,4>td;};
vector<Ridge> ridges;vector<int>fs;int idx[1024];
while(src>>id>>N>>lo>>hi){if(id!=last){q.seekg((id-1)*32);array<U,4> key;q.read((char*)key.data(),32);assert(q);fs.clear();for(int j=0;j<252;j++)if(1ull&(key[j/64]>>(j%64)))fs.push_back(all[j]);
 ridges.clear();for(int t=0;t<1024;t++)if(pc(t)==4){Ridge h;h.t=t;int nf=0;for(int j=0;j<int(fs.size());j++)if((t&fs[j])==t){assert(nf<2);h.f[nf++]=j;}
  if(!nf)continue;assert(nf==2);int n=0;for(int j=0;j<10;j++)if(t&b(j))h.td[n++]=tri[t^b(j)];idx[t]=ridges.size();ridges.push_back(h);}
 last=id;}
 A x=lo|(A(hi)<<64);int d[42]={};array<int,2> inc[42];int start=1024,nt=0,nf=0;
 for(const Ridge&r:ridges){int s=0;for(int j=0;j<4;j++)s|=int((x>>r.td[j])&1)<<j;if(s!=5&&s!=10)continue;++nt;start=min(start,r.t);for(int f:r.f){assert(d[f]<2);inc[f][d[f]++]=r.t;}}
 for(int j=0;j<int(fs.size());j++){assert(d[j]==0||d[j]==2);nf+=d[j]>0;}assert(nt==N&&nf==N);
 int t=start,f=ridges[idx[t]].f[0];vector<int>R,C;while(true){C.push_back(t);R.push_back(1023^fs[f]);auto e=inc[f];t=e[0]^e[1]^t;auto h=ridges[idx[t]].f;f=h[0]^h[1]^f;if(t==start)break;assert(int(C.size())<N);}
 assert(int(C.size())==N);cout<<id<<' '<<N;for(int s:R)cout<<' '<<s;for(int s:C)cout<<' '<<s;cout<<'\n';}}
