'''Streaming mask deduplication then mixed equations for arbitrary 33/34-marked covers, bounded memory. The canonical representative and all raw backlinks are preserved.'''
from r5_general_massprep import sig,rules
from pathlib import Path
from collections import Counter
import json,sys
raw,back,join,out=sys.argv[1:5];N,K=map(int,sys.argv[5:7]);maxscope=int(sys.argv[7])if len(sys.argv)>7 else K
S={int(l.split()[0])for l in open(join)if 'status=candidate'in l or 'status=budget'in l};B=[tuple(map(int,l.split()))for l in open(back)if int(l.split()[0])in S];gids={v[1]for v in B}
rd={i:list(map(int,l.split()))for i,l in enumerate(open(raw),1)if i in gids};Sg={};alls=[];meta=Path(out+'.meta');maps=open(out+'.map','w')
for u,g,s,sw,mask in B:
 id,n,*v=rd[g];assert id==s;R=v[:n];C=v[n:];G=[a for a in range(n)if not mask>>a&1]
 if sw:R,C=C[1:]+C[:1],R
 c=[C[a]for a in G];r=[R[a]if G[(i+1)%K]==(a+1)%n else -1 for i,a in enumerate(G)];key=sig(r,c)
 if key not in Sg:Sg[key]=len(alls);alls.append(dict(r=r,c=c,gid=g,shape=id,sw=sw,gone=mask))
 print(Sg[key],u,g,s,sw,mask,file=maps)
maps.close();meta.write_text(json.dumps(alls,separators=(',',':')));print('raw',len(B),'full masks',len(alls),'saved meta',flush=True)
sel=set(int(i)for i in open(sys.argv[8]))if len(sys.argv)>8 else set(range(len(alls)))
with open(out+'.dat','w')as f:
 print(K,N,len(alls),file=f)
 for ii,B in enumerate(alls):
  qs=[];ms=[]
  if ii in sel:
   qs,ms=rules(B['r'],B['c']);ms=[c for c in ms if c[0]<=maxscope]
  print(ii,len(qs),len(ms),file=f)
  for v in qs:print(*v,file=f)
  for s,d,i,j,V,T in ms:print(s,len(T),i,j,*V,*(x for h,L in T for x in [h,len(L),*(z for e in L for z in e)]),file=f)
  if ii%200==0:f.flush()
print('all equations for',len(sel),'cases, at most scope',maxscope,flush=True)
