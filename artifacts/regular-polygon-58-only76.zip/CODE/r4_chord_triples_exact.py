#!/usr/bin/env python3
"""Normalize modular chord triples and discard false coincidences exactly."""
from collections import defaultdict
from itertools import combinations
from math import gcd
from pathlib import Path
import argparse
def div(a,b):
    assert b[-1]==1
    a=list(a);q=[0]*(len(a)-len(b)+1)
    for i in range(len(q)-1,-1,-1):
        x=a[i+len(b)-1];q[i]=x
        for j,y in enumerate(b):a[i+j]-=x*y
    assert not any(a)
    return q
P={1:[-1,1]}
def cyclo(n):
    if n not in P:
        q=[-1]+[0]*(n-1)+[1]
        for d in range(1,n):
            if n%d==0:q=div(q,cyclo(d))
        P[n]=q
    return P[n]
def basis(n):
    p=cyclo(n);d=len(p)-1;b=[]
    for i in range(n):
        if i<d:b.append(tuple(int(j==i) for j in range(d)))
        else:b.append(tuple(-(a*p[j])+u for j,(u,a) in enumerate(zip((0,)+b[-1][:-1],(b[-1][-1],)*d))))
    return b
def zero(a,b,c,vec):
    n=len(vec);t=[0]*len(vec[0])
    for l,j,k in [(a,b,c),(b,c,a),(c,a,b)]:
        for u in l:
            p=vec[(u+sum(j))%n];q=vec[(u+sum(k))%n]
            t=[x+y-z for x,y,z in zip(t,p,q)]
    return not any(t)
def main():
    a=argparse.ArgumentParser();a.add_argument('n',type=int);a.add_argument('buckets');a.add_argument('output')
    p=a.parse_args();V=basis(p.n);seen=set();bad=0;good=defaultdict(list)
    for l in open(p.buckets):
        key,k,*z=map(int,l.split())
        T=list(zip(z[::2],z[1::2]));assert len(T)==k
        if k>=p.n-1:continue # all these lines pass through one grid vertex; no disjoint endpoints
        for R in combinations(T,3):
            points=sorted(x for s in R for x in s)
            if len(set(points))<6:continue
            x0=points[0];I={v:k for k,v in enumerate(points)}
            patt=tuple(sorted(tuple(sorted((I[x],I[y]))) for x,y in R))
            point=tuple(x-x0 for x in points)
            K=(patt,point)
            if K in seen:continue
            seen.add(K)
            if zero(*(tuple(i-x0 for i in t) for t in R),V):good[patt].append(point)
            else:bad+=1
    with open(p.output,'w') as f:
        for q,t in sorted(good.items()):
            for z in sorted(t):print(*(x for r in q for x in r),*z,file=f)
    print('grid',p.n,'matching patterns',len(good),'normalized rows',sum(map(len,good.values())),'false modular',bad)
if __name__=='__main__':main()
