/* Canonicalize the pointed fill supercatalog. Only mark a universal vertex (full vertex degree)
 * minimizing its incident-facet number and, on ties, two rounds of incidence-color refinement.
 * Any actual ten-point polytope admits a minimizing universal pointing, so this is safe.
 * Hashes used ONLY as deterministic vertex invariant/color partition; ties explored exhaustively,
 * and final hypergraph equality compares all four words (no hash-as-isomorphism assumption).
 * Usage: canon 4catalog.txt fill.bin [flat_canonical_4uint64.bin].
 */
#include <array>
#include <vector>
#include <algorithm>
#include <fstream>
#include <iostream>
#include <unordered_set>
#include <cstdint>
#include <cstring>
#include <cassert>
using namespace std;using U=uint64_t;using A=__uint128_t;
int b(int i){return 1<<i;}U h(U x){x+=0x9e3779b97f4a7c15ULL;x=(x^(x>>30))*0xbf58476d1ce4e5b9ULL;x=(x^(x>>27))*0x94d049bb133111ebULL;return x^(x>>31);}
struct Key{array<U,4> w{};friend bool operator==(const Key&a,const Key&b){return a.w==b.w;}};struct Hash{size_t operator()(const Key&k)const{return h(k.w[0])^h(k.w[1]+17)^h(k.w[2]+50)^h(k.w[3]+93);}};
vector<int>B[2000],subs;int pos[1024],a[1024][5];U wp[100],color[10],v1[10],v2[10];
int d[10][10],deg[10],nF,F[50],p[10],q[10],start[10],endc[10],ng;
Key best;long long reps=0;bool first;
void canonical(int group){
 if(group<ng){auto s=start[group],e=endc[group];do{canonical(group+1);}while(next_permutation(p+s,p+e));return;}
 Key x;for(int k=0;k<10;k++)q[p[k]]=b(k);
 for(int j=0;j<nF;j++){int* f=a[F[j]];int v=q[f[0]]|q[f[1]]|q[f[2]]|q[f[3]]|q[f[4]];int i=pos[v];x.w[i/64]|=1ull<<(i%64);}
 ++reps;if(first||x.w<best.w){best=x;first=false;}}
int main(int argc,char**argv){if(argc<3)return 1;
 for(int i=0;i<100;i++)wp[i]=h(i+2048);int bit=0;
 for(int s=0;s<1024;s++)if(__builtin_popcount(s)==5){pos[s]=bit++;if(s<512)subs.push_back(s);int z=0;for(int i=0;i<10;i++)if(s&b(i))a[s][z++]=i;}
 ifstream ct(argv[1]);string name;int num;while(ct>>name>>num){int id=stoi(name.substr(1));B[id].resize(num);for(int&v:B[id]){ct>>v;v|=512;}}
 unordered_set<Key,Hash> known;array<long long,43> points{},unique{},kept{};
 ifstream bin(argv[2],ios::binary);int id,marked=9;U lo,hi;long long phase=0,eligible=0;
 while(bin.read((char*)&id,4)){bin.read((char*)&lo,8);bin.read((char*)&hi,8);assert(bin);nF=0;for(int f:B[id])F[nF++]=f;
  for(int half=0;half<=1;half++){U mask=half?hi:lo;while(mask){int k=__builtin_ctzll(mask);mask&=mask-1;F[nF++]=subs[half*64+k];}}
  points[nF]++;memset(d,0,sizeof(d));for(int t=0;t<nF;t++){int* v=a[F[t]];for(int k=0;k<5;k++){int i=v[k];d[i][i]++;for(int j=0;j<k;j++){d[i][v[j]]++;d[v[j]][i]++;}}}
  for(int i=0;i<10;i++){deg[i]=0;for(int j=0;j<10;j++)if(i!=j&&d[i][j])deg[i]++;}
  assert(deg[9]==9);bool skip=false;for(int j=0;j<9;j++)if(deg[j]==9&&d[j][j]<d[9][9])skip=true;if(skip)continue;
  for(int i=0;i<10;i++)v1[i]=h(128*d[i][i]+deg[i]);
  for(int u=0;u<2;u++){for(int i=0;i<10;i++){U val=v1[i];for(int j=0;j<10;j++)if(i!=j)val+=wp[d[i][j]]*v1[j];v2[i]=h(val);}copy(v2,v2+10,v1);}
  for(int j=0;j<9;j++)if(deg[j]==9&&d[j][j]==d[9][9]&&v1[j]<v1[9])skip=true;if(skip)continue;kept[nF]++;
  for(int i=0;i<10;i++)p[i]=i;sort(p,p+10,[&](int i,int j){return v1[i]!=v1[j]?v1[i]<v1[j]:i<j;});ng=0;for(int i=0;i<10;){int j=i+1;while(j<10&&v1[p[i]]==v1[p[j]])j++;if(j>i+1){start[ng]=i;endc[ng++]=j;}i=j;}first=true;canonical(0);
  if(known.insert(best).second)unique[nF]++;
 }
 for(int i=34;i<=42;i+=2)cout<<i<<" "<<points[i]<<" "<<kept[i]<<" "<<unique[i]<<"\n";cerr<<"canonical labelings evaluated "<<reps<<" total types "<<known.size()<<"\n";
 if(argc>3){vector<Key>vec(known.begin(),known.end());sort(vec.begin(),vec.end(),[](const auto&a,const auto&b){return a.w<b.w;});ofstream out(argv[3],ios::binary);for(auto&k:vec)out.write((char*)&k.w[0],32);}
}
