/* Independent signed complex-bracket construction from full masks. Build each
   row-to-column path by backtracking a private BFS; the walk has odd length,
   so its reverse preserves its +-+ exponents. */
#include <bits/stdc++.h>
using namespace std;using A=array<int,6>;using F=vector<pair<int,int>>;using Q=vector<pair<int,F>>;struct Rule{int i,j;vector<int>V;Q T;int deg;};
int pred[10][40][80],M[40][40],R[40],C[40],K,N,sc=11;vector<int>G[10][80];
void gen(int idx,ostream&out){for(int t=0;t<10;t++)for(int u=0;u<2*K;u++)G[t][u].clear();for(int i=0;i<K;i++)for(int j=0;j<K;j++){int m=R[i]<0?0:R[i]&C[j];M[i][j]=m;if(m&&!(m&(m-1))){int t=__builtin_ctz(m);G[t][i].push_back(K+j);G[t][K+j].push_back(i);}}
 set<A>eq;for(int t=0;t<10;t++){for(int i=0;i<K;i++){
  int*q=pred[t][i];fill(q,q+2*K,-1);q[i]=i;vector<int>Q0{i};for(int p=0;p<int(Q0.size());p++){int u=Q0[p];for(int v:G[t][u])if(q[v]<0)q[v]=u,Q0.push_back(v);}
  for(int h=i+1;h<K;h++){vector<int>J;for(int j:G[t][i])if(M[h][j-K]==(1<<t))J.push_back(j-K);for(int a=0;a<(int)J.size();a++)for(int b=0;b<a;b++)eq.insert({i,(i+1)%K,h,(h+1)%K,J[a],J[b]});}}}
 vector<Rule>T;for(int i=0;i<K;i++)for(int j=0;j<K;j++){int m=M[i][j];if(__builtin_popcount(m)<2)continue;bool known=true;for(int t=0;t<10;t++)if((m>>t&1)&&pred[t][i][K+j]<0)known=false;if(!known)continue;
 vector<map<pair<int,int>,int>>term(1);vector<int>sign{-1};set<pair<int,int>>used;
 for(int t=0;t<10;t++)if(m>>t&1){int s=1;map<pair<int,int>,int>a;auto use=[&](int u,int b,int d){for(int e:{u,(u+1)%K}){assert(e!=b);if(b<e)s=-s;auto key=minmax(b,e);a[key]+=d;used.insert(key);}};int v=K+j,d=1;
 while(v!=i){int u=pred[t][i][v];assert(u>=0);use(min(u,v),max(u,v)-K,d);d=-d;v=u;}assert(d==-1);use(i,j,-1);vector<int>bal(K);for(auto[u,e]:a)bal[u.first]+=e,bal[u.second]+=e;assert(*min_element(bal.begin(),bal.end())==0&&*max_element(bal.begin(),bal.end())==0);term.push_back(move(a));sign.push_back(s);}
 map<pair<int,int>,int>D;for(auto key:used)for(auto&a:term)D[key]=min(D[key],a[key]);map<F,int>hh;for(int t=0;t<(int)term.size();t++){F g;for(auto u:used)for(int v=0;v<term[t][u]-D[u];v++)g.push_back(u);hh[g]+=sign[t];}
 set<int>vs;Rule h{};h.i=i;h.j=j;for(auto&[f,s]:hh)if(s){h.T.push_back({s,f});for(auto[a,b]:f)vs.insert(a),vs.insert(b);h.deg+=f.size();}h.V=vector<int>(vs.begin(),vs.end());if(!h.T.empty()&&int(h.V.size())<=sc){sort(h.T.begin(),h.T.end());T.push_back(move(h));}}
 stable_sort(T.begin(),T.end(),[](const Rule&a,const Rule&b){return make_tuple(a.V.size(),a.deg,a.i,a.j)<make_tuple(b.V.size(),b.deg,b.i,b.j);});
 out<<idx<<' '<<eq.size()<<' '<<T.size()<<'\n';for(auto&E:eq){for(int x:E)out<<x<<' ';out<<'\n';}for(auto &h:T){out<<h.V.size()<<' '<<h.T.size()<<' '<<h.i<<' '<<h.j;for(auto a:h.V)out<<' '<<a;for(auto&[s,f]:h.T){out<<' '<<s<<' '<<f.size();for(auto[a,b]:f)out<<' '<<a<<' '<<b;}out<<'\n';}}
int main(int ac,char**av){ifstream f(av[1]);ofstream o(av[2]);int n;f>>K>>N>>n;if(ac>3)sc=atoi(av[3]);o<<K<<' '<<N<<' '<<n<<'\n';for(int i=0;i<n;i++){for(int j=0;j<K;j++)f>>R[j];for(int j=0;j<K;j++)f>>C[j];gen(i,o);}return 0;}
