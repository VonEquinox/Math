#!/bin/sh
# Terminal proof on one cohort. All three bounds are derived in this run.
set -eu
b=$1;w=$2;p=$3;mkdir -p "$w/empty" "$w/b9"
n=$(awk 'NR==1{if($1!=32||$2!=58)exit 1;print $3}' "$w/ms")
awk -v n="$n" 'BEGIN{for(i=0;i<n;i++)print i}' >"$w/ids"
"$b/r5_general_fasttree" "$w/ms" "$w/eq" 9
"$b/r7_general_mass_exactrect" "$w/eq" "$w/ids" 8 - "$p" >"$w/e";tail -1 "$w/e"
awk '/ unresolved /{print $1}' "$w/e" >"$w/l2";: >"$w/t";: >"$w/l3"
if [ -s "$w/l2" ];then
 "$b/r6_general_closure" "$w/ms" "$w/l2" "$w/sl" 8 4 3
 "$b/r6_general_validate_slp" "$w/ms" "$w/sl"
 "$b/bundle" "$w/sl" "$w/empty" '' 8 2400 1021 >"$w/t";tail -1 "$w/t"
 awk '/ unresolved /{print $1}' "$w/t" >"$w/l3"
fi
: >"$w/e9";: >"$w/t9"
if [ -s "$w/l3" ];then
 "$b/r7_general_mass_exactrect" "$w/eq" "$w/l3" 9 "$w/b9" "$p" >"$w/e9";tail -1 "$w/e9"
 awk '/ unresolved /{print $1}' "$w/e9" >"$w/l4"
 if [ -s "$w/l4" ];then
  "$b/r6_general_closure" "$w/ms" "$w/l4" "$w/sl9" 9 6 5
  "$b/r6_general_validate_slp" "$w/ms" "$w/sl9"
  "$b/bundle" "$w/sl9" "$w/b9" "$w/b9" 9 5000 1021 28000000 >"$w/t9";tail -1 "$w/t9"
 fi
fi
python3 - "$w" <<'PY'
from pathlib import Path
import sys
q=Path(sys.argv[1]);need=set(range(int((q/'ms').open().readline().split()[2])))
for name in ['e','t','e9','t9']:
 seen=set();dead=set();f=(q/name).read_text().splitlines()
 if not f:assert not need;continue
 for line in f:
  if not line.split()[0].isdigit():continue
  n=int(line.split()[0]);assert n in need and n not in seen;seen.add(n)
  if ' EMPTY ' in line:dead.add(n)
  else:assert ' unresolved ' in line
 assert seen==need;(done,of)=map(int,(f[-1].split()[1],f[-1].split()[4]));assert(done,of)==(len(dead),len(need));need-=dead
assert not need
print('All full-support class IDs refuted.')
PY
