// Regular58: proper corners only. Additional necessary conic concurrences of
// exposed 3-face chord lines. Exact cyclic-six table: aggregate possible pair
// differences by original increasing logical positions; interval triangle cuts.
// Output every open selector; this file is only a necessary sieve.
#include <bits/stdc++.h>
using namespace std;using W=uint64_t;
const int K=32,N=58;int n,r[42],c[42];int pc(W s){return __builtin_popcountll(s);} W bt(int i){return W(1)<<i;}
struct Row{array<int,6>q,g;};
int sig(array<int,6>p){array<pair<int,int>,3> a;for(int i=0;i<3;i++)a[i]=minmax(p[2*i],p[2*i+1]);sort(a.begin(),a.end());int h=0;for(auto[x,y]:a)h=(h*6+x)*6+y;return h;}
struct Relation{array<int,6>v;int s;W m;bool operator<(const Relation&o)const{return tie(v,s)<tie(o.v,o.s);}};
vector<Relation> rr;vector<W>bad;map<int,vector<Row>>table;
void triple(int a,int b,int e,int f,int j,int k){
 array<int,6>p{a,b,e,f,j,k},v=p;sort(v.begin(),v.end());if(adjacent_find(v.begin(),v.end())!=v.end())return;
 W m=0;for(int i:v)m|=bt(i);for(int&x:p)x=lower_bound(v.begin(),v.end(),x)-v.begin();int s=sig(p);if(!table.count(s))bad.push_back(m);else rr.push_back({v,s,m});}
void global(){for(int i=0;i<n;i++)for(int h=i+1;h<n;h++){W cols[10]={};for(int j=0;j<n;j++){int z=c[(i+1)%n]&r[j];if(z&&!(z&(z-1))&&(c[(h+1)%n]&r[j])==z)cols[__builtin_ctz(z)]|=bt(j);}
 for(W s:cols)for(W a=s;a;a&=a-1)for(W b=a&(a-1);b;b&=b-1)triple(i,(i+1)%n,h,(h+1)%n,__builtin_ctzll(a),__builtin_ctzll(b));}}
void local(){int F[42];for(int i=0;i<n;i++)F[i]=r[i]^1023;
 for(int e=1;e<1024;e++)if(pc(e)==2){int v[42],m=0;for(int i=0;i<n;i++)if((F[i]&e)==e)v[m++]=i;if(m<=2)continue;
  int more[42],next[42];bool edge[42];for(int i=0;i<m;i++){int a=(i+m-1)%m,b=next[i]=(i+1)%m;more[i]=-1;for(int j=0;j<m;j++)if(j!=i&&j!=a&&j!=b&&pc(F[v[i]]&F[v[j]])==4){if(more[i]>=0){bad={0};return;}more[i]=j;}}
  for(int i=0;i<m;i++){int j=next[i];edge[i]=pc(F[v[i]]&F[v[j]])==4&&(more[i]>=0||more[j]>=0||(v[i]+1)%n==v[j]);}
  for(int i=0;i<m;i++)if(edge[i])for(int j=i+1;j<m;j++)if(edge[j]){int a=(F[v[i]]&F[v[next[i]]])^e,b=(F[v[j]]&F[v[next[j]]])^e;W cols[10]={};
   for(int k=0;k<m;k++){int z=a&~F[v[k]];if(z&&!(z&(z-1))&&(b&~F[v[k]])==z)cols[__builtin_ctz(z)]|=bt(v[k]);}
   for(W s:cols)for(W a=s;a;a&=a-1)for(W b=a&(a-1);b;b&=b-1)triple(v[i],v[next[i]],v[j],v[next[j]],__builtin_ctzll(a),__builtin_ctzll(b));
  }
 }}
struct Token{array<W,15>w;};unordered_map<W,Token>memo;
const Token&get(int s,array<int,6>u){int g[6];W key=s;for(int j=0;j<6;j++){g[j]=(u[(j+1)%6]-u[j]+K)%K;key=key*32+g[j];}
 auto h=memo.find(key);if(h!=memo.end())return h->second;Token t{};
 for(const auto&r:table[s]){bool ok=true;for(int j=0;j<6;j++)if(r.g[j]<g[j]){ok=false;break;}if(!ok)continue;
 int p=0;for(int a=0;a<6;a++)for(int b=a+1;b<6;b++)t.w[p++]|=bt(r.q[b]-r.q[a]);}
 return memo.emplace(key,t).first->second;}
long long counts[6]={},nt=0,layouts=0;ofstream out;bool delta3=false;string writebound;
int mark(W h){for(auto s:bad)if(!(s&h))return 0;int ranks[42],m=0;for(int i=0;i<n;i++)ranks[i]=(h&bt(i))?-1:m++;assert(m==K);
 W D[K][K];for(int i=0;i<K;i++)for(int j=i+1;j<K;j++){int a=j-i;D[i][j]=(bt(a+(N-K)+1)-1)^(bt(a)-1);}
 for(auto&c:rr)if(!(c.m&h)){auto u=c.v;for(int&i:u)i=ranks[i];const Token&t=get(c.s,u);int p=0;for(int a=0;a<6;a++)for(int b=a+1;b<6;b++)
  if(!(D[u[a]][u[b]]&=t.w[p++]))return 1;}
 // Known difference ranges conjoined on all shared marks; Floyd gives all path bounds.
 int B[K][K];for(int i=0;i<K;i++){B[i][i]=0;for(int j=i+1;j<K;j++){W w=D[i][j];B[i][j]=63-__builtin_clzll(w);B[j][i]=-__builtin_ctzll(w);}}
 for(int k=0;k<K;k++){for(int i=0;i<K;i++)for(int j=0;j<K;j++)B[i][j]=min(B[i][j],max(-1024,B[i][k]+B[k][j]));for(int i=0;i<K;i++)if(B[i][i]<0)return 2;}
 if(delta3){for(int i=0;i<K;i++)for(int j=i+1;j<K;j++){int lo=-B[j][i],hi=B[i][j];D[i][j]&=(bt(hi+1)-1)^(bt(lo)-1);if(!D[i][j])return 2;}
  for(int i=0;i<K;i++)for(int j=i+1;j<K;j++)for(int k=j+1;k<K;k++){W a=D[i][j],b=D[j][k],c=D[i][k];if(pc(a)>pc(b))swap(a,b);W e=0;for(;a&&!e;a&=a-1)e=(b<<__builtin_ctzll(a))&c;if(!e)return 3;}
 }
 if(!writebound.empty()){ofstream q(writebound);for(int i=0;i<K;i++){for(int j=0;j<K;j++)q<<B[i][j]-(j-i)<<' ';q<<'\n';}assert(q);}
 return 4;
}
int main(int ac,char**av){ifstream p(av[1]),f(av[2]);out.open(av[3]);delta3=ac>4;ios::sync_with_stdio(false);
 array<int,6>rr0;while(p>>rr0[0]>>rr0[1]>>rr0[2]>>rr0[3]>>rr0[4]>>rr0[5]){auto q=rr0;sort(q.begin(),q.end());Row a;a.q=q;for(int j=0;j<6;j++)a.g[j]=(q[(j+1)%6]-q[j]+N)%N;auto b=rr0;for(int&x:b)x=lower_bound(q.begin(),q.end(),x)-q.begin();table[sig(b)].push_back(a);}
 int shape;while(f>>shape>>n){for(int i=0;i<n;i++)f>>r[i];for(int i=0;i<n;i++)f>>c[i];nt++;rr.clear();bad.clear();global();local();sort(rr.begin(),rr.end());rr.erase(unique(rr.begin(),rr.end(),[](auto&a,auto&b){return !(a<b)&&!(b<a);}),rr.end());sort(bad.begin(),bad.end());bad.erase(unique(bad.begin(),bad.end()),bad.end());
 auto visit=[&](auto&&go,W h,int at,int k)->void{if(k){for(int j=at;j<=n-k;j++)go(go,h|bt(j),j+1,k-1);return;}layouts++;int t=mark(h);counts[t]++;if(t==4)out<<nt<<' '<<shape<<' '<<h<<'\n';};visit(visit,0,0,n-K);
 if(!(nt%10000))cerr<<nt<<" traces, "<<layouts<<" layouts, "<<counts[4]<<" survive, "<<memo.size()<<" lookup\n";}
 cout<<"traces "<<nt<<" layouts "<<layouts<<" order, pair, linear, 3-sum rejects and open:";for(int i=0;i<5;i++)cout<<' '<<counts[i];cout<<" memo "<<memo.size()<<'\n';
}
