// Exact vertex-link membership check against all simplicial four-polytopes with 5..9 vertices.
#include <algorithm>
#include <array>
#include <cstdint>
#include <vector>
#include <fstream>
#include <iostream>
#include <unordered_map>
#include <cassert>
#include <cstring>
using namespace std;using U=uint64_t;
int b(int i){return 1<<i;}U h(U x){x+=0x9e3779b97f4a7c15ULL;x=(x^(x>>30))*0xbf58476d1ce4e5b9ULL;x=(x^(x>>27))*0x94d049bb133111ebULL;return x^(x>>31);}
U tablewt[64];
struct P{int nv;vector<int>F;int co[9][9];U sig[9],key;bool mem[512];
void init(int n,const vector<int>&faces){nv=n;F=faces;memset(co,0,sizeof co);memset(mem,0,sizeof mem);for(auto f:F){mem[f]=true;int u=f;while(u){int i=__builtin_ctz(u);u&=u-1;int v=f;while(v){int j=__builtin_ctz(v);v&=v-1;co[i][j]++;}}}
 U a[9];for(int i=0;i<n;i++)sig[i]=h(co[i][i]);for(int round=0;round<2;round++){for(int i=0;i<n;i++){U v=sig[i];for(int j=0;j<n;j++)v+=tablewt[co[i][j]]*sig[j];a[i]=h(v);}copy(a,a+n,sig);}
 key=h(n+32*F.size());for(int i=0;i<n;i++)key+=h(sig[i]);}};
bool equ(const P&A,const P&B){if(A.nv!=B.nv||A.F.size()!=B.F.size()||A.key!=B.key)return 0;int n=A.nv;int poss[9]={},order[9],mp[9]={};for(int i=0;i<n;i++){order[i]=i;for(int j=0;j<n;j++)if(A.sig[i]==B.sig[j])poss[i]|=b(j);if(!poss[i])return 0;}
 sort(order,order+n,[&](int i,int j){return __builtin_popcount(poss[i])<__builtin_popcount(poss[j]);});
 auto dfs=[&](auto&&self,int k,int used)->bool{if(k==n){for(int z:A.F){int g=0;while(z){int i=__builtin_ctz(z);z&=z-1;g|=b(mp[i]);}if(!B.mem[g])return false;}return true;}
 int i=order[k],opt=poss[i]&~used;while(opt){int j=__builtin_ctz(opt);opt&=opt-1;bool good=1;for(int a=0;a<k;a++)if(A.co[i][order[a]]!=B.co[j][mp[order[a]]]){good=0;break;}if(good){mp[i]=j;if(self(self,k+1,used|b(j)))return true;}}
 return false;};return dfs(dfs,0,0);}
int main(int argc,char**argv){if(argc<3)return 1;for(int j=0;j<64;j++)tablewt[j]=h(j+109);unordered_map<U,vector<P>> known;ifstream cat(argv[1]);int n,nf;while(cat>>n>>nf){vector<int>F(nf);for(int&f:F)cat>>f;P p;p.init(n,F);known[p.key].push_back(p);}
 vector<int>subs;for(int s=0;s<1024;s++)if(__builtin_popcount(s)==5)subs.push_back(s);array<U,4>key;ifstream bin(argv[2],ios::binary);ofstream out;if(argc>3)out.open(argv[3],ios::binary);long long all[43]={},surv[43]={};
 while(bin.read((char*)&key[0],32)){vector<int> F;for(int half=0;half<4;half++){U x=key[half];while(x){int j=__builtin_ctzll(x);x&=x-1;F.push_back(subs[half*64+j]);}}nf=F.size();all[nf]++;
 bool valid=true;for(int i=0;i<10&&valid;i++){vector<int>T;int s=0;for(int f:F)if(f&b(i)){s|=f^b(i);T.push_back(f^b(i));}
 int mp[10]={};int n=0;for(int j=0;j<10;j++)if(s&b(j))mp[j]=b(n++);assert(n>=5&&n<=9);
 for(int &f:T){int q=f,v=0;while(q){int j=__builtin_ctz(q);q&=q-1;v|=mp[j];}f=v;}P p;p.init(n,T);auto a=known.find(p.key);valid=false;if(a!=known.end())for(auto &Q:a->second)if(equ(p,Q)){valid=true;break;}}
 if(valid){surv[nf]++;if(out)out.write((char*)&key[0],32);}}
 for(int i=34;i<=42;i+=2)cout<<i<<" "<<all[i]<<" "<<surv[i]<<"\n";
}
