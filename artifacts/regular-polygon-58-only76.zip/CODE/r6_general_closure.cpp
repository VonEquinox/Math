// Algebraic straight-line closure of rank-one masks on marked conic vertices.
// A private positive pivot has value s(h,l) and is safe under every conic
// specialization with distinct marks. Complete a mixed-additive cell or a
// pivot rectangle, retaining several expressions of least coordinate support.
// Hashes are used only to DROP redundant necessary equations (no exclusion).
#include <bits/stdc++.h>
using namespace std;using W=uint64_t;int K,N,scope,rounds,keep;
const int P=10000019;int Z[40];long long np(int a,int b){long long x=a,y=1;while(b){if(b&1)y=y*x%P;x=x*x%P;b/=2;}return y;}
struct E{W vars;int sig,op,i,j,k,cost;};struct Rel{int x,y;W vars;};vector<E>T;vector<Rel>rel;
set<tuple<int,int,int,int>>expr;set<pair<int,int>>equ;int S[40][40],M[40][40],pv[10][40][40];
vector<pair<int,int>> base[10];vector<int> opts[10][40][40];int R[40],C[40];mt19937 mt(7418190);
int pop(W x){return __builtin_popcountll(x);}
int slack(int i,int j){int d1=(Z[j]-Z[i]+P)%P,d2=(Z[j]-Z[(i+1)%K]+P)%P;return 1LL*d1*d2%P; }
int initS(int i,int j){int q=T.size();W v=(W(1)<<i)|(W(1)<<((i+1)%K))|(W(1)<<j);T.push_back({v,slack(i,j),0,i,j,0,0});return q;}
map<tuple<int,int,int,int>,int> exid;
int makee(int op,int i,int j,int k=0){W a=T[i].vars|T[j].vars;if(op==2)a|=T[k].vars;if(pop(a)>scope)return -1;
 if(op==2&&i>j)swap(i,j);
 if(op==2&&i==k)return j; if(op==2&&j==k)return i;
 auto key=make_tuple(op,i,j,k);auto it=exid.find(key);if(it!=exid.end())return it->second;
 int v;if(op==1)v=(T[i].sig-T[j].sig+P)%P;else {assert(T[k].op==0&&T[k].sig!=0);v=1LL*T[i].sig*T[j].sig%P*pv[0][T[k].i][T[k].j]%P;}
 int c=T[i].cost+T[j].cost+1;if(c>28)return -1;int h=T.size();T.push_back({a,v,op,i,j,k,c});exid.emplace(key,h);return h;}
void addrel(int a,int b){if(a<0||b<0||T[a].sig==T[b].sig)return;W v=T[a].vars|T[b].vars;if(pop(v)>scope)return;auto k=minmax(a,b);if(equ.insert(k).second)rel.push_back({a,b,v});}
bool setv(int t,int i,int j,int a){if(a<0||T[a].sig==0)return false;auto&Q=opts[t][i][j];
 bool duplicate=false,better=true;for(int b:Q){addrel(a,b);if(T[a].sig==T[b].sig&&T[a].vars==T[b].vars){if(T[b].cost<=T[a].cost)duplicate=true;}if((T[b].vars&T[a].vars)==T[b].vars&&T[b].sig==T[a].sig&&T[b].cost<=T[a].cost)duplicate=true;}
 if(duplicate)return false;
 auto rank=[](int a){return make_tuple(pop(T[a].vars),T[a].cost,T[a].vars,a);};Q.push_back(a);sort(Q.begin(),Q.end(),[&](int a,int b){return rank(a)<rank(b);});if(int(Q.size())>keep){int rem=Q.back();Q.pop_back();if(rem==a)return false;}return true;}
void solve(int s){
 T.clear();exid.clear();rel.clear();equ.clear();for(int t=0;t<10;t++){base[t].clear();for(int i=0;i<K;i++)for(int j=0;j<K;j++)opts[t][i][j].clear();}
 for(int i=0;i<K;i++)for(int j=0;j<K;j++){S[i][j]=initS(i,j);int m=R[i]<0?0:R[i]&C[j];M[i][j]=m;if(m){assert(T[S[i][j]].sig!=0);pv[0][i][j]=np(T[S[i][j]].sig,P-2);if(!(m&(m-1))){int t=__builtin_ctz(m);base[t].push_back({i,j});opts[t][i][j].push_back(S[i][j]);}}}
 for(int rd=0;rd<rounds;rd++){int cnt=0;
 for(int t=0;t<10;t++)for(auto [h,l]:base[t]){int pivot=S[h][l];
  for(int i=0;i<K;i++)if(i!=h&&!opts[t][i][l].empty())for(int j=0;j<K;j++)if(j!=l&&!opts[t][h][j].empty()&&(M[i][j]>>t&1)){
   auto &A=opts[t][i][l],&B=opts[t][h][j];for(int a:A)for(int b:B){if(pop(T[a].vars|T[b].vars|T[pivot].vars)>scope)continue;int h0=makee(2,a,b,pivot);if(h0>=0)cnt+=setv(t,i,j,h0);}
  }}
 for(int i=0;i<K;i++)for(int j=0;j<K;j++){int m=M[i][j];if(pop(m)<2)continue;
 for(int zz=m;zz;zz&=zz-1){int t=__builtin_ctz(zz);vector<int>states{S[i][j]};
  for(int z=m^(1<<t);z;z&=z-1){int h=__builtin_ctz(z);vector<int>next;for(int a:states)for(int b:opts[h][i][j]){int g=makee(1,a,b);if(g>=0)next.push_back(g);}sort(next.begin(),next.end(),[](int a,int b){return make_tuple(pop(T[a].vars),T[a].cost,a)<make_tuple(pop(T[b].vars),T[b].cost,b);});if(int(next.size())>8)next.resize(8);states.swap(next);if(states.empty())break;}
  for(int a:states)cnt+=setv(t,i,j,a);
 }}
 if(!cnt)break;}
}
void write(int s,ofstream&out){sort(rel.begin(),rel.end(),[](const Rel&a,const Rel&b){return make_tuple(pop(a.vars),T[a.x].cost+T[a.y].cost,a.vars)<make_tuple(pop(b.vars),T[b.x].cost+T[b.y].cost,b.vars);});
 // evaluations proportional to each other under this fingerprint might collide; do not add a new invalid equation by simplification.
 unordered_map<int,int>ids;vector<int>lst;function<int(int)> id=[&](int a){auto it=ids.find(a);if(it!=ids.end())return it->second;auto &e=T[a];if(e.op){id(e.i);id(e.j);if(e.op==2)id(e.k);}int i=lst.size();ids[a]=i;lst.push_back(a);return i;};
 set<pair<W,int>> ded;vector<Rel> good;for(auto g:rel){int h=(T[g.x].sig-T[g.y].sig+P)%P;h=min(h,P-h);if(!ded.emplace(g.vars,h).second)continue;id(g.x);id(g.y);good.push_back(g);}
 out<<s<<' '<<lst.size()<<' '<<good.size()<<'\n';for(int u:lst){auto e=T[u];out<<e.op<<' '<<(e.op?ids[e.i]:e.i)<<' '<<(e.op?ids[e.j]:e.j)<<' '<<(e.op==2?ids[e.k]:0)<<'\n';}
 for(auto g:good)out<<ids[g.x]<<' '<<ids[g.y]<<' '<<g.vars<<'\n';}
int main(int ac,char**av){ifstream m(av[1]),is(av[2]);ofstream o(av[3]);scope=atoi(av[4]);rounds=ac>5?atoi(av[5]):3;keep=ac>6?atoi(av[6]):3;set<int>I;int k,cnt;while(is>>k)I.insert(k);m>>K>>N>>cnt;o<<K<<' '<<N<<' '<<I.size()<<'\n';set<int>Zs;for(int i=0;i<K;i++)do{Z[i]=1+mt()%(P-1);}while(!Zs.insert(Z[i]).second);
 for(int i=0;i<cnt;i++){for(int j=0;j<K;j++)m>>R[j];for(int j=0;j<K;j++)m>>C[j];if(!I.count(i))continue;solve(i);write(i,o);}
}
