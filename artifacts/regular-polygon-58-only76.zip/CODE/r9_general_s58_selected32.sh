#!/bin/sh
# For a supplied 32-byte source type sequence, produce every proper regular58
# marked support class, with only certified necessary sieves and zero budgets.
set -eu
b=$1;src=$2;p=$3;q=$4;mkdir -p "$q/chunks";N=$(( $(wc -c <"$src")/32 ));test "$((N*32))" = "$(wc -c <"$src")";a=0
while [ "$a" -lt "$N" ];do t="$q/chunks/b$a";"$b/r8_general_s58_streambi" "$src" 96 "$q/chi" "$a" 32 >"$t.geo";"$b/r3_geom_export" "$src" "$q/chi" >"$q/tmp";"$b/r8_general_s58_intrinsic" "$p" "$q/tmp" "$t.left" d3 >"$t.log";gzip -c "$q/tmp" >"$t.gz";a=$((a+96));done
python3 CODE/r8_general_s58_gather36.py "$q/chunks" "$q";"$b/r8_general_s58_intrinsicjoin" "$p" "$q/raw" "$q/left" "$q/data" "$q/back" >"$q/head";cat "$q/head" "$q/data" >"$q/sys";"$b/r5_general_markedjoin" "$p" "$q/sys" 15000 58 >"$q/j";tail -1 "$q/j";grep -q ' budget=0 ' "$q/j"
: >"$q/none";python3 CODE/r5_general_massstream.py "$q/raw" "$q/back" "$q/j" "$q/m" 58 32 0 "$q/none";python3 CODE/r5_general_metalines.py "$q/m.meta" 58 >"$q/ms"
