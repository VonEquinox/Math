#!/bin/sh
# Six-dimensional width11 regular58: proper f36 K32 and noncross f32 K31.
# Default: exact terminal; --rebuild: regenerate ALL geometry from the reusable
# 4D/9-figure census; --source <binary>: SHA-checked supplied full 5D/10 input.
set -eu
cd "$(dirname "$0")/..";w=${WORK:-$(mktemp -d)};mkdir -p "$w";if [ -z "${WORK:-}" ];then trap 'rm -rf "$w"' EXIT;fi
c=${CXX:-c++};for s in r4_chord_concurrency r5_general_fasttree r7_general_mass_exactrect r6_general_closure r6_general_validate_slp r8_general_s58_pairtable;do "$c" -O3 -std=c++17 "CODE/$s.cpp" -o "$w/$s";done
"$c" -O3 -std=c++17 -DGROUPED_CLOSURE CODE/r6_general_closecheck.cpp -o "$w/bundle"
mkdir -p "$w/empty";"$w/r4_chord_concurrency" 58 1000037 668900 "$w/buckets"
python3 CODE/r4_chord_triples_exact.py 58 "$w/buckets" "$w/exact";python3 CODE/r5_general_patterns35.py 58 "$w/exact" >"$w/p";test "$(wc -l <"$w/p")" -eq 26040
mode=${1:-};if [ -n "$mode" ];then
 for s in r3_geom_quickp r3_geom_join r3_geom_stream r3_geom_export r5_general_markedjoin r8_general_s58_intrinsic r8_general_s58_intrinsicjoin;do "$c" -O3 -w -std=c++17 "CODE/$s.cpp" -o "$w/$s";done
 "$c" -O3 -std=c++17 -DMARKED_K=31 CODE/r5_general_marked34.cpp -o "$w/mk31"
 if [ "$mode" = "--source" ];then src=$2;else
 test "$mode" = "--rebuild";sed 's/if(nf>=33)/if(nf==32||nf==36)/' CODE/r3_geom_fill.cpp >"$w/fill.cpp";"$c" -O3 -std=c++17 "$w/fill.cpp" -o "$w/fill";for s in canon links;do "$c" -O3 -std=c++17 "CODE/r3_geom_$s.cpp" -o "$w/$s";done
 vf=CERTIFICATES/r3_geom_vertexfigures.txt;sl=CERTIFICATES/r3_geom_smalllinks.txt
 "$w/fill" "$vf" 0 1142 "$w/g" >"$w/fcount";"$w/canon" "$vf" "$w/g" "$w/c" >"$w/ccount";"$w/links" "$sl" "$w/c" "$w/fulltypes" >"$w/lcount";src="$w/fulltypes"
 fi
 python3 - "$src" "$w" <<'P'
from pathlib import Path
import sys,hashlib
v=Path(sys.argv[1]).read_bytes();w=Path(sys.argv[2])
for k,h in [(32,'272864c3caf1917602d702a5fb59a5ef74230cdcd219c2cb1362618afd14974a'),(36,'a9d1b5a7ab5c2b1ca35966d6610402322bc519c7861507481af199c172e1c1c3')]:
 a=b''.join(v[i:i+32]for i in range(0,len(v),32)if int.from_bytes(v[i:i+32],'little').bit_count()==k)
 assert hashlib.sha256(a).hexdigest()==h;(w/str(k)).write_bytes(a)
P
 q="$w/low";mkdir -p "$q";"$w/r3_geom_quickp" "$w/32" 32 1000000 0 "$q/quick" 31 >"$q/filter";grep -q 'count 3860 surviving 916' "$q/filter"
 "$w/r3_geom_join" "$q/quick" 1000000 "$q/chi" 0 31 >"$q/fill";"$w/r3_geom_export" "$q/quick" "$q/chi" >"$q/raw";test "$(wc -l <"$q/raw")" -eq 6842
 "$w/mk31" "$q/raw" "$q/both" 58 "$q/data" "$w/p" >"$q/head";awk '$4==1' "$q/both" >"$q/back"
 cat "$q/head" "$q/data" >"$q/sys";"$w/r5_general_markedjoin" "$w/p" "$q/sys" 20000 58 >"$q/j"
 : >"$q/none";python3 CODE/r5_general_massstream.py "$q/raw" "$q/back" "$q/j" "$q/m" 58 31 0 "$q/none";python3 CODE/r5_general_metalines.py "$q/m.meta" 58 >"$q/ms"
 q="$w/high";mkdir -p "$q/chunks";"$w/r3_geom_quickp" "$w/36" 36 1000000 0 "$q/quick" 32 >"$q/filter";grep -q 'count 26548 surviving 26529' "$q/filter"
 start=0;while [ "$start" -lt 26529 ];do a="$q/chunks/b$start";"$w/r3_geom_stream" "$q/quick" 400 "$q/tmpchi" "$start" 32 >"$a.geo";"$w/r3_geom_export" "$q/quick" "$q/tmpchi" >"$q/tmpraw"
 "$w/r8_general_s58_intrinsic" "$w/p" "$q/tmpraw" "$a.left" 3 >"$a.filter";gzip -c "$q/tmpraw" >"$a.gz";start=$((start+400));done
 python3 CODE/r8_general_s58_gather36.py "$q/chunks" "$q"
 "$w/r8_general_s58_intrinsicjoin" "$w/p" "$q/raw" "$q/left" "$q/data" "$q/back" >"$q/head"
 cat "$q/head" "$q/data" >"$q/sys";"$w/r5_general_markedjoin" "$w/p" "$q/sys" 15000 58 >"$q/j";grep -q 'total=345 unsat=303 budget=0 candidates=42' "$q/j"
 : >"$q/none";python3 CODE/r5_general_massstream.py "$q/raw" "$q/back" "$q/j" "$q/m" 58 32 0 "$q/none";python3 CODE/r5_general_metalines.py "$q/m.meta" 58 >"$q/ms"
 python3 - "$q" <<'P'
from pathlib import Path
import sys
q=Path(sys.argv[1]);L=[tuple(map(int,s.split()))for s in(q/'m.map').open()if s.split()[0]=='3'];assert len(L)==1
_,_,g,sh,sw,mask=L[0];assert(sh,sw,mask)==(1050,1,0)
assert(q/'raw').read_bytes().splitlines()[g-1]==Path('CERTIFICATES/r8_s58_f36_last_raw.txt').read_bytes().strip()
P
fi
for k in f32_K31 f36_K32;do
 gzip -dc "CERTIFICATES/r8_s58_${k}_masks.gz" >"$w/testms";if [ -n "$mode" ];then if [ "$k" = "f32_K31" ];then cmp "$w/testms" "$w/low/ms";else cmp "$w/testms" "$w/high/ms";fi;fi
 "$w/r5_general_fasttree" "$w/testms" "$w/eq" 9;awk 'NR==1{for(i=0;i<$3;i++)print i}' "$w/testms" >"$w/ids"
 "$w/r7_general_mass_exactrect" "$w/eq" "$w/ids" 8 - "$w/p" >"$w/e";tail -1 "$w/e"
 if [ "$k" = f32_K31 ];then grep -q '^total 131 empty / 131$' "$w/e";else
 grep -q '^total 72 empty / 75$' "$w/e";awk '/ unresolved /{print $1}' "$w/e" >"$w/left";test "$(tr '\n' ' ' <"$w/left")" = "3 70 74 "
 # ID 3 comes from just one labeled selector; do not transfer its localized
 # boundary geometry to any other isomorphic support.
 printf '70\n74\n' >"$w/two";"$w/r6_general_closure" "$w/testms" "$w/two" "$w/slp" 8 4 3
 "$w/r6_general_validate_slp" "$w/testms" "$w/slp";"$w/bundle" "$w/slp" "$w/empty" '' 8 2400 1021 >"$w/t";tail -1 "$w/t";grep -q '^total 2 empty / 2$' "$w/t"
 fi
done
"$w/r8_general_s58_pairtable" CERTIFICATES/r8_s58_f36_last_raw.txt CERTIFICATES/r8_s58_f36_last_origin.txt "$w/empty" 8 6000000 1200 >"$w/last";cat "$w/last";grep -q '^0 full 3 .*skipped 0 .* EMPTY$' "$w/last"
echo 'No f36 proper K32, and no noncross f32 proper K31. Regular58 balanced ambient f>=67.'
