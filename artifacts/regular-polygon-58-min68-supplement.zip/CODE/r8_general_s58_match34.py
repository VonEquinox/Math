"""Split all 34-facet 5d/10 keys by existence of two vertex-disjoint missing edges."""
import sys,hashlib
from pathlib import Path
from itertools import combinations
p=Path(sys.argv[1]).read_bytes();assert len(p)==11096*32
fr=[s for s in range(1024)if s.bit_count()==5];P=[s for s in range(1024)if s.bit_count()==2]
U={pair:sum(1<<i for i,v in enumerate(fr)if v&pair==pair)for pair in P};A=[];B=[]
for i in range(0,len(p),32):
 b=p[i:i+32];k=int.from_bytes(b,'little');assert k.bit_count()==34;E=[s for s,h in U.items()if not k&h];assert len(E)==4
 if any(a&b0==0 for a,b0 in combinations(E,2)):A.append(b)
 else:
  assert E[0]&E[1]&E[2]&E[3];B.append(b)
for v,path,count in zip((A,B),sys.argv[2:],(8167,2929)):
 t=b''.join(v);assert len(v)==count;Path(path).write_bytes(t);print(count,hashlib.sha256(t).hexdigest())
assert hashlib.sha256(b''.join(A)).hexdigest()=='114cc89072fcaf991413fe6ed13e604afa27bbc70d75ad0f04d3fb0b85a54f93'
