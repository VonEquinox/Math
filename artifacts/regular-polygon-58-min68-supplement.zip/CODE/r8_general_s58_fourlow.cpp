// At f=67, four q31 links determine every facet touching one of these low
// vertices, including every omission. The high-only completion is UNIQUE.
#include <bits/stdc++.h>
using namespace std;using V=vector<int>;int pc(int x){return __builtin_popcount(x);}int bit(int i){return 1<<i;}
struct Pat{V F,O;bool operator<(const Pat&o)const{return tie(F,O)<tie(o.F,o.O);}bool operator==(const Pat&o)const{return tie(F,O)==tie(o.F,o.O);}};
void normalize(Pat&p){sort(p.F.begin(),p.F.end());sort(p.O.begin(),p.O.end());}
struct It{
 int n,ct[1024]={};vector<V> colors;It(int m,const Pat&p):n(m),colors(m){
 for(auto A:{&p.F,&p.O})for(int f:*A)for(int s=f;;s=(s-1)&f){ct[s]+=(A==&p.F)?16:1;if(!s)break;}
 for(int i=0;i<n;i++){V t;for(int j=0;j<n;j++)if(j!=i)t.push_back(4096*ct[bit(j)]+ct[bit(i)|bit(j)]);sort(t.begin(),t.end());colors[i].push_back(ct[bit(i)]);colors[i].insert(colors[i].end(),t.begin(),t.end());}}
};
template<class CB>void iso(const It&A,const It&B,const CB&fn){if(A.ct[0]!=B.ct[0])return;int n=A.n;V ab(n,-1),cand(n),ord(n),mp(1024),pre(1024);iota(ord.begin(),ord.end(),0);for(int i=0;i<n;i++){for(int j=0;j<n;j++)if(A.colors[i]==B.colors[j])cand[i]|=bit(j);if(!cand[i])return;}
 sort(ord.begin(),ord.end(),[&](int a,int b){return pc(cand[a])<pc(cand[b]);});
 for(int s=1;s<bit(n);s++)pre[s]=pre[s&(s-1)]|bit(ord[__builtin_ctz(s)]);
 auto dfs=[&](auto&&go,int at,int used)->void{if(at==n){fn(ab);return;}int i=ord[at],h=bit(at);for(int t=cand[i]&~used;t;t&=t-1){int j=__builtin_ctz(t);bool ok=true;
 for(int s=0;s<h;s++){mp[h+s]=mp[s]|bit(j);if(A.ct[pre[h+s]]!=B.ct[mp[h+s]]){ok=false;break;}}if(!ok)continue;
 ab[i]=j;go(go,at+1,used|bit(j));}};dfs(dfs,0,0);}
int mv(int v,const V&map){int r=0;for(;v;v&=v-1)r|=bit(map[__builtin_ctz(v)]);return r;}
Pat remap(const Pat&p,const V&m,int add){Pat o;for(int f:p.F)o.F.push_back(mv(f,m)|add);for(int f:p.O)o.O.push_back(mv(f,m)|add);normalize(o);return o;}
Pat edge(const Pat&p,int k,bool shrink){Pat z;auto f=[&](const V&v,V&w){for(int m:v)if(m&bit(k)){int s=m^bit(k);w.push_back(shrink?(s&(bit(k)-1))|((s>>(k+1))<<k):s);}};f(p.F,z.F);f(p.O,z.O);return z;}
struct Cg{int id;Pat p;vector<It> E;Cg(int i,Pat q):id(i),p(q){for(int j=0;j<10;j++)E.emplace_back(9,edge(p,j,1));}};
int main(int ac,char**av){ifstream q(av[1],ios::binary),t(av[2]);ofstream out(av[3]);map<int,vector<Pat>> occ;map<int,V> Fs;string s;V univ;for(int y=0;y<1024;y++)if(pc(y)==5)univ.push_back(y);
 while(getline(t,s)){stringstream z(s);int n,f;z>>n;Pat p;while(z>>f)p.O.push_back(f);assert(p.O.size()==3);if(!Fs.count(n)){q.seekg(32*(n-1));array<uint64_t,4>a;q.read((char*)a.data(),32);assert(q);for(int j=0;j<252;j++)if(a[j/64]>>(j%64)&1)Fs[n].push_back(univ[j]);}p.F=Fs[n];normalize(p);occ[n].push_back(p);}
 vector<Cg>P;for(auto&[id,L]:occ){Pat F{Fs[id],{}};It I(10,F);vector<V>aut;iso(I,I,[&](const V&a){aut.push_back(a);});set<V>D;for(auto&p:L){V best=p.O;for(auto&r:aut){V z;for(int f:p.O)z.push_back(mv(f,r));sort(z.begin(),z.end());best=min(best,z);}if(D.insert(best).second)P.emplace_back(id,Pat{F.F,best});}cout<<"shape "<<id<<" stars "<<L.size()<<" aut "<<aut.size()<<" marked orbits "<<D.size()<<endl;}
 int start=ac>4?stoi(av[4]):0,stop=ac>5?stoi(av[5]):int(P.size());long long triples=0,yes=0;
 struct Option{Pat w;array<Pat,11> sides;};
 for(int aa=start;aa<min<int>(P.size(),stop);aa++){auto&A=P[aa];V root;for(int i=1;i<11;i++)root.push_back(i);Pat PA=remap(A.p,root,1);
 vector<vector<Option>>opts(11);for(int i=1;i<11;i++){set<Pat>D;for(int bb=0;bb<P.size();bb++){auto&B=P[bb];for(int v=0;v<10;v++)iso(B.E[v],A.E[i-1],[&](const V&m){V map(10);int z=0;for(int k=0;k<10;k++)if(k!=v){int x=m[z++];map[k]=1+x+(x>=i-1);}map[v]=0;D.insert(remap(B.p,map,bit(i)));});}
 for(auto&p:D){Option op;op.w=p;for(int j=1;j<11;j++)if(j!=i)op.sides[j]=edge(p,j,0);opts[i].push_back(op);}}
 // Local facet masks in sides[j] remove j but keep i. Compare on common global 6-facets.
 for(int i=1;i<11;i++)for(auto&o:opts[i])for(int j=1;j<11;j++)if(j!=i){for(int&f:o.sides[j].F)f|=bit(j);for(int&f:o.sides[j].O)f|=bit(j);}
 vector<map<Pat,V>> join(121);for(int i=1;i<11;i++)for(int j=1;j<11;j++)if(i!=j)for(int a=0;a<opts[i].size();a++)join[11*i+j][opts[i][a].sides[j]].push_back(a);
 auto glue=[&](const Pat&A,const Pat&B,const Pat&C,int L){triples++;set<int>f,o;for(auto*z:array<const Pat*,4>{&PA,&A,&B,&C}){f.insert(z->F.begin(),z->F.end());o.insert(z->O.begin(),z->O.end());}
 int n=67-f.size(),h=9-o.size(),hi=2047^L;if(n<0||n>7||h<0||h>n)return;
 int F[11]={},O[11]={};for(int v:f)for(int j=0;j<11;j++)F[j]+=v>>j&1;for(int v:o)for(int j=0;j<11;j++)O[j]+=v>>j&1;
 int nz=0,hz=0;for(int j=0;j<11;j++)if(hi>>j&1){int a=F[j]+n-38,b=O[j]+h-6;if(a<0||a>1||b<0||b>a)return;nz+=a;hz+=b;if(a)f.insert(hi^bit(j));if(b)o.insert(hi^bit(j));}else if(F[j]!=34||O[j]!=3)return;
 if(nz!=n||hz!=h)return;int rid[2048]={},tri[2048]={};for(int v:f){for(int s=v;s;s=(s-1)&v){if(pc(s)==5&&++rid[s]>2)return;if(pc(s)<=3)tri[s]=1;}}
 int hollow=0;for(int j=0;j<2048;j++){if(rid[j]==1)return;if(pc(j)==2&&!tri[j])return;if(pc(j)==3&&!tri[j])hollow++;}if(hollow!=10)return;yes++;out<<aa<<' '<<L;for(int a:f)out<<' '<<a;out<<" :";for(int a:o)out<<' '<<a;out<<'\n';};
 for(int i=1;i<11;i++)for(int j=i+1;j<11;j++)for(int k=j+1;k<11;k++)for(auto&a:opts[i]){auto x=join[11*j+i].find(a.sides[j]),y=join[11*k+i].find(a.sides[k]);if(x==join[11*j+i].end()||y==join[11*k+i].end())continue;for(int b0:x->second){auto&b=opts[j][b0];for(int c0:y->second){auto&c=opts[k][c0];if(b.sides[k]==c.sides[j])glue(a.w,b.w,c.w,1|bit(i)|bit(j)|bit(k));}}}
 cout<<"anchor "<<aa<<" of "<<P.size()<<" shape "<<A.id<<" embeddings";for(int i=1;i<11;i++)cout<<' '<<opts[i].size();cout<<" all-compatible cumulative "<<triples<<" possible "<<yes<<endl;
 }
 cout<<"done "<<start<<' '<<stop<<" compatible "<<triples<<" possible "<<yes<<endl;
}
