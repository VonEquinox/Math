// Independent all-permutations colored canonicalizer and explicit 3^7
// pure-high filling verifier. No subset-count isomorphism backtracking,
// stage-1 missing-bit shortcut, or ridge test from the first solver is reused.
#include <bits/stdc++.h>
using namespace std;using H=vector<int>;using A=array<int,10>;int bit(int x){return 1<<x;}int pc(int x){return __builtin_popcount(x);}
int permute(int s,const A&r){int v=0;while(s){v|=bit(r[__builtin_ctz(s)]);s&=s-1;}return v;}
struct Canon{H key;vector<A> maps;};
Canon canon(int n,H h,bool all){
 int C=bit(n);vector<pair<int,int>> val(n);A p{};for(int i=0;i<n;i++){for(int e:h)if(e&bit(i)){val[i].first++;val[i].second+=bool(e&C);}p[i]=i;}
 sort(p.begin(),p.begin()+n,[&](int i,int j){return val[i]!=val[j]?val[i]<val[j]:i<j;});
 vector<pair<int,int>>groups;for(int i=0,j;i<n;i=j){for(j=i+1;j<n&&val[p[j]]==val[p[i]];j++);groups.push_back({i,j});}
 Canon z;auto go=[&](auto&&f,int i)->void{if(i<groups.size()){auto[a,b]=groups[i];do{f(f,i+1);}while(next_permutation(p.begin()+a,p.begin()+b));return;}
 A m{};for(int j=0;j<n;j++)m[p[j]]=j;H v;for(int e:h)v.push_back(permute(e&(C-1),m)|(e&C));sort(v.begin(),v.end());
 if(z.key.empty()||v<z.key){z.key=v;z.maps={m};}else if(all&&z.key==v)z.maps.push_back(m);};go(go,0);return z;}
struct State{H facets;array<Canon,10>link;};
int main(int ac,char**av){ifstream q(av[1],ios::binary),t(av[2]);map<H,State>Q;string l;while(getline(t,l)){stringstream ss(l);int id,o;ss>>id;set<int>O;while(ss>>o)O.insert(o);q.seekg(32*(id-1));array<uint64_t,4>a;q.read((char*)a.data(),32);assert(q);H f;int j=0;for(int v=0;v<1024;v++)if(pc(v)==5){if(a[j/64]>>(j%64)&1)f.push_back(v|(O.count(v)?1024:0));++j;}
 auto K=canon(10,f,false).key;if(Q.count(K))continue;State P;P.facets=K;
 for(int v=0;v<10;v++){H F;for(int e:K)if(e&bit(v))F.push_back((e&(bit(v)-1))|((e>>(v+1))<<v));P.link[v]=canon(9,F,true);}Q[K]=P;}
 cout<<"independently canonicalized "<<Q.size()<<" low stars"<<endl;
 using Opt=vector<H>;long long okpairs=0,fill=0,total=0,limits=0;int at=0;
 for(auto&[key,P]:Q){vector<Opt>op(10);for(int j=0;j<10;j++){set<H>S;auto&T=P.link[j];
 for(auto&[k,R]:Q)for(int b=0;b<10;b++){auto&s=R.link[b];if(s.key!=T.key)continue;
 for(auto&t:T.maps){A I{},map{};for(int k=0;k<9;k++)I[t[k]]=k;
 for(int k=0;k<10;k++)if(k==b)map[k]=10;else{int v=s.maps[0][k-(k>b)],w=I[v];map[k]=w+(w>=j);}
 H a;for(int e:R.facets)a.push_back(permute(e&1023,map)|bit(j)|((e&1024)<<1));sort(a.begin(),a.end());S.insert(a);}}
 op[j].assign(S.begin(),S.end());}
 H star;for(int e:P.facets)star.push_back((e&1023)|1024|((e&1024)<<1));sort(star.begin(),star.end());
 auto ck=[&](const H&A,const H&B,const H&C,int L){
 total++;set<int>I(star.begin(),star.end());for(auto*e:{&A,&B,&C})I.insert(e->begin(),e->end());int full=I.size(),out=0,deg[11]={},miss[11]={};
 for(int e:I){out+=e>=2048;for(int h=0;h<11;h++)if(e&bit(h)){deg[h]++;miss[h]+=e>=2048;}}
 if(full>67||out>9||full<60||out<2)return;limits++;
 H Hs;for(int j=0;j<11;j++)if(!(L&bit(j)))Hs.push_back(j);assert(Hs.size()==7);
 for(int F=0;F<128;F++)if(pc(F)==67-full)for(int O=F;;O=(O-1)&F){if(pc(O)==9-out){bool ok=true;for(int j=0;j<7;j++){int h=Hs[j];if(deg[h]+pc(F&~bit(j))!=38||miss[h]+pc(O&~bit(j))!=6){ok=false;break;}}if(ok)fill++;}if(!O)break;}
 };
 for(int a=0;a<8;a++)for(int b=a+1;b<9;b++)for(int c=b+1;c<10;c++){map<H,vector<int>> ab,ac,bc;
 auto edge=[](const H&v,int j){H x;for(int t:v)if(t&bit(j))x.push_back(t);return x;};
 for(int i=0;i<op[b].size();i++)ab[edge(op[b][i],a)].push_back(i);
 for(int i=0;i<op[c].size();i++)ac[edge(op[c][i],a)].push_back(i),bc[edge(op[c][i],b)].push_back(i);
 for(auto&u:op[a]){auto x=ab.find(edge(u,b)),y=ac.find(edge(u,c));if(x==ab.end()||y==ac.end())continue;
 for(int j:x->second){auto z=bc.find(edge(op[b][j],c));if(z==bc.end())continue;vector<int>r;set_intersection(y->second.begin(),y->second.end(),z->second.begin(),z->second.end(),back_inserter(r));for(int k:r)ck(u,op[b][j],op[c][k],1024|bit(a)|bit(b)|bit(c));}}}
 cout<<"anchor "<<++at<<" cumulative "<<total<<" pass cardinality "<<limits<<" some degree filling "<<fill<<endl;
 }cout<<"independent result "<<total<<" compatible, "<<limits<<" pass cardinality, "<<fill<<" complete full/omitted degrees"<<endl;
}
