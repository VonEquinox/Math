"""Recover exact marked facet subsets from every original joint-angular backlink."""
from pathlib import Path
from collections import Counter,defaultdict
import sys
def run(q0,dir,save,allow=None):
 p=Path(dir);Q=Path(q0).read_bytes();se=[s for s in range(1024)if s.bit_count()==5];Fs={};T=set();shapes=Counter();ids=defaultdict(set)
 allowed=set(map(int,Path(allow).read_text().split()))if allow else None
 cases=defaultdict(list)
 for l in open(p/'m.map'):
  fid,u,g,sh,sw,h=map(int,l.split());assert sw==1
  if allowed is None or fid in allowed:cases[g].append((fid,sh,h))
 for g,l in enumerate(open(p/'raw'),1):
  if g not in cases:continue
  sh,n,*row=map(int,l.split());r=tuple(s^1023 for s in row[:n]);c=row[n:];assert len(c)==n==len(set(r))
  if sh not in Fs:
   z=int.from_bytes(Q[32*sh-32:32*sh],'little');Fs[sh]={s for i,s in enumerate(se)if z>>i&1}
  F=Fs[sh];assert set(r)<=F;A=tuple(F-set(r));shapes[sh]+=1
  for id,o,h in cases[g]:
   assert o==sh
   key=(sh,tuple(sorted(A+tuple(r[i]for i in range(n)if h>>i&1))))
   T.add(key);ids[key].add(id)
 with open(save,'w')as f,open(save+'.ids','w')as a:
  for key in sorted(T):
   sh,O=key;print(sh,*O,file=f);print(sh,*O,':',*sorted(ids[key]),file=a)
 print('active cycles by shape',shapes,'literal unique omit stars',Counter(sh for sh,O in T),flush=True)
if __name__=='__main__':run(*sys.argv[1:])
