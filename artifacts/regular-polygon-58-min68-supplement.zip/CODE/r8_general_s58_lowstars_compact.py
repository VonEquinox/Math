"""Compact literal full five-facet masks for the four-low join; no isomorphism changes."""
from pathlib import Path
import sys
p,q,up,op=map(Path,sys.argv[1:]);cells=[list(map(int,s.split())) for s in q.read_text().splitlines()]
keys=sorted({s[0]for s in cells});t=p.read_bytes();up.write_bytes(b''.join(t[32*i-32:32*i]for i in keys))
op.write_text(''.join(' '.join(map(str,[keys.index(i)+1]+a))+'\n'for i,*a in cells))
print('source keys',keys,'literal sets',len(cells))
