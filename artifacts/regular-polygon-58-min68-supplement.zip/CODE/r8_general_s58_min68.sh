#!/bin/sh
# Corrected direct-from-4D source build and independent full marked four-link join.
set -eu
cd "$(dirname "$0")/..";w=${WORK:-$(mktemp -d)};mkdir -p "$w";if [ -z "${WORK:-}" ];then trap 'rm -rf "$w"' EXIT;fi
C=${CXX:-c++};for s in r4_chord_concurrency r5_general_fasttree r7_general_mass_exactrect r8_general_s58_fourlow r8_general_s58_fourlow_check;do "$C" -O3 -std=c++17 "CODE/$s.cpp" -o "$w/$s";done
"$w/r4_chord_concurrency" 58 1000037 668900 "$w/buckets" >"$w/chord.log";python3 CODE/r4_chord_triples_exact.py 58 "$w/buckets" "$w/exact";python3 CODE/r5_general_patterns35.py 58 "$w/exact" >"$w/p";test "$(wc -l <"$w/p")" -eq 26040
if [ -n "${1:-}" ];then
 for s in r3_geom_quickp r3_geom_stream r3_geom_join r3_geom_export r5_general_markedjoin;do "$C" -O3 -std=c++17 "CODE/$s.cpp" -o "$w/$s";done
 "$C" -O3 -std=c++17 -DMARKED_K=30 CODE/r5_general_marked34.cpp -o "$w/m30"
 sed 's/const int K=32,N=58/const int K=31,N=58/' CODE/r8_general_s58_intrinsic.cpp >"$w/s31.cpp"
 sed 's/"r8_general_s58_intrinsic.cpp"/"s31.cpp"/' CODE/r8_general_s58_intrinsicjoin.cpp >"$w/j31.cpp"
 "$C" -O3 -std=c++17 "$w/s31.cpp" -o "$w/s31";"$C" -O3 -std=c++17 "$w/j31.cpp" -o "$w/j31"
 if [ "$1" = "--source" ];then src=$2;else
 test "$1" = "--rebuild";sed 's/if(nf>=33)/if(nf==30||nf==34)/' CODE/r3_geom_fill.cpp >"$w/f0.cpp";"$C" -O3 -std=c++17 "$w/f0.cpp" -o "$w/fill"
 for s in canon links;do "$C" -O3 -std=c++17 "CODE/r3_geom_$s.cpp" -o "$w/$s";done
 "$w/fill" CERTIFICATES/r3_geom_vertexfigures.txt 0 1142 "$w/f" >"$w/flog";"$w/canon" CERTIFICATES/r3_geom_vertexfigures.txt "$w/f" "$w/c" >"$w/clog";"$w/links" CERTIFICATES/r3_geom_smalllinks.txt "$w/c" "$w/all" >"$w/llog";src="$w/all"
 fi
 python3 - "$src" "$w" <<'PY'
import hashlib,sys
from pathlib import Path
v=Path(sys.argv[1]).read_bytes()
for k,h in [(30,'ffb58257b51de76878a3bd8313c7d2e4e033cd82ea0eb99ba0c653eed40ccb90'),(34,'ef93a5088552e6d18a556378836478ac0254115338f662cb220d8c88ec456003')]:
 a=b''.join(v[i:i+32]for i in range(0,len(v),32)if int.from_bytes(v[i:i+32],'little').bit_count()==k)
 assert hashlib.sha256(a).hexdigest()==h;(Path(sys.argv[2])/str(k)).write_bytes(a)
PY
 q="$w/lo";mkdir -p "$q";"$w/r3_geom_quickp" "$w/30" 30 1000000 0 "$q/q" 30 >"$q/q.log";grep -q 'count 1276 surviving 4' "$q/q.log"
 "$w/r3_geom_join" "$q/q" 1000000 "$q/chi" 0 30 >"$q/ge";"$w/r3_geom_export" "$q/q" "$q/chi" >"$q/raw";test "$(wc -l <"$q/raw")" -eq 646
 "$w/m30" "$q/raw" "$q/both" 58 "$q/da" "$w/p" >"$q/head";awk '$4==1' "$q/both">"$q/back";cat "$q/head" "$q/da" >"$q/sys";"$w/r5_general_markedjoin" "$w/p" "$q/sys" 15000 58 >"$q/j"
 : >"$q/none";python3 CODE/r5_general_massstream.py "$q/raw" "$q/back" "$q/j" "$q/m" 58 30 0 "$q/none";python3 CODE/r5_general_metalines.py "$q/m.meta" 58 >"$q/ms"
 cmp "$q/ms" CERTIFICATES/r8_s58_f30K30_masks.txt
 q="$w/hi";mkdir -p "$q/chunks";"$w/r3_geom_quickp" "$w/34" 34 1000000 0 "$q/q" 31 >"$q/q.log";grep -q 'count 11096 surviving 8122' "$q/q.log"
 a=0;while [ "$a" -lt 8122 ];do p="$q/chunks/b$a";"$w/r3_geom_stream" "$q/q" 320 "$q/tmpchi" "$a" 31 >"$p.ge";"$w/r3_geom_export" "$q/q" "$q/tmpchi" >"$q/tmpr";"$w/s31" "$w/p" "$q/tmpr" "$p.left" 3 >"$p.log";gzip -c "$q/tmpr" >"$p.gz";a=$((a+320));done
 python3 CODE/r8_general_s58_gather36.py "$q/chunks" "$q";"$w/j31" "$w/p" "$q/raw" "$q/left" "$q/da" "$q/back" >"$q/head";cat "$q/head" "$q/da" >"$q/sys";"$w/r5_general_markedjoin" "$w/p" "$q/sys" 15000 58 >"$q/j";grep -q 'total=1608 unsat=1136 budget=0 candidates=472' "$q/j"
 awk 'NR==FNR{if(/status=(candidate|budget)/)a[$1]=1;next} $1 in a {print -1,$0}' "$q/j" "$q/back">"$q/m.map";test "$(wc -l <"$q/m.map")" -eq 297564
 python3 CODE/r8_general_s58_markedorig.py "$q/q" "$q" "$q/S";python3 CODE/r8_general_s58_lowstars_compact.py "$q/q" "$q/S" "$q/six" "$q/stars"
 cmp "$q/six" CERTIFICATES/r8_s58_f67_six.bin;cmp "$q/stars" CERTIFICATES/r8_s58_f67_stars.txt
fi
"$w/r5_general_fasttree" CERTIFICATES/r8_s58_f30K30_masks.txt "$w/eq" 9;printf '0\n1\n2\n' >"$w/ids";"$w/r7_general_mass_exactrect" "$w/eq" "$w/ids" 8 - "$w/p" >"$w/e";grep -q 'total 3 empty / 3' "$w/e";tail -1 "$w/e"
a=CERTIFICATES/r8_s58_f67_six.bin;b=CERTIFICATES/r8_s58_f67_stars.txt
"$w/r8_general_s58_fourlow" "$a" "$b" "$w/out" >"$w/one";grep -q 'done 0 29 compatible 4432 possible 0' "$w/one";test ! -s "$w/out";tail -1 "$w/one"
"$w/r8_general_s58_fourlow_check" "$a" "$b" >"$w/two";grep -q '4432 compatible, 400 pass cardinality, 0 complete full/omitted degrees' "$w/two";tail -1 "$w/two"
